"""Draws the villagers' emote bubbles as pixel art: a cream speech bubble with a dark outline and a small icon.

usage: python make_emotes.py <Assets/Resources/Art>
Writes emote_<kind>.png (15x14 logical pixels, scaled 4x with hard edges).
"""
import os
import sys

from PIL import Image

INK = (59, 42, 26, 255)          # the UI's dark brown outline
FILL = (255, 248, 230, 255)
SCALE = 4

# 9x7 icons; letters pick colours, "." is the bubble fill
PALETTE = {
    "X": INK, "R": (217, 69, 60, 255), "r": (245, 140, 130, 255), "B": (79, 163, 224, 255), "b": (191, 228, 255, 255),
    "G": (242, 193, 78, 255), "g": (176, 122, 30, 255), "W": (255, 255, 255, 255), "w": (214, 206, 190, 255),
    "N": (110, 72, 40, 255), "n": (150, 104, 60, 255), "O": (232, 120, 40, 255), "V": (90, 110, 190, 255),
    "M": (200, 80, 70, 255), "s": (190, 186, 176, 255), "K": (204, 140, 88, 255),
}
ICONS = {
    "talk": [".........",
             ".........",
             ".........",
             ".XX.XX.XX",
             ".XX.XX.XX",
             ".........",
             "........."],
    "heart": [".RR...RR.",
              "RrRR.RRRR",
              "RRRRRRRRR",
              ".RRRRRRR.",
              "..RRRRR..",
              "...RRR...",
              "....R...."],
    "note": ["...XXXXX.",
             "...X...X.",
             "...X...X.",
             "...X...X.",
             ".XXX.XXX.",
             "XXXXXXXX.",
             ".XX..XX.."],
    "excl": ["...OOO...",
             "...OOO...",
             "...OOO...",
             "....O....",
             ".........",
             "...OOO...",
             "...OOO..."],
    "question": ["..VVVV...",
                 ".VV..VV..",
                 ".....VV..",
                 "....VV...",
                 "...VV....",
                 ".........",
                 "...VV...."],
    "sweat": ["....B....",
              "...BBB...",
              "..BBBBB..",
              "..BBbBB..",
              "..BBBBB..",
              "...BBB...",
              "........."],
    "food": ["..s...s..",
             "...s.s...",
             "..WWWWW..",
             ".WWWWWWW.",
             "NNNNNNNNN",
             ".NnnnnnN.",
             "..NNNNN.."],
    "coin": ["...ggg...",
             "..gGGGg..",
             ".gGGWGGg.",
             ".gGGWGGg.",
             ".gGGGGGg.",
             "..gGGGg..",
             "...ggg..."],
    "zzz": [".....VVVV",
            ".......V.",
            "......V..",
            ".VVV.VVVV",
            "...V.....",
            "..V......",
            ".VVV....."],
    "laugh": [".........",
              "..X...X..",
              ".X.X.X.X.",
              ".........",
              "..XXXXX..",
              "..XMMMX..",
              "...XXX..."],
    "wave": [".K.K.K...",
             ".K.K.K.K.",
             ".KKKKKKK.",
             "KKKKKKKK.",
             ".KKKKKKK.",
             "..KKKKK..",
             "........."],
}


def bubble():
    """15x14: rounded body (rows 0-10) and a tail at the bottom left pointing at the speaker's head."""
    w, h = 15, 14
    px = [[None] * w for _ in range(h)]
    for y in range(11):
        for x in range(w):
            px[y][x] = INK if x in (0, w - 1) or y in (0, 10) else FILL
    for x, y in ((0, 0), (w - 1, 0), (0, 10), (w - 1, 10)):      # rounded corners
        px[y][x] = None
    for x, y in ((1, 1), (w - 2, 1), (1, 9), (w - 2, 9)):
        px[y][x] = INK
    px[10][3] = px[10][4] = FILL                                  # the tail opens out of the bottom edge
    for x, y, c in ((2, 11, INK), (3, 11, FILL), (4, 11, FILL), (5, 11, INK),
                    (1, 12, INK), (2, 12, FILL), (3, 12, INK), (4, 12, INK), (1, 13, INK)):
        px[y][x] = c
    return px


def render(kind, icon):
    px = bubble()
    for j, row in enumerate(icon):
        for i, ch in enumerate(row):
            if ch != ".":
                px[2 + j][3 + i] = PALETTE[ch]
    h, w = len(px), len(px[0])
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    for y in range(h):
        for x in range(w):
            if px[y][x]:
                im.putpixel((x, y), px[y][x])
    return im.resize((w * SCALE, h * SCALE), Image.NEAREST)


if __name__ == "__main__":
    out = sys.argv[1]
    for kind, icon in ICONS.items():
        render(kind, icon).save(os.path.join(out, f"emote_{kind}.png"))
    print(len(ICONS), "emotes")
