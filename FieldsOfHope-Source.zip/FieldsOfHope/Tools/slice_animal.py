"""
Farm animals' sprites for Client/Animals.cs, from AI-generated art (transparent background):

  slice_animal.py walk  sheet.png out.png    a row of walking figures -> a strip of 4 equal frames, 128 px high: every
                                             figure scaled to the same height (112 px), centred, feet 4 px above the bottom
  slice_animal.py sleep pose.png  out.png    one lying-down figure -> cropped, 160 px wide, 4 px clear below it

Frames are as wide as the widest figure needs, so a long carabao fits as well as a chicken; the game reads the frame width
as the strip's width / 4. Only solid pixels count, so faint specks round the edges are ignored.
"""
import sys
from PIL import Image

H, FIG, FEET = 128, 112, 4


def solid(im):
    return im.split()[3].point(lambda a: 255 if a > 40 else 0)


def figures(im):
    # some sheets come with a faint haze along their top and bottom edges: the figures never reach there
    W, Hs = im.size
    px = im.load()
    for y in list(range(0, Hs // 20)) + list(range(Hs - Hs // 20, Hs)):
        for x in range(W): px[x, y] = (0, 0, 0, 0)
    a = solid(im)
    cols = [any(a.getpixel((x, y)) for y in range(0, Hs, 2)) for x in range(W)]
    runs, start = [], None
    for x, on in enumerate(cols + [False]):
        if on and start is None: start = x
        if not on and start is not None:
            if x - start > W * 0.04: runs.append((start, x))
            start = None
    merged = []
    for r in runs:
        if merged and r[0] - merged[-1][1] < W * 0.015: merged[-1] = (merged[-1][0], r[1])
        else: merged.append(r)
    if len(merged) != 4:
        # figures that nearly touch: cut at the emptiest column near each quarter, then keep each frame's own figure
        counts = [sum(1 for y in range(0, Hs, 2) if a.getpixel((x, y))) for x in range(W)]
        cuts = [0] + [min(range(round(W * k / 4 - W * 0.08), round(W * k / 4 + W * 0.08)), key=lambda x: (counts[x], abs(x - W * k / 4)))
                      for k in (1, 2, 3)] + [W]
        merged = list(zip(cuts, cuts[1:]))
    out = []
    for x0, x1 in merged:
        piece = largest_blob(im.crop((x0, 0, x1, Hs)))
        out.append(piece.crop(solid(piece).getbbox()))
    return out


def largest_blob(piece):
    """Only the biggest connected shape stays (a neighbour's tail tip or a stray speck goes)."""
    a = solid(piece); w, h = a.size; m = a.load()
    seen = bytearray(w * h); best = []
    for sy in range(h):
        for sx in range(w):
            if not m[sx, sy] or seen[sy * w + sx]: continue
            blob, stack = [], [(sx, sy)]; seen[sy * w + sx] = 1
            while stack:
                x, y = stack.pop(); blob.append((x, y))
                for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                    if 0 <= nx < w and 0 <= ny < h and m[nx, ny] and not seen[ny * w + nx]:
                        seen[ny * w + nx] = 1; stack.append((nx, ny))
            if len(blob) > len(best): best = blob
    keep = Image.new('L', (w, h), 0); k = keep.load()
    for x, y in best: k[x, y] = 255
    # soft edge pixels next to the kept shape stay too
    from PIL import ImageFilter
    keep = keep.filter(ImageFilter.MaxFilter(5))
    out = Image.new('RGBA', (w, h), (0, 0, 0, 0)); out.paste(piece, (0, 0), keep)
    return out


def walk(src, dst):
    figs = figures(Image.open(src).convert("RGBA"))
    if len(figs) != 4: sys.exit(f"{src}: found {len(figs)} figures, expected 4")
    heights = sorted(f.height for f in figs)
    k = FIG / heights[len(heights) // 2]                      # one scale for the whole walk, from the typical frame
    figs = [f.resize((max(1, round(f.width * k)), max(1, round(f.height * k))), Image.LANCZOS) for f in figs]
    fw = (max(f.width for f in figs) + 8 + 3) // 4 * 4
    strip = Image.new("RGBA", (fw * 4, H), (0, 0, 0, 0))
    for i, f in enumerate(figs):
        strip.alpha_composite(f, (i * fw + (fw - f.width) // 2, max(0, H - FEET - f.height)))
    strip.save(dst)
    print(dst, "4 frames of", fw, "x", H)


def sleep(src, dst):
    f = Image.open(src).convert("RGBA")
    # a faint glow round the figure (some poses come with one) is cleared; the figure's own edges are solid
    px = f.load()
    for y in range(f.height):
        for x in range(f.width):
            if px[x, y][3] < 110: px[x, y] = (0, 0, 0, 0)
    f = largest_blob(f)
    f = f.crop(solid(f).getbbox())
    f = f.resize((160, max(1, round(f.height * 160 / f.width))), Image.LANCZOS)
    out = Image.new("RGBA", (164, f.height + FEET + 2), (0, 0, 0, 0))
    out.alpha_composite(f, (2, 2))
    out.save(dst)
    print(dst, out.size)


if __name__ == "__main__":
    {"walk": walk, "sleep": sleep}[sys.argv[1]](sys.argv[2], sys.argv[3])
