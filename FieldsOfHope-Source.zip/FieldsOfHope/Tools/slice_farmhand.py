"""
Slices the farmhand's work sheets (4 evenly spaced poses, transparent background) into game strips that match his walk cycle.

Each sheet came out of the generator at its own scale, and some poses crouch or raise a tool, so neither the figure height nor
the gaps between poses can be trusted. Instead:
  * every sheet is split near its column boundaries at the emptiest pixel column, and only each part's main figure is kept
    (tools and splashes that touch it stay, specks and slivers of the neighbouring pose are dropped);
  * every sheet is scaled so the salakot hat is as wide as it is in walk_farmer_se, so a crouching planter stays crouch-sized
    and all actions line up with the walking farmer;
  * the feet sit on one baseline, centred in the frame, so he never slides between frames.

Usage: slice_farmhand.py <walk_farmer_se.png> <out_dir> <sheet.png>...   (writes <out_dir>/farmhand_<sheet name>.png)
"""
import os
import sys

from PIL import Image

F = 192            # output frame size: headroom for a raised axe
REF = 160          # the figure is drawn REF / WALK_F times the walk frame's pixel size, so in the game a farmhand_* frame
WALK_F = 144       # is drawn F / REF times as large as a walk frame (Farmhand.cs)
COLS = 4


def solid(im):
    return im.split()[3].point(lambda a: 255 if a > 40 else 0)


def main_figure(col):
    """Keeps the run of columns holding the most pixels, plus runs that nearly touch it; drops edge slivers."""
    s = solid(col)
    W, H = col.size
    counts = [sum(1 for y in range(0, H, 2) if s.getpixel((x, y))) for x in range(W)]
    runs, start = [], None
    for x, c in enumerate(counts + [0]):
        if c and start is None: start = x
        if not c and start is not None: runs.append((start, x)); start = None
    if not runs: return None
    best = max(runs, key=lambda r: sum(counts[r[0]:r[1]]))
    x0, x1 = best
    for r in sorted(runs):                       # a splash or tool tip separated by a small gap belongs to the figure
        if r[1] <= x0 and x0 - r[1] < W * 0.06: x0 = r[0]
    for r in sorted(runs):
        if r[0] >= x1 and r[0] - x1 < W * 0.06: x1 = r[1]
    piece = col.crop((x0, 0, x1, H))
    return piece.crop(solid(piece).getbbox())


def hat_width(fig):
    """Widest solid row in the top third of the figure: the salakot brim."""
    s = solid(fig)
    W, H = fig.size
    best = 0
    for y in range(0, max(1, H // 3)):
        xs = [x for x in range(W) if s.getpixel((x, y))]
        if xs: best = max(best, xs[-1] - xs[0])
    return best


def feet_x(fig):
    s = solid(fig)
    W, H = fig.size
    xs = [x for y in range(int(H * 0.9), H) for x in range(W) if s.getpixel((x, y))]
    return sum(xs) / len(xs) if xs else W / 2


def figures(sheet):
    """Splits the sheet near each nominal column boundary, at the emptiest pixel column, so a pose that leans over the
    boundary isn't cut in half; then keeps each part's main figure."""
    W, H = sheet.size
    s = solid(sheet)
    counts = [sum(1 for y in range(0, H, 2) if s.getpixel((x, y))) for x in range(W)]
    cuts = [0]
    for k in range(1, COLS):
        mid, r = round(W * k / COLS), round(W * 0.09)
        cuts.append(min(range(mid - r, mid + r), key=lambda x: (counts[x], abs(x - mid))))
    cuts.append(W)
    out = []
    for a, b in zip(cuts, cuts[1:]):
        f = main_figure(sheet.crop((a, 0, b, H)))
        if f: out.append(f)
    return out


def median(v):
    v = sorted(v)
    return (v[(len(v) - 1) // 2] + v[len(v) // 2]) / 2


if __name__ == "__main__":
    walk, out_dir, sheets = sys.argv[1], sys.argv[2], sys.argv[3:]
    strip = Image.open(walk).convert("RGBA")
    n = strip.width // strip.height
    walk_hat = median([hat_width(f.crop(solid(f).getbbox())) for f in
                       (strip.crop((i * strip.height, 0, (i + 1) * strip.height, strip.height)) for i in range(n))])
    target = walk_hat * REF / WALK_F
    for path in sheets:
        figs = figures(Image.open(path).convert("RGBA"))
        scale = target / median([hat_width(f) for f in figs])
        out = Image.new("RGBA", (F * len(figs), F), (0, 0, 0, 0))
        for i, f in enumerate(figs):
            w, h = max(1, round(f.width * scale)), max(1, round(f.height * scale))
            g = f.resize((w, h), Image.LANCZOS)
            x = i * F + round(F / 2 - feet_x(f) * scale)
            x = min(max(i * F, x), i * F + F - w)
            out.alpha_composite(g, (x, max(0, F - 4 - h)))
        name = os.path.splitext(os.path.basename(path))[0]
        out.save(os.path.join(out_dir, f"farmhand_{name}.png"))
        print(name, len(figs), "frames, scale", round(scale, 3), "tallest", round(max(f.height for f in figs) * scale), "of", F)
