"""
Builds the farm maps from separate pieces (replaces the single painted farm_bg).

  python -I map_builder.py <pieces_dir> <out_assets_dir> <preview_dir>

For each location it
  * paints the ground (grass, paths, river, ponds, sea, tilled soil, paddies) on the same 2:1 isometric grid the plots use,
    so plots and fields line up by construction -> Resources/Art/ground_<loc>.png (+ mask_ground_<loc>.png for water motion)
  * exports the layout for the game: every object (buildings, trees, props, animals), villagers, walker routes,
    markers and ambience points -> Resources/Map/layout_<loc>.json
  * renders a preview PNG with everything depth-sorted, to check the composition without Unity.
Object art (AI-generated, sliced by slice_sheet.py) is resized to its on-screen size and written to Resources/Map/<name>.png.

Coordinates are "map px": the 1700 x 952 frame the farm screen has always used (FarmScreen.BgToWorld).
"""
import json, math, os, random, sys
from PIL import Image, ImageChops, ImageDraw, ImageFilter

MAP_W, MAP_H = 1700, 952
LOW = 3                                   # ground is painted at 1/3 size and scaled up: chunky pixels like the art
TW, TH = 119.088, 59.544                  # plot tile size in map px (FarmScreen: 176 canvas units / scale)
GX, GY = 270.228, 387.57                  # centre of plot (0,0); plot (c, r) is grid tile (c, r)


def tile(i, j):
    """Centre of grid tile (i, j) in map px."""
    return GX + (i - j) * TW / 2, GY + (i + j) * TH / 2


def diamond(i, j, grow=0.0):
    x, y = tile(i, j)
    hw, hh = TW / 2 + grow, TH / 2 + grow / 2
    return [(x, y - hh), (x + hw, y), (x, y + hh), (x - hw, y)]


# ---------------------------------------------------------------------------------------------- catalogue
# name: (source piece, size spec)   size spec: ("h", px) height or ("w", px) width on the map
CATALOGUE = {
    "farmhouse": ("buildA_00", ("h", 225)), "barn": ("buildA_01", ("h", 235)),
    "store": ("buildB_00", ("h", 150)), "millhouse": ("buildB_01", ("h", 165)), "well": ("buildB_02", ("h", 92)),
    "shed": ("buildB_03", ("h", 105)),
    "feast_table": ("feast_00", ("w", 190)), "side_table": ("feast_01", ("w", 78)), "stool": ("feast_02", ("h", 24)),
    "board": ("feast_05", ("h", 80)), "pot_plant": ("feast_06", ("h", 40)),
    "fence": ("props_00", ("w", 66)),
    # each field's back edges (Tools/make_field_art.py draws these in the old fence's frame)
    "stone_wall": ("edge_00", ("w", 66)), "bamboo_fence": ("edge_01", ("w", 66)), "coco_log": ("edge_02", ("w", 66)), "hay": ("props_02", ("w", 44)), "hay2": ("props_03", ("w", 46)),
    "bench": ("props_04", ("w", 56)), "crate": ("props_05", ("w", 32)), "barrel": ("props_06", ("h", 36)),
    "boulder": ("props_07", ("w", 50)), "rocks": ("props_08", ("w", 46)), "scarecrow": ("props_09", ("h", 82)),
    "sign": ("props_10", ("h", 54)), "trough": ("props_11", ("w", 58)),
    "oak": ("trees_00", ("h", 150)), "pine": ("trees_01", ("h", 172)), "fruit_tree": ("trees_02", ("h", 135)),
    "pine_small": ("trees_03", ("h", 112)), "bush_big": ("trees_04", ("w", 72)), "bush": ("trees_05", ("w", 50)),
    "bush_pink": ("trees_06", ("w", 52)), "bush_yellow": ("trees_07", ("w", 50)),
    "cabbage": ("trees_05", ("w", 26)), "strawberry": ("trees_06", ("w", 26)), "carrot_top": ("trees_04", ("w", 24)),
    "coconut": ("tropic_00", ("h", 190)), "banana": ("tropic_01", ("h", 125)), "mango": ("tropic_02", ("h", 135)),
    "cacao": ("tropic_03", ("h", 120)), "durian": ("tropic_04", ("h", 135)), "pineapple": ("tropic_05", ("w", 66)),
    "bamboo": ("tropic_06", ("h", 140)), "kubo": ("tropic_07", ("h", 135)),
    "turbine": ("ilocos_00", ("h", 250)), "rotor": ("ilocos_01", ("w", 150)), "carabao": ("ilocos_02", ("w", 88)),
    "straw": ("ilocos_03", ("h", 78)), "jars": ("ilocos_04", ("w", 58)), "garlic_rack": ("ilocos_05", ("w", 78)),
    "deer": ("animals_00", ("h", 72)), "goat": ("animals_01", ("h", 48)), "chicken": ("animals_02", ("h", 28)),
    "hen": ("animals_03", ("h", 28)), "duck": ("animals_04", ("w", 34)), "swan": ("animals_05", ("w", 46)),
    "cat": ("animals_06", ("h", 30)), "wheel": ("animals_07", ("w", 90)),
    "campfire": ("campfire", ("w", 60)),       # Tools/make_village_art.py
}
TEXTURE_SCALE = 1.5     # exported art is 1.5x its map size: crisp on a 1080p screen at the farm zoom


def piece_size(name, src):
    kind, v = CATALOGUE[name][1]
    w, h = src.size
    return (round(v), round(h * v / w)) if kind == "w" else (round(w * v / h), round(v))


# ---------------------------------------------------------------------------------------------- ground painter
class Ground:
    def __init__(self, grass, seed):
        self.rnd = random.Random(seed)
        self.w, self.h = MAP_W // LOW + 1, MAP_H // LOW + 1
        self.img = Image.new("RGB", (self.w, self.h), grass[0])
        self.water = Image.new("L", (self.w, self.h), 0)
        self.d = ImageDraw.Draw(self.img)
        self.wd = ImageDraw.Draw(self.water)
        self.grass = grass
        self.paint_grass()

    def P(self, pts):
        return [(x / LOW, y / LOW) for x, y in pts]

    def paint_grass(self):
        g0, g1, g2, tuft = self.grass
        # soft patches of three greens from blurred noise
        noise = Image.effect_noise((self.w, self.h), 90).filter(ImageFilter.GaussianBlur(6))
        lo, hi = noise.getextrema()
        n = noise.load(); px = self.img.load()
        for y in range(self.h):
            for x in range(self.w):
                v = (n[x, y] - lo) / max(1, hi - lo)
                px[x, y] = g1 if v < 0.35 else g2 if v > 0.68 else g0
        for _ in range(self.w * self.h // 55):           # little grass tufts
            x, y = self.rnd.randrange(1, self.w - 2), self.rnd.randrange(1, self.h - 1)
            px[x, y] = tuft; px[x + 1, y - 1] = tuft; px[x + 2, y] = tuft
        for _ in range(self.w * self.h // 900):          # tiny wild flowers
            x, y = self.rnd.randrange(self.w), self.rnd.randrange(self.h)
            px[x, y] = self.rnd.choice([(250, 245, 230), (250, 220, 90), (240, 160, 190)])

    def band(self, pts, width, layers):
        """A smooth band along a polyline; layers = [(extra width, colour), ...] drawn widest first."""
        p = self.P(pts)
        for extra, col in layers:
            w = max(1, round((width + extra) / LOW))
            self.d.line(p, fill=col, width=w, joint="curve")
            r = w / 2
            for x, y in (p[0], p[-1]):
                self.d.ellipse((x - r, y - r, x + r, y + r), fill=col)

    def speckle(self, mask_pts, width, cols, density):
        """Random pebbles/specks inside a band."""
        m = Image.new("L", (self.w, self.h), 0)
        ImageDraw.Draw(m).line(self.P(mask_pts), fill=255, width=max(1, round(width / LOW)), joint="curve")
        mp = m.load(); px = self.img.load()
        for _ in range(int(self.w * self.h * density)):
            x, y = self.rnd.randrange(self.w), self.rnd.randrange(self.h)
            if mp[x, y]:
                px[x, y] = self.rnd.choice(cols)

    def dirt_path(self, pts, width):
        self.band(pts, width, [(4, (150, 110, 62)), (0, (206, 164, 104))])
        self.speckle(pts, width - 6, [(184, 142, 86), (226, 190, 132), (170, 128, 78)], 0.05)

    def cobble_path(self, pts, width):
        self.band(pts, width, [(4, (96, 96, 92)), (0, (170, 168, 160))])
        m = Image.new("L", (self.w, self.h), 0)
        ImageDraw.Draw(m).line(self.P(pts), fill=255, width=max(1, round((width - 4) / LOW)), joint="curve")
        mp = m.load()
        for _ in range(int(self.w * self.h * 0.03)):     # stones: light tops with a dark lower edge
            x, y = self.rnd.randrange(1, self.w - 3), self.rnd.randrange(1, self.h - 2)
            if mp[x, y] and mp[x + 2, y + 1]:
                self.d.rectangle((x, y, x + 2, y + 1), fill=self.rnd.choice([(190, 188, 180), (150, 148, 140), (200, 196, 186)]))
                self.d.line((x, y + 2, x + 2, y + 2), fill=(118, 116, 110))

    def river(self, pts, width):
        self.band(pts, width, [(10, (58, 98, 44)), (5, (120, 170, 190)), (0, (64, 140, 206))])
        self.wd.line(self.P(pts), fill=255, width=max(1, round(width / LOW)), joint="curve")
        self.ripples(pts, width)

    def ripples(self, pts, width):
        m = Image.new("L", (self.w, self.h), 0)
        ImageDraw.Draw(m).line(self.P(pts), fill=255, width=max(1, round((width - 12) / LOW)), joint="curve")
        mp = m.load()
        for _ in range(int(self.w * self.h * 0.012)):
            x, y = self.rnd.randrange(self.w - 4), self.rnd.randrange(self.h)
            if mp[x, y] and mp[x + 3, y]:
                self.d.line((x, y, x + self.rnd.randint(2, 4), y), fill=(150, 205, 235))

    def pond(self, cx, cy, rx, ry):
        box = lambda g: ((cx - rx - g) / LOW, (cy - ry - g / 2) / LOW, (cx + rx + g) / LOW, (cy + ry + g / 2) / LOW)
        self.d.ellipse(box(10), fill=(58, 98, 44))
        self.d.ellipse(box(5), fill=(120, 170, 190))
        self.d.ellipse(box(0), fill=(64, 140, 206))
        self.wd.ellipse(box(0), fill=255)
        for _ in range(int(rx * ry / 120)):
            a, r = self.rnd.random() * 6.28, self.rnd.random() * 0.8
            x, y = (cx + math.cos(a) * rx * r) / LOW, (cy + math.sin(a) * ry * r) / LOW
            self.d.line((x, y, x + 3, y), fill=(150, 205, 235))
        for _ in range(int(rx / 18)):                    # lily pads
            a, r = self.rnd.random() * 6.28, 0.3 + self.rnd.random() * 0.5
            x, y = (cx + math.cos(a) * rx * r) / LOW, (cy + math.sin(a) * ry * r) / LOW
            self.d.ellipse((x - 2, y - 1, x + 2, y + 1), fill=(84, 160, 70))

    def sea(self, poly, beach):
        self.d.polygon(self.P(beach), fill=(232, 212, 160))
        self.d.polygon(self.P(poly), fill=(52, 128, 196))
        self.wd.polygon(self.P(poly), fill=255)
        xs = [p[0] for p in poly]; ys = [p[1] for p in poly]
        m = Image.new("L", (self.w, self.h), 0); ImageDraw.Draw(m).polygon(self.P(poly), fill=255); mp = m.load()
        for _ in range(int(self.w * self.h * 0.02)):
            x, y = self.rnd.randrange(self.w - 5), self.rnd.randrange(self.h)
            if mp[x, y] and mp[x + 4, y]:
                self.d.line((x, y, x + self.rnd.randint(2, 5), y), fill=(120, 185, 230))

    def area(self, poly, fill, edge):
        self.d.polygon(self.P(poly), fill=fill, outline=edge)

    def blob(self, cx, cy, rx, ry, fill, edge):
        self.d.ellipse(((cx - rx) / LOW, (cy - ry) / LOW, (cx + rx) / LOW, (cy + ry) / LOW), fill=fill, outline=edge)

    def soil_tile(self, i, j, wet=False):
        pts = self.P(diamond(i, j))
        self.d.polygon(pts, fill=(98, 64, 38) if not wet else (84, 70, 48), outline=(64, 40, 22))
        # furrows along the tile's long axis
        (tx, ty), (rx, ry), (bx, by), (lx, ly) = pts
        for k in range(1, 5):
            f = k / 5
            a = (lx + (tx - lx) * f, ly + (ty - ly) * f); b = (bx + (rx - bx) * f, by + (ry - by) * f)
            self.d.line((a, b), fill=(76, 48, 28))

    def paddy_tile(self, i, j):
        pts = self.P(diamond(i, j, -3))
        self.d.polygon(self.P(diamond(i, j)), fill=(150, 120, 74))         # earthen dike
        self.d.polygon(pts, fill=(96, 150, 170))
        self.wd.polygon(pts, fill=255)
        (tx, ty), (rx, ry), (bx, by), (lx, ly) = pts
        for a in range(1, 7):
            for b in range(1, 5):
                fa, fb = a / 7, b / 5
                x = lx + (tx - lx) * fb + (bx - lx) * fa; y = ly + (ty - ly) * fb + (by - ly) * fa
                self.d.line((x, y, x, y - 2), fill=(90, 170, 70))

    def bridge(self, x, y, length, angle_deg):
        a = math.radians(angle_deg); dx, dy = math.cos(a), math.sin(a) * 0.5
        nx, ny = -dy, dx
        hw = 26
        for k in range(-int(length / 2), int(length / 2), 7):
            cx, cy = x + dx * k, y + dy * k
            plank = [(cx + nx * hw, cy + ny * hw), (cx - nx * hw, cy - ny * hw),
                     (cx - nx * hw + dx * 6, cy - ny * hw + dy * 6), (cx + nx * hw + dx * 6, cy + ny * hw + dy * 6)]
            self.d.polygon(self.P(plank), fill=(150, 100, 56), outline=(92, 60, 32))
        # the deck is not water: the living painting's ripples (the mask) stop at its edges, so the planks stay still
        a0, a1, w = -length / 2 - 4, length / 2 + 10, hw + 4
        deck = [(x + dx * a0 + nx * w, y + dy * a0 + ny * w), (x + dx * a0 - nx * w, y + dy * a0 - ny * w),
                (x + dx * a1 - nx * w, y + dy * a1 - ny * w), (x + dx * a1 + nx * w, y + dy * a1 + ny * w)]
        self.wd.polygon(self.P(deck), fill=0)

    def save(self, path, mask_path):
        big = self.img.resize((self.w * LOW, self.h * LOW), Image.NEAREST).crop((0, 0, MAP_W, MAP_H))
        big.save(path)
        # living-painting mask: G = water (ripples + glints); everything else still
        wm = self.water.resize((self.w * LOW, self.h * LOW), Image.NEAREST).crop((0, 0, MAP_W, MAP_H))
        wm = wm.filter(ImageFilter.GaussianBlur(2)).resize((MAP_W // 2, MAP_H // 2), Image.BILINEAR)
        z = Image.new("L", wm.size, 0)
        Image.merge("RGBA", (z, wm, z, z)).save(mask_path)
        return big


# ---------------------------------------------------------------------------------------------- layout helpers
class Layout:
    def __init__(self, loc, grass, seed):
        self.loc = loc
        self.g = Ground(grass, seed)
        self.rnd = random.Random(seed + 1)
        self.objects = []          # {s, x, y, flip, spin, squash, sway, depth}
        self.villagers = []
        self.walkers = []
        self.markers = {}
        self.chimneys, self.windows, self.flowers, self.fireflies = [], [], [], []
        self.home = (300, 470)
        self.paths = []            # every path drawn on the ground: the village walkers' network
        self.views = []            # extra places worth stopping at (bridges, the shore)
        self.farmhand = None       # {home: house sprite, approach: [points from its door to the field]}

    def path(self, kind, pts, width):
        """Draws a dirt or cobble path and remembers it, so villagers walk where the paths are."""
        getattr(self.g, kind + "_path")(pts, width)
        self.paths.append(pts)

    def add(self, s, x, y, flip=False, sway=None, spin=0.0, squash=1.0, depth=None, tilt=0.0):
        if sway is None:
            sway = 1.0 if s in TREES else 0.0
        self.objects.append(dict(s=s, x=round(x, 1), y=round(y, 1), flip=flip, sway=sway, spin=spin, squash=squash,
                                 tilt=round(tilt, 2), depth=round(y if depth is None else depth, 1)))

    def wall_wheel(self, house, axle, spin, wall_slope=0.45, across=0.5):
        """A water wheel mounted on a house wall that runs up-right at wall_slope (screen dy/dx).

        The wheel sprite is drawn face-on; laying it flat against the wall is the affine map M = [along-wall, up]
        (along-wall foreshortened to `across`). Its SVD M = R(tilt) * diag(squash, 1) * R(any) is exactly what the
        game can draw: the holder rotates by tilt, squashes, and the spinning child supplies the last rotation.
        `axle` is where the axle box is painted on the house, in map px from the house's foot (x right, y up).
        """
        h = next(o for o in self.objects if o["s"] == house)
        b = math.atan(wall_slope)
        a, c = across * math.cos(b), across * math.sin(b)          # M = [[a, 0], [c, 1]] (y up)
        p, q = a * a + c * c, c                                    # M^T M = [[p, q], [q, 1]]
        tr, det = p + 1, p - q * q
        l1 = tr / 2 + math.sqrt(tr * tr / 4 - det); l2 = tr - l1
        vx, vy = q, l1 - p; n = math.hypot(vx, vy); vx, vy = vx / n, vy / n
        major = math.degrees(math.atan2(c * vx + vy, a * vx))      # direction of M v1, the long axis
        x = h["x"] + axle[0] + 14                                   # +14, +7: out along the wall's normal, so the
        y = h["y"] - axle[1] + 7                                    # wheel turns in the water beside the wall
        self.add("wheel", x, y, spin=spin, squash=math.sqrt(l2 / l1), tilt=major - 90, depth=h["y"] + 1)

    def scatter(self, names, box, n, avoid=(), min_gap=40):
        x0, y0, x1, y1 = box
        placed = 0; tries = 0
        while placed < n and tries < n * 40:
            tries += 1
            x, y = self.rnd.uniform(x0, x1), self.rnd.uniform(y0, y1)
            if any(ax0 <= x <= ax1 and ay0 <= y <= ay1 for ax0, ay0, ax1, ay1 in avoid):
                continue
            if any(abs(o["x"] - x) < min_gap and abs(o["y"] - y) < min_gap * 0.6 for o in self.objects):
                continue
            self.add(self.rnd.choice(names), x, y, flip=self.rnd.random() < 0.5)
            placed += 1

    def fence_line(self, a, b, flip, piece="fence"):
        """Fence pieces from a to b (both map px); flip for the up-right direction."""
        n = max(1, round(math.dist(a, b) / 58))
        for k in range(n):
            f = (k + 0.5) / n
            x, y = a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f
            self.add(piece, x, y + 20, flip=flip, depth=y)

    def villager(self, name, x, y, h, pace="Chat", night=True, depth=0, flip=False):
        """depth: draw order when it differs from the feet (0 = by the feet); flip: faces left instead of right."""
        self.villagers.append(dict(name=name, x=x, y=y, height=h, pace=pace, nightOwl=night, depth=depth, flip=flip))

    def bench_sitter(self, x, y):
        """A bench with the seated villager on it: the bench sorts behind her so she sits on the seat, not inside it."""
        self.add("bench", x, y, depth=y - 14)
        self.villager("bench_sitter", x + 2, y - 8, 54)

    FEAST_FRONT = (("feast_grey", -80, 22, 60), ("feast_top", -27, 34, 50), ("feast_brown", 27, 38, 50), ("feast_red", 80, 28, 62))

    def feast_seats(self, tx, ty, back):
        """Four guests on stools along the long table's open front (the high back edge would hide anyone sitting there),
        plus the one at the low back corner (`back`, map px), whose head shows above the table."""
        for name, dx, dy, h in self.FEAST_FRONT:
            self.add("stool", tx + dx, ty + dy + 2)
            self.villager(name, tx + dx, ty + dy, h)
        self.add("stool", back[0], back[1] + 2)

    def campfire(self, x, y):
        """The stone-ringed fire villagers gather round on some evenings; (x, y) is the centre of the fire bed, where
        the game draws the flames (the piece's foot is 13.5 map px below it). People round it sort by their feet."""
        self.add("campfire", x, y + 13.5, depth=y)

    def walker(self, who, route, height=1.0):
        self.walkers.append(dict(who=who, height=height, route=[dict(x=x, y=y) for x, y in route]))

    def field_edges(self, piece):
        """The field's two back edges: Baguio's dry-stone wall, Ilocos's bamboo fence, Davao's coconut logs."""
        top, right, bottom, left = diamond(0, 0)[0], diamond(3, 0)[1], diamond(3, 2)[2], diamond(0, 2)[3]
        self.fence_line((top[0] + 8, top[1] - 6), (right[0] + 18, right[1] - 2), flip=False, piece=piece)
        self.fence_line((left[0] - 14, left[1] + 6), (top[0] - 8, top[1] - 6), flip=True, piece=piece)

    def plots_frame(self, ground_col=(176, 136, 84), edge=(126, 92, 52)):
        """Frame under the 12 plots (each location's field has its own rim and edging, see field_edges)."""
        top, right, bottom, left = diamond(0, 0)[0], diamond(3, 0)[1], diamond(3, 2)[2], diamond(0, 2)[3]
        grow = 16
        frame = [(top[0], top[1] - grow / 2), (right[0] + grow, right[1]), (bottom[0], bottom[1] + grow / 2), (left[0] - grow, left[1])]
        self.g.area(frame, ground_col, edge)
        return frame


TREES = {"oak", "pine", "fruit_tree", "pine_small", "bush_big", "bush", "bush_pink", "bush_yellow", "coconut", "banana",
         "mango", "cacao", "durian", "bamboo", "pineapple", "cabbage", "strawberry", "carrot_top"}


# where smoke and window light come from on each building: (dx, dy) as fractions of the drawn (w, h), from the foot
BUILDING_POINTS = {
    "farmhouse": {"chimney": [(0.30, 0.93)], "windows": [(0.12, 0.30)], "lamps": [(-0.285, 0.31)]},
    "barn": {"windows": [(0.05, 0.62), (0.28, 0.30)], "lamps": [(-0.13, 0.44)]},
    "millhouse": {"chimney": [(0.12, 0.95)], "windows": [(-0.12, 0.32)], "lamps": [(-0.06, 0.36)]},
    "store": {"windows": [(0.10, 0.36)]},
    "kubo": {"windows": [(0.05, 0.45)], "lamps": [(-0.12, 0.60)]},
    "shed": {"lamps": [(-0.14, 0.52)]},
}
# lamps: a lantern on the wall beside each door (beside the doorway, never in it), lit from dusk to dawn


# Doors, as fractions of the house's drawn (w, h) from its foot (x right, y up). A visitor stands on the doorstep (`out`, map px
# from the door) and goes in along `entry`, drawn behind the house, so the house itself hides them: nobody fades in or out.
# The kubo is on stilts: in is up the ladder and through the doorway on the porch.
DOORS = {
    "farmhouse": dict(door=(-0.167, 0.118), out=(-7, 8), entry=[(-0.167, 0.118), (-0.11, 0.16)]),
    "millhouse": dict(door=(-0.15, 0.13), out=(-7, 8), entry=[(-0.15, 0.13), (-0.09, 0.17)]),
    "barn": dict(door=(-0.30, 0.148), out=(-8, 9), entry=[(-0.30, 0.148), (-0.24, 0.19)]),
    "shed": dict(door=(-0.30, 0.06), out=(-6, 7), entry=[(-0.30, 0.06), (-0.22, 0.12)]),
    "kubo": dict(door=(-0.241, 0.034), out=(-6, 8), entry=[(-0.241, 0.034), (-0.156, 0.22), (-0.116, 0.36), (-0.06, 0.40)]),
}


# field workers who walk between the plants in their patch (Tools/slice_walk.py walk_{name}_se/_ne): how big their walk
# frames are drawn relative to the work frames, matched by head size
WORKER_WALK = {"waterer_top": 0.92, "waterer_cab": 0.89, "harvester": 0.84, "hoer": 1.0, "plank_man": 1.0}
CROPS = {"cabbage", "strawberry", "carrot_top", "pineapple"}


def worker_patches(L, objs):
    """Work spots for each walking worker: beside the crops around them, so the crop sits where the can, basket or hoe
    lands (in front of them); with no crops about, a few steps around where they stand. A spot is only used if nothing
    in front of it (a tree, a well, a trough) would cover the worker standing there."""
    def clear(x, y, h):
        body = (x - 14, y - h, x + 14, y)
        for o in objs:
            if o["s"] in CROPS or o["s"] == "stool" or o["depth"] <= y: continue
            w, oh = o["w"], o["h"]
            box = (o["x"] - w / 2, o["y"] - oh / 2, o["x"] + w / 2, o["y"] + oh / 2) if o["spin"] else (o["x"] - w / 2, o["y"] - oh, o["x"] + w / 2, o["y"])
            if box[0] < body[2] and box[2] > body[0] and box[1] < body[3] and box[3] > body[1]: return False
        return True

    for v in L.villagers:
        if v["name"] not in WORKER_WALK: continue
        side = 1 if v.get("flip") else -1                  # facing right, they stand up-left of the plant
        h = v["height"]
        near = sorted((o for o in objs if o["s"] in CROPS and math.dist((o["x"], o["y"]), (v["x"], v["y"])) < 110),
                      key=lambda o: math.dist((o["x"], o["y"]), (v["x"], v["y"])))
        pts = [(v["x"], v["y"])]
        for o in near:
            p = (o["x"] + side * 18, o["y"] - 4)
            if all(math.dist(p, q) > 24 for q in pts) and clear(*p, h): pts.append(p)
            if len(pts) >= 7: break
        if len(pts) < 3:
            r = 32 if v["name"] == "plank_man" else 40
            for dx, dy in ((-r, r / 2), (r, r / 2), (-r, -r / 2), (r, -r / 2), (0, r), (0, -r), (-r * 1.4, 0), (r * 1.4, 0)):
                p = (v["x"] + dx, v["y"] + dy)
                if clear(*p, h) and all(math.dist(p, q) > 24 for q in pts): pts.append(p)
                if len(pts) >= 4: break
        v["walk"] = [dict(x=round(x, 1), y=round(y, 1)) for x, y in pts]
        v["walkScale"] = WORKER_WALK[v["name"]]


# farm animals walk about their patch by day and sleep there at night (Client/Animals.cs): how far each kind roams (map px)
ANIMALS = {"deer": 90, "goat": 70, "chicken": 55, "hen": 55, "cat": 110, "carabao": 60, "duck": 30, "swan": 34}
WATER_BIRDS = {"duck", "swan"}
BLOCKERS = {"farmhouse", "barn", "store", "millhouse", "shed", "kubo", "well", "feast_table", "side_table", "turbine", "trough",
            "board", "bench", "garlic_rack", "jars", "straw", "hay", "hay2", "crate", "barrel", "boulder", "rocks", "sign",
            "scarecrow", "campfire", "stool", "oak", "pine", "pine_small", "fruit_tree", "coconut", "mango", "durian", "cacao",
            "banana", "bamboo", "bush_big"}


def animal_roams(L, objs):
    """Takes the animals out of the static objects and gives each the places it wanders between: on dry land clear of
    buildings, props, tree trunks and the field (or, for ducks and swans, on the water), around where it was placed."""
    water = L.g.water
    def wet(x, y):
        xi, yi = int(x / LOW), int(y / LOW)
        return 0 <= xi < water.width and 0 <= yi < water.height and water.getpixel((xi, yi)) > 0
    top, right, bottom, left = diamond(0, 0)[0], diamond(3, 0)[1], diamond(3, 2)[2], diamond(0, 2)[3]
    field = [(top[0], top[1] - 30), (right[0] + 40, right[1]), (bottom[0], bottom[1] + 30), (left[0] - 40, left[1])]
    def in_field(x, y):
        inside = False
        for (x1, y1), (x2, y2) in zip(field, field[1:] + field[:1]):
            if (y1 > y) != (y2 > y) and x < x1 + (y - y1) * (x2 - x1) / (y2 - y1): inside = not inside
        return inside
    def blocked(x, y):
        for o in objs:
            if o["s"] not in BLOCKERS: continue
            if o["s"] in ("farmhouse", "barn", "store", "millhouse", "shed", "kubo", "feast_table", "turbine"):
                if o["x"] - o["w"] / 2 - 10 < x < o["x"] + o["w"] / 2 + 10 and o["y"] - o["h"] * 0.4 < y < o["y"] + 12: return True
            elif math.dist((x, y), (o["x"], o["y"])) < 22: return True
        return False
    animals, keep = [], []
    for o in objs:
        if o["s"] not in ANIMALS: keep.append(o); continue
        R, swim = ANIMALS[o["s"]], o["s"] in WATER_BIRDS
        def ok(x, y):
            if not (20 < x < MAP_W - 20 and 40 < y < MAP_H - 10): return False
            if swim: return all(wet(x + dx, y + dy) for dx, dy in ((0, 0), (12, 0), (-12, 0), (0, 6), (0, -6)))
            return not wet(x, y) and not wet(x, y + 6) and not in_field(x, y) and not blocked(x, y)
        pts = [(o["x"], o["y"])]
        for f in (0.45, 0.8, 1.0):
            for k in range(9):
                a = k * math.tau / 9 + f * 1.7
                x, y = o["x"] + math.cos(a) * R * f, o["y"] + math.sin(a) * R * f * 0.55
                if ok(x, y) and all(math.dist((x, y), q) > 16 for q in pts): pts.append((x, y))
        animals.append(dict(kind=o["s"], x=o["x"], y=o["y"], w=o["w"], h=o["h"], flip=o["flip"], swim=swim,
                            roam=[dict(x=round(x, 1), y=round(y, 1)) for x, y in pts[:10]]))
    objs[:] = keep
    return animals


def village_spots(L, objs):
    """Places the village walkers visit: house doors, the store counter, the notice board, benches, the well, views."""
    spots, counts = [], {}

    def add(kind, base, x, y, **extra):
        k = counts.get(base, 0); counts[base] = k + 1
        spots.append(dict(kind=kind, name=f"{base}_{k}", x=round(x, 1), y=round(y, 1), **extra))

    for o in objs:
        s, w, h, sx = o["s"], o["w"], o["h"], -1 if o["flip"] else 1
        if s in DOORS:
            d = DOORS[s]
            dx, dy = o["x"] + sx * d["door"][0] * w, o["y"] - d["door"][1] * h
            add("door", s, dx + sx * d["out"][0], dy + d["out"][1], depth=o["depth"] - 1,
                entry=[dict(x=round(o["x"] + sx * fx * w, 1), y=round(o["y"] - fy * h, 1)) for fx, fy in d["entry"]])
        elif s == "store": add("store", s, o["x"] - 0.45 * w, o["y"] + 26)      # a customer's spot, clear of the vendors
        elif s == "board": add("board", s, o["x"] + 4, o["y"] + 20)
        elif s == "bench": add("bench", s, o["x"] + 36, o["y"] + 8)
        elif s == "well": add("well", s, o["x"] + 42, o["y"] + 6)
        elif s == "campfire": add("campfire", s, o["x"], o["depth"])           # the centre of the fire
    for x, y in L.views: add("view", "view", x, y)
    return spots


def paths_preview(L, spots, farmhand, src, out):
    """The village network drawn over the map preview: paths, stopping places, doorways and the farmhand's route."""
    img = Image.open(src).convert("RGB"); d = ImageDraw.Draw(img)
    for pts in L.paths: d.line([tuple(p) for p in pts], fill=(255, 230, 0), width=3)
    for sp in spots:
        x, y = sp["x"], sp["y"]
        d.ellipse((x - 7, y - 7, x + 7, y + 7), outline=(255, 0, 255), width=3); d.text((x + 9, y - 6), sp["name"], fill=(255, 255, 255))
        if sp.get("entry"):
            d.line([(x, y)] + [(e["x"], e["y"]) for e in sp["entry"]], fill=(0, 255, 255), width=2)
    for v in L.villagers:
        if v.get("walk"):
            pts = [(p["x"], p["y"]) for p in v["walk"]]
            d.line(pts + [pts[0]], fill=(0, 200, 255), width=2)
            for x, y in pts: d.ellipse((x - 3, y - 3, x + 3, y + 3), fill=(0, 200, 255))
    if farmhand:
        home = next(sp for sp in spots if sp["name"] == farmhand["home"])
        d.line([(home["x"], home["y"])] + [(p["x"], p["y"]) for p in farmhand["approach"]], fill=(255, 80, 0), width=3)
    img.save(out)


# ---------------------------------------------------------------------------------------------- Baguio
def baguio():
    L = Layout("baguio", [(104, 168, 64), (96, 158, 58), (114, 176, 70), (78, 132, 48)], 11)
    g = L.g
    river = [(1720, 250), (1560, 290), (1380, 330), (1240, 380), (1140, 440), (1080, 530), (1030, 630), (950, 735),
             (820, 815), (640, 868), (430, 902), (220, 940), (120, 960)]
    track = [(600, -10), (606, 110), (650, 210), (690, 300)]
    cobble = [(690, 312), (790, 360), (900, 392), (1010, 420), (1110, 452), (1210, 498), (1300, 548), (1380, 590)]
    store_path = [(1205, 498), (1188, 590), (1196, 690), (1232, 752)]
    road = [(1720, 870), (1560, 812), (1420, 818), (1300, 848), (1240, 860)]
    g.blob(1410, 618, 130, 52, (196, 156, 98), (150, 110, 62))           # barn yard
    g.blob(1210, 252, 150, 62, (122, 180, 76), None)                     # feast lawn, a lighter green
    L.path("dirt", track, 44); L.path("dirt", road, 50)
    L.path("cobble", cobble, 46); L.path("cobble", store_path, 40)
    g.river(river, 64)
    g.bridge(1112, 452, 120, 20); L.views.append((1112, 452))
    g.pond(150, 805, 105, 56)
    L.plots_frame((122, 118, 108), (84, 80, 72))                         # terrace stones round the field
    # fields: cabbage + strawberries by the farmhouse, tomatoes/carrots by the pond
    f1 = [(i, j) for i in range(6, 9) for j in range(-4, -2)]
    f2 = [(i, j) for i in range(5, 8) for j in range(4, 6)]
    for i, j in f1 + f2:
        g.soil_tile(i, j)
    for k, (i, j) in enumerate(f1):
        x, y = tile(i, j)
        for dx, dy in ((-22, 0), (0, -11), (0, 11), (22, 0)):
            L.add("cabbage" if (i + j) % 2 else "strawberry", x + dx, y + dy + 8)
    for i, j in f2:
        x, y = tile(i, j)
        for dx, dy in ((-20, 0), (0, -10), (0, 10), (20, 0)):
            L.add("carrot_top", x + dx, y + dy + 8)

    # buildings
    L.add("farmhouse", 700, 312); L.add("shed", 548, 238)
    L.add("barn", 1452, 598); L.add("store", 1272, 806)
    L.add("millhouse", 898, 711); L.wall_wheel("millhouse", (46.7, 52.0), spin=40)
    # gathering lawn
    L.add("feast_table", 1205, 262); L.add("side_table", 1322, 252)
    L.feast_seats(1205, 262, (1252, 226))
    L.add("board", 1075, 215); L.add("pot_plant", 1335, 205); L.add("pot_plant", 1092, 285)
    # fences around the plots, hay, scarecrows, benches, crates
    top, right, bottom, left = diamond(0, 0)[0], diamond(3, 0)[1], diamond(3, 2)[2], diamond(0, 2)[3]
    L.field_edges("stone_wall")
    L.add("hay", 582, 560); L.add("hay2", 620, 585); L.add("hay", 1350, 650); L.add("hay2", 1520, 640)
    L.add("scarecrow", 1010, 520); L.add("scarecrow", 470, 640)
    L.bench_sitter(300, 868); L.add("bench", 1132, 790); L.add("bench", 960, 380)
    L.add("crate", 1340, 845); L.add("crate", 1312, 860); L.add("barrel", 1520, 590); L.add("barrel", 1540, 605)
    L.add("trough", 1330, 610); L.add("sign", 1000, 455); L.add("boulder", 760, 760); L.add("rocks", 1180, 395)
    L.add("well", 615, 360)
    # animals
    L.add("deer", 1620, 345); L.add("goat", 1380, 655); L.add("chicken", 790, 338); L.add("hen", 818, 352)
    L.add("chicken", 770, 352); L.add("cat", 1225, 810)
    L.add("swan", 140, 800, sway=0.6); L.add("duck", 205, 815, sway=0.6)
    # trees: forest along the top, left and right edges, a few in the middle
    L.scatter(["pine", "pine", "oak", "pine_small"], (20, 30, 520, 150), 9, min_gap=55)
    L.scatter(["pine", "oak", "pine_small", "fruit_tree"], (700, 30, 1100, 160), 6, avoid=[(640, 160, 760, 330)], min_gap=55)
    L.scatter(["pine", "pine_small", "oak"], (1380, 30, 1690, 230), 6, min_gap=55)
    L.scatter(["pine", "pine_small"], (10, 200, 60, 900), 7, min_gap=60)
    L.scatter(["pine", "oak", "pine_small"], (1580, 420, 1690, 800), 5, min_gap=55)
    L.add("fruit_tree", 860, 260); L.add("fruit_tree", 470, 200); L.add("oak", 700, 650)
    L.scatter(["bush", "bush_big", "bush_pink", "bush_yellow"], (60, 160, 1650, 930), 22,
              avoid=[(60, 330, 640, 600), (720, 380, 1060, 600), (180, 600, 520, 790), (1050, 160, 1360, 320),
                     (1300, 520, 1560, 700), (1150, 700, 1360, 900), (1020, 400, 1230, 760), (40, 720, 280, 900),
                     (600, 230, 900, 330)], min_gap=60)

    # villagers in context (feet in map px)
    L.villager("waterer_top", 846, 470, 66, "Work", False); L.villager("harvester", 930, 520, 68, "Work", False)
    L.villager("crate_kid", 955, 484, 52, "Work", False)
    L.villager("hoer", 400, 690, 66, "Work", False); L.villager("waterer_cab", 300, 702, 66, "Work", False)
    L.villager("hay_girl", 640, 548, 72, "Chat", False); L.villager("plank_man", 600, 268, 72, "Work", False)
    L.villager("feast_back", 1252, 226, 58); L.villager("feast_tray", 1050, 262, 66)
    L.villager("path_lady", 880, 398, 68); L.villager("path_man", 922, 402, 68)
    L.villager("barn_basket", 1360, 628, 68); L.villager("barn_boy", 1398, 642, 68)
    L.villager("barn_back", 1440, 628, 64); L.villager("barn_lola", 1476, 640, 64)
    L.villager("store_overalls", 1196, 790, 64, depth=808); L.villager("store_purple", 1238, 812, 64)
    L.villager("road_man", 1490, 818, 68); L.villager("road_lady", 1530, 812, 68)
    # walkers
    L.walker("farmer", [(694, 318), (790, 362), (900, 394), (1010, 422), (1110, 454), (1210, 500), (1300, 552)])
    L.walker("woman", [(1206, 504), (1188, 592), (1196, 690), (1226, 748)], 0.97)
    L.walker("lola", [(1700, 866), (1560, 814), (1420, 820), (1310, 846)], 0.88)
    L.walker("boy", [(602, 20), (606, 110), (648, 208), (684, 296)], 0.78)
    L.markers = {"npc": (1160, 712), "gathering": (1062, 180)}
    L.farmhand = dict(home="farmhouse", approach=[(664, 352), (566, 428)])
    L.paths.append([(1232, 752), (1180, 800), (1240, 858)])   # not drawn: round the store to the road below
    L.campfire(200, 280)          # the lawn above the field, in view of the farm (the location label hides the lower clearing)
    L.paths.append([(652, 222), (590, 252), (505, 252), (390, 268), (300, 278)])   # not drawn: past the shed's doorstep to the campfire
    L.fireflies = [(150, 760), (400, 640), (900, 620), (1550, 760), (1300, 420), (700, 870)]
    return L


# ---------------------------------------------------------------------------------------------- Ilocos Norte
def ilocos():
    L = Layout("ilocos", [(152, 170, 76), (142, 160, 68), (164, 180, 88), (118, 132, 52)], 23)
    g = L.g
    g.sea([(1060, -10), (1720, -10), (1720, 470), (1560, 395), (1380, 258), (1210, 126)],
          [(980, -10), (1720, -10), (1720, 560), (1520, 455), (1320, 305), (1140, 150)])
    track = [(600, -10), (610, 120), (652, 214), (690, 296)]
    road = [(700, 318), (830, 380), (980, 440), (1140, 512), (1290, 590), (1440, 640), (1720, 664)]
    lane = [(1140, 512), (1110, 640), (1130, 760), (1200, 830)]
    L.path("dirt", track, 44); L.path("dirt", road, 54); L.path("dirt", lane, 42)
    g.blob(1240, 790, 150, 58, (214, 184, 126), (170, 140, 90))          # village square
    L.plots_frame((214, 188, 136), (170, 142, 96))                       # sand
    for i in range(7, 11):
        for j in range(-2, 1):
            g.paddy_tile(i, j)
    for i in range(5, 8):
        for j in range(4, 6):
            g.soil_tile(i, j)
            x, y = tile(i, j)
            for dx, dy in ((-20, 0), (0, -10), (0, 10), (20, 0)):
                L.add("carrot_top", x + dx, y + dy + 8)

    L.add("kubo", 700, 300); L.add("kubo", 1350, 720); L.add("store", 1236, 860)
    for k, (x, y) in enumerate(((1170, 214), (1352, 332), (1548, 470))):
        L.add("turbine", x, y)
        L.add("rotor", x, y - 236, spin=-60 - k * 7, depth=y + 1)
    L.add("well", 600, 610)
    L.add("feast_table", 980, 800); L.add("side_table", 1090, 812)
    L.feast_seats(980, 800, (1030, 768))
    L.add("board", 860, 760)
    L.add("garlic_rack", 560, 280); L.add("garlic_rack", 820, 300); L.add("jars", 760, 330); L.add("jars", 1420, 760)
    L.add("straw", 1080, 610); L.add("straw", 620, 700); L.add("straw", 1460, 600)
    top, right, bottom, left = diamond(0, 0)[0], diamond(3, 0)[1], diamond(3, 2)[2], diamond(0, 2)[3]
    L.field_edges("bamboo_fence")
    L.bench_sitter(1180, 740); L.add("crate", 1300, 880); L.add("barrel", 1420, 800); L.add("trough", 860, 680)
    L.add("rocks", 1000, 300); L.add("boulder", 380, 760); L.add("sign", 680, 380)
    L.add("carabao", 880, 700); L.add("goat", 1200, 650); L.add("chicken", 780, 350); L.add("hen", 640, 330)
    L.add("cat", 1250, 870)
    L.add("coconut", 1060, 230); L.add("coconut", 1120, 320); L.add("coconut", 1500, 560); L.add("coconut", 1640, 610)
    L.add("mango", 420, 180); L.add("mango", 880, 160); L.add("bamboo", 40, 320)
    L.scatter(["bush", "bush_big", "bush_yellow", "oak"], (20, 20, 1000, 200), 9, avoid=[(560, 0, 760, 330)], min_gap=60)
    L.scatter(["bush", "bush_big", "bush_yellow", "bush_pink"], (20, 600, 1700, 940), 12,
              avoid=[(180, 600, 520, 790), (560, 560, 700, 740), (820, 730, 1140, 880), (1080, 480, 1180, 900),
                     (1150, 700, 1480, 940), (620, 480, 1060, 760)], min_gap=60)
    L.scatter(["bush", "bamboo", "mango"], (10, 200, 70, 900), 5, min_gap=60)

    L.villager("waterer_top", 760, 600, 66, "Work", False); L.villager("harvester", 900, 610, 68, "Work", False)
    L.villager("waterer_cab", 820, 660, 66, "Work", False)
    L.villager("hoer", 400, 690, 66, "Work", False); L.villager("crate_kid", 330, 700, 52, "Work", False)
    L.villager("hay_girl", 660, 712, 72, "Chat", False); L.villager("plank_man", 610, 300, 72, "Work", False)
    L.villager("feast_back", 1030, 768, 58); L.villager("feast_tray", 1120, 790, 66)
    L.villager("path_lady", 940, 430, 68); L.villager("path_man", 982, 438, 68)
    L.villager("barn_basket", 1290, 760, 68); L.villager("barn_boy", 1330, 772, 68)
    L.villager("barn_back", 1460, 700, 64); L.villager("barn_lola", 1496, 712, 64)
    L.villager("store_overalls", 1180, 852, 64, depth=862); L.villager("store_purple", 1290, 880, 64)
    L.villager("road_man", 1560, 650, 68); L.villager("road_lady", 1600, 652, 68)
    L.walker("farmer", [(704, 322), (830, 382), (980, 442), (1140, 514), (1290, 592), (1430, 640)])
    L.walker("woman", [(1140, 516), (1112, 640), (1130, 760), (1196, 826)], 0.97)
    L.walker("lola", [(1700, 664), (1560, 652), (1440, 642)], 0.88)
    L.walker("boy", [(602, 20), (610, 120), (650, 212), (686, 292)], 0.78)
    L.markers = {"npc": (1160, 900), "gathering": (840, 720), "well": (600, 650)}
    L.views.append((1300, 455))   # the sea and the wind turbines
    L.campfire(860, 460)          # on the grass between the road and the rice paddy
    L.farmhand = dict(home="kubo", approach=[(640, 360), (566, 428)])
    L.fireflies = [(400, 640), (900, 560), (1550, 760), (1300, 680), (200, 260), (760, 860)]
    return L


# ---------------------------------------------------------------------------------------------- Davao
def davao():
    L = Layout("davao", [(84, 160, 58), (76, 150, 52), (98, 172, 66), (58, 118, 40)], 37)
    g = L.g
    river = [(1720, 110), (1520, 190), (1340, 300), (1262, 440), (1290, 590), (1420, 740), (1520, 860), (1580, 960)]
    track = [(600, -10), (610, 120), (652, 214), (690, 296)]
    road = [(700, 318), (850, 400), (1010, 470), (1170, 512), (1266, 520), (1400, 548), (1720, 590)]
    lane = [(1010, 470), (980, 600), (1010, 760), (1090, 860)]
    L.path("dirt", track, 44); L.path("dirt", road, 52); L.path("dirt", lane, 40)
    g.river(river, 66)
    g.bridge(1268, 520, 120, 10); L.views.append((1268, 520))
    g.blob(1560, 470, 120, 52, (180, 142, 88), (136, 100, 58))           # yard by the east kubo
    L.plots_frame((104, 78, 46), (76, 56, 32))                           # orchard mulch
    for i in range(6, 9):
        for j in range(-4, -2):
            g.soil_tile(i, j)
            x, y = tile(i, j)
            L.add("pineapple", x, y + 14)
    L.add("kubo", 700, 300); L.add("kubo", 1560, 455); L.add("store", 1110, 878); L.add("shed", 540, 250)
    L.add("feast_table", 1000, 210); L.add("side_table", 1116, 200)
    L.feast_seats(1000, 210, (1050, 174))
    L.add("board", 860, 170)
    top, right, bottom, left = diamond(0, 0)[0], diamond(3, 0)[1], diamond(3, 2)[2], diamond(0, 2)[3]
    L.field_edges("coco_log")
    kinds = ["mango", "cacao", "durian"]                                # orchard rows
    for r, y in enumerate((610, 700, 790)):
        for c, x in enumerate((700, 800, 900)):
            L.add(kinds[(r + c) % 3], x + (r % 2) * 30, y)
    for x, y in ((90, 650), (170, 700), (110, 760), (230, 790), (60, 860), (170, 880), (290, 900)):
        L.add("banana", x, y)
    for x, y in ((1180, 390), (1220, 650), (1360, 860), (1660, 300), (1690, 820), (470, 170), (60, 260), (1440, 960)):
        L.add("coconut", x, y)
    L.add("bamboo", 1330, 200); L.add("bamboo", 1210, 760); L.add("bamboo", 40, 450)
    L.add("hay", 600, 560); L.add("crate", 1170, 900); L.add("barrel", 1060, 900); L.bench_sitter(1060, 440)
    L.add("rocks", 1180, 470); L.add("sign", 1000, 520); L.add("jars", 1640, 520)
    L.add("carabao", 1600, 560); L.add("goat", 1480, 520); L.add("chicken", 780, 340); L.add("hen", 640, 330)
    L.add("duck", 1300, 360, sway=0.6); L.add("duck", 1330, 640, sway=0.6); L.add("cat", 1150, 905)
    L.scatter(["bush", "bush_big", "bush_pink", "bush_yellow"], (20, 20, 1700, 940), 14,
              avoid=[(60, 330, 640, 600), (720, 380, 1060, 600), (640, 540, 960, 830), (850, 140, 1180, 270),
                     (1050, 820, 1260, 940), (1480, 400, 1700, 600), (0, 620, 330, 940), (560, 200, 780, 340)], min_gap=60)

    L.villager("waterer_top", 846, 470, 66, "Work", False); L.villager("harvester", 975, 465, 68, "Work", False)
    L.villager("crate_kid", 760, 845, 52, "Work", False); L.villager("hoer", 805, 500, 66, "Work", False)
    L.villager("waterer_cab", 345, 725, 66, "Work", False, flip=True)      # waters the banana grove on her left
    L.villager("hay_girl", 640, 560, 72, "Chat", False); L.villager("plank_man", 600, 280, 72, "Work", False)
    L.villager("feast_back", 1050, 174, 58); L.villager("feast_tray", 1150, 230, 66)
    L.villager("path_lady", 1400, 556, 68); L.villager("path_man", 1440, 562, 68)
    L.villager("barn_basket", 1500, 500, 68); L.villager("barn_boy", 1540, 512, 68)
    L.villager("barn_back", 1620, 498, 64); L.villager("barn_lola", 1672, 534, 64)
    L.villager("store_overalls", 1060, 870, 64, depth=880); L.villager("store_purple", 1140, 900, 64)
    L.villager("road_man", 1600, 600, 68); L.villager("road_lady", 1640, 604, 68)
    L.walker("farmer", [(704, 322), (850, 402), (1010, 472), (1170, 514), (1266, 522), (1400, 550)])
    L.walker("woman", [(1010, 476), (982, 600), (1010, 760), (1084, 856)], 0.97)
    L.walker("lola", [(1700, 590), (1560, 572), (1420, 552)], 0.88)
    L.walker("boy", [(602, 20), (610, 120), (650, 212), (686, 292)], 0.78)
    L.markers = {"npc": (1040, 830), "gathering": (840, 140)}
    L.campfire(990, 335)          # the clearing between the feast table and the road
    L.farmhand = dict(home="kubo", approach=[(640, 360), (566, 428)])
    L.fireflies = [(200, 720), (800, 700), (1300, 760), (1600, 420), (400, 200), (1100, 600)]
    return L

# ---------------------------------------------------------------------------------------------- export + preview
def load_piece(pieces_dir, name, cache={}):
    if name not in cache:
        src = Image.open(os.path.join(pieces_dir, CATALOGUE[name][0] + ".png")).convert("RGBA")
        cache[name] = (src, piece_size(name, src))
    return cache[name]


def export(L, pieces_dir, assets_dir, preview_dir, art_dir):
    os.makedirs(os.path.join(assets_dir, "Map"), exist_ok=True)
    ground = L.g.save(os.path.join(art_dir, f"ground_{L.loc}.png"), os.path.join(art_dir, f"mask_ground_{L.loc}.png"))

    objs, tree_tops, flowers, chimneys, windows, lamps = [], [], [], [], [], []
    for o in L.objects:
        src, (w, h) = load_piece(pieces_dir, o["s"])
        tex = os.path.join(assets_dir, "Map", o["s"] + ".png")
        if not os.path.exists(tex):
            tw, th = round(w * TEXTURE_SCALE), round(h * TEXTURE_SCALE)
            img = src.resize((tw, th), Image.LANCZOS)
            pad = Image.new("RGBA", ((tw + 3) // 4 * 4, (th + 3) // 4 * 4), (0, 0, 0, 0))
            pad.paste(img, ((pad.width - tw) // 2, pad.height - th))      # padding above and to the sides; feet stay on the bottom edge
            pad.save(tex)
        w2 = math.ceil(w * TEXTURE_SCALE / 4) * 4 / TEXTURE_SCALE; h2 = math.ceil(h * TEXTURE_SCALE / 4) * 4 / TEXTURE_SCALE
        objs.append(dict(o, w=round(w2, 1), h=round(h2, 1)))
        if o["s"] in ("oak", "pine", "fruit_tree", "pine_small", "coconut", "mango", "durian", "bamboo"):
            tree_tops.append(dict(x=o["x"], y=round(o["y"] - h * 0.75, 1)))
        if o["s"] in ("bush_pink", "bush_yellow", "strawberry"):
            flowers.append(dict(x=o["x"], y=round(o["y"] - h * 0.6, 1)))
        for kind, pts in BUILDING_POINTS.get(o["s"], {}).items():
            for fx, fy in pts:
                p = dict(x=round(o["x"] + (-fx if o["flip"] else fx) * w, 1), y=round(o["y"] - fy * h, 1))
                {"chimney": chimneys, "windows": windows, "lamps": lamps}[kind].append(p)

    pts = lambda seq: [dict(x=x, y=y) for x, y in seq]
    spots = village_spots(L, objs)
    worker_patches(L, objs)
    animals = animal_roams(L, objs)
    farmhand = None
    if L.farmhand:
        # his home is the named house nearest the field
        doors = [sp for sp in spots if sp["kind"] == "door" and sp["name"].startswith(L.farmhand["home"] + "_")]
        home = min(doors, key=lambda sp: math.dist((sp["x"], sp["y"]), (400, 450)))
        farmhand = dict(home=home["name"], approach=pts(L.farmhand["approach"]))
    data = dict(ground=f"ground_{L.loc}", mask=f"mask_ground_{L.loc}", objects=objs, villagers=L.villagers,
                walkers=L.walkers, markers=[dict(name=k, x=v[0], y=v[1]) for k, v in L.markers.items()],
                chimneys=chimneys, windows=windows, flowers=flowers, treeTops=tree_tops, fireflies=pts(L.fireflies),
                home=dict(x=L.home[0], y=L.home[1]), paths=[dict(pts=pts(p)) for p in L.paths], spots=spots,
                farmhand=farmhand, animals=animals, lamps=lamps)
    with open(os.path.join(assets_dir, "Map", f"layout_{L.loc}.json"), "w") as f:
        json.dump(data, f, indent=1)
    preview(L, ground, objs, art_dir, os.path.join(preview_dir, f"preview_{L.loc}.png"), pieces_dir)
    paths_preview(L, spots, farmhand, os.path.join(preview_dir, f"preview_{L.loc}.png"), os.path.join(preview_dir, f"paths_{L.loc}.png"))
    print(L.loc, len(objs), "objects,", len(L.villagers), "villagers,", len(L.walkers), "walkers,",
          ", ".join(f"{a['kind']} {len(a['roam'])}" for a in animals))


def preview(L, ground, objs, art_dir, out, pieces_dir):
    img = ground.convert("RGBA")
    tile_img = Image.open(os.path.join(art_dir, f"tile_soil_{L.loc}.png")).convert("RGBA")
    tw, th = round(TW), round(TW * 152 / 256)
    tile_img = tile_img.resize((tw, th), Image.NEAREST)
    for r in range(3):
        for c in range(4):
            x, y = tile(c, r)
            img.alpha_composite(tile_img, (round(x - tw / 2), round(y - TH / 2)))
    draw = []
    for o in objs:
        src, (w, h) = load_piece(pieces_dir, o["s"])
        im = src.resize((round(w), round(h)), Image.LANCZOS)
        if o["flip"]: im = im.transpose(Image.FLIP_LEFT_RIGHT)
        if o["squash"] != 1: im = im.resize((max(1, round(w * o["squash"])), round(h)), Image.LANCZOS)
        if o.get("tilt"): im = im.rotate(o["tilt"], resample=Image.BICUBIC, expand=True)
        if o["spin"]:
            pos = (round(o["x"] - im.width / 2), round(o["y"] - im.height / 2))
        else:
            pos = (round(o["x"] - im.width / 2), round(o["y"] - im.height))
        draw.append((o["depth"], im, pos))
    for v in L.villagers:
        strip = Image.open(os.path.join(art_dir, f"act_{v['name']}.png")).convert("RGBA")
        F = strip.height; fr = strip.crop((0, 0, F, F))
        size = round(v["height"] / 0.7); fr = fr.resize((size, size), Image.LANCZOS)
        if v.get("flip"): fr = fr.transpose(Image.FLIP_LEFT_RIGHT)
        draw.append((v.get("depth") or v["y"], fr, (round(v["x"] - size / 2), round(v["y"] - size + size * 4 / 160))))
    for wk in L.walkers:
        strip = Image.open(os.path.join(art_dir, f"walk_{wk['who']}_se.png")).convert("RGBA")
        F = strip.height; fr = strip.crop((0, 0, F, F))
        size = round(74 * wk["height"] / 0.84); fr = fr.resize((size, size), Image.LANCZOS)
        p = wk["route"][len(wk["route"]) // 2]
        draw.append((p["y"], fr, (round(p["x"] - size / 2), round(p["y"] - size + size * 4 / 144))))
    for d, im, pos in sorted(draw, key=lambda t: t[0]):
        img.paste(im, pos, im)
    dd = ImageDraw.Draw(img)
    for name, (x, y) in L.markers.items():
        dd.ellipse((x - 26, y - 26, x + 26, y + 26), outline=(255, 255, 255), width=4); dd.text((x - 24, y + 28), name, fill=(255, 255, 255))
    img.convert("RGB").save(out)


LAYOUTS = {"baguio": baguio, "ilocos": ilocos, "davao": davao}

if __name__ == "__main__":
    pieces_dir, assets_dir, preview_dir = sys.argv[1:4]
    only = sys.argv[4:] or list(LAYOUTS)
    art_dir = os.path.join(assets_dir, "Art")
    os.makedirs(preview_dir, exist_ok=True)
    for loc in only:
        export(LAYOUTS[loc](), pieces_dir, assets_dir, preview_dir, art_dir)
