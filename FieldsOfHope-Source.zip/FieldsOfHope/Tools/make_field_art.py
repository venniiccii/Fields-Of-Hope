"""
Each location's planting field has its own look (the client noticed every map's field was the same):

  Baguio  dark highland loam on stone-terrace tiles, a dry-stone wall behind, rocks and pine stumps
  Ilocos  sandy soil, a bamboo fence behind, driftwood and dry shrubs
  Davao   orchard grass with a mulch ring for each tree, coconut logs behind, coconut husks and banana stumps

  python -I make_field_art.py <Resources/Art dir> <map pieces dir> [contact sheet png]

Writes tile_{soil,soil_wet,grass}_<loc>.png and obstacle_<kind>.png to Art (pixel art on a 4 px grid, like the
existing tiles and obstacles), and edge_00/01/02.png (stone wall, bamboo fence, coconut log) to the pieces dir for
map_builder.py, which places them where the wooden fence stood. Deterministic: the same input gives the same files.
"""
import math, os, random, sys
from PIL import Image, ImageDraw

PX = 4                                     # every art pixel is 4x4 texels
OUT = (52, 32, 20)                         # outline colour shared by the tiles and obstacles


def up(img, k=PX):
    return img.resize((img.width * k, img.height * k), Image.NEAREST)


def down(img, k=PX):
    return img.resize((img.width // k, img.height // k), Image.NEAREST)


def outline(img, col=OUT):
    """Dark 1 px outline around everything opaque (4-neighbourhood), like the existing sprites."""
    w, h = img.size
    src = img.load()
    out = img.copy(); dst = out.load()
    for y in range(h):
        for x in range(w):
            if src[x, y][3]: continue
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nx, ny = x + dx, y + dy
                if 0 <= nx < w and 0 <= ny < h and src[nx, ny][3] and src[nx, ny][:3] != col:
                    dst[x, y] = col + (255,); break
    return out


def h01(*v):
    """Stable hash -> [0, 1)."""
    n = 0
    for k in v: n = (n * 1000003 + int(k) * 7919 + 17) & 0xFFFFFFFF
    n ^= n >> 13; n = (n * 1274126177) & 0xFFFFFFFF; n ^= n >> 16
    return n / 2 ** 32


def shade(c, f):
    return tuple(max(0, min(255, round(v * f))) for v in c[:3])


# ---------------------------------------------------------------------------------------------- tiles
# the 64 x 40 tile: top diamond (0,16)-(32,0)-(64,16)-(32,32), 8 px sides below it (left face lit, right face shaded)
def roles(template):
    """Role of each art pixel of an existing tile, from its colours: top, furrow/blade, left, right, outline."""
    t = down(template.convert("RGBA"))
    px = t.load(); w, h = t.size
    cols = {}
    for y in range(h):
        for x in range(w):
            if px[x, y][3]: cols[px[x, y][:3]] = cols.get(px[x, y][:3], 0) + 1
    top = max(cols, key=cols.get)
    grid = [[None] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            c = px[x, y]
            if not c[3]: continue
            on_top = abs(x - 31.5) / 32 + abs(y - 15.5) / 16 <= 1.0
            if c[:3] == OUT: grid[y][x] = "out"
            elif on_top: grid[y][x] = "top" if c[:3] == top else "mark"
            else: grid[y][x] = "left" if x < 32 else "right"
    return grid, w, h


def side_v(x, y):
    """Distance below the top diamond's lower edge, and position along that edge."""
    top_y = 16 + x / 2 if x < 32 else 32 - (x - 32) / 2
    return y - top_y, x


def paint_tile(grid, w, h, pal, top_fx=None, side_fx=None):
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0)); px = img.load()
    for y in range(h):
        for x in range(w):
            r = grid[y][x]
            if r is None: continue
            c = pal[r]
            if r in ("top", "mark") and top_fx: c = top_fx(x, y, r, c)
            if r in ("left", "right") and side_fx: c = side_fx(x, y, r, c)
            px[x, y] = c + (255,)
    return up(img)


def stone_sides(light, dark, mortar):
    """Terrace wall faces: two courses of stones with staggered joints."""
    def fx(x, y, r, c):
        v, u = side_v(x, y)
        base = light if r == "left" else dark
        row = 0 if v < 4.5 else 1
        if abs(v - 4.5) < 0.6: return mortar
        u2 = u + row * 4 + (3 if r == "right" else 0)
        if u2 % 8 == 0: return mortar
        return shade(base, 0.9 + 0.2 * h01(u2 // 8, row, r == "left"))
    return fx


def speckle(cols, rate, seed):
    def fx(x, y, r, c):
        if r != "top": return c
        k = h01(x, y, seed)
        return cols[int(k / rate) % len(cols)] if k < rate * len(cols) else c
    return fx


def mulch_ring(base_fx, mulch, mulch_dark, litter):
    """A ring of dark mulch round each orchard tree, on the grass top."""
    def fx(x, y, r, c):
        d = ((x - 31.5) / 13) ** 2 + ((y - 15.5) / 6.5) ** 2
        if d <= 1.0:
            k = h01(x, y, 99)
            return litter if k < 0.08 else mulch_dark if k < 0.3 or d > 0.8 else mulch
        return base_fx(x, y, r, c) if base_fx else c
    return fx


def tiles(art_dir):
    soil_g, w, h = roles(Image.open(os.path.join(art_dir, "tile_soil.png")))
    grass_g, _, _ = roles(Image.open(os.path.join(art_dir, "tile_grass.png")))
    out = {}

    # Baguio: dark highland loam on terraces of grey stone
    loam = dict(top=(86, 56, 38), mark=(64, 41, 27), out=(44, 38, 32), left=(0, 0, 0), right=(0, 0, 0))
    loam_wet = dict(loam, top=(62, 40, 27), mark=(46, 30, 19))
    stone = stone_sides((146, 142, 132), (112, 108, 100), (70, 66, 60))
    grass_b = dict(top=(106, 168, 74), mark=(132, 210, 92), out=(44, 38, 32), left=(0, 0, 0), right=(0, 0, 0))
    out["baguio"] = (paint_tile(soil_g, w, h, loam, side_fx=stone), paint_tile(soil_g, w, h, loam_wet, side_fx=stone),
                     paint_tile(grass_g, w, h, grass_b, side_fx=stone))

    # Ilocos: dry sandy soil, sandy sides
    sand = dict(top=(192, 152, 100), mark=(164, 124, 80), out=(92, 64, 38), left=(152, 114, 72), right=(128, 94, 58))
    sand_wet = dict(sand, top=(150, 110, 70), mark=(126, 90, 56), left=(124, 90, 56), right=(106, 76, 46))
    dry = dict(top=(160, 166, 82), mark=(196, 198, 114), out=(92, 64, 38), left=(152, 114, 72), right=(128, 94, 58))
    grains = speckle([(212, 180, 128), (176, 136, 88)], 0.03, 1)
    out["ilocos"] = (paint_tile(soil_g, w, h, sand, top_fx=grains), paint_tile(soil_g, w, h, sand_wet),
                     paint_tile(grass_g, w, h, dry, top_fx=speckle([(176, 150, 80)], 0.04, 2)))

    # Davao: lush orchard grass, a mulch ring where the tree stands, dark earth sides
    lush = dict(top=(70, 146, 58), mark=(102, 182, 76), out=(40, 30, 18), left=(76, 54, 32), right=(60, 42, 24))
    lush_wet = dict(lush, top=(60, 132, 60), mark=(88, 166, 80))
    litter = speckle([(176, 120, 58), (210, 172, 76), (132, 200, 96)], 0.012, 3)
    ring = mulch_ring(litter, (96, 66, 40), (78, 52, 32), (176, 120, 58))
    out["davao"] = (paint_tile(grass_g, w, h, lush, top_fx=ring), paint_tile(grass_g, w, h, lush_wet, top_fx=ring),
                    paint_tile(grass_g, w, h, lush, top_fx=litter))

    for loc, (soil, wet, grass) in out.items():
        soil.save(os.path.join(art_dir, f"tile_soil_{loc}.png"))
        wet.save(os.path.join(art_dir, f"tile_soil_wet_{loc}.png"))
        grass.save(os.path.join(art_dir, f"tile_grass_{loc}.png"))
    return out


# ---------------------------------------------------------------------------------------------- obstacles (32 x 32)
def canvas(w=32, h=32):
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    return img, ImageDraw.Draw(img)


def driftwood():
    img, d = canvas()
    # a thick, bleached log washed up across the plot: knots, grain, a broken branch and a pale cut end
    d.polygon([(3, 22), (6, 18), (16, 15), (25, 11), (28, 13), (28, 18), (18, 22), (7, 26), (4, 26)], fill=(180, 168, 148))
    d.polygon([(4, 21), (7, 18), (16, 15), (25, 11), (26, 13), (16, 17), (7, 20)], fill=(216, 206, 186))
    d.polygon([(5, 25), (17, 21), (27, 17), (28, 18), (18, 22), (7, 26)], fill=(136, 124, 106))
    d.polygon([(14, 16), (15, 9), (17, 6), (19, 7), (17, 10), (17, 16)], fill=(196, 184, 162))
    d.line((17, 7, 18, 10), fill=(150, 138, 118))
    for x0, y0 in ((8, 21), (13, 19), (20, 17)):
        d.line((x0, y0, x0 + 4, y0 - 2), fill=(150, 138, 118))
    d.ellipse((9, 21, 11, 23), fill=(110, 98, 84))
    d.ellipse((24, 11, 29, 18), fill=(204, 188, 160)); d.ellipse((25, 13, 28, 16), fill=(176, 158, 128)); d.point((26, 14), fill=(132, 110, 84))
    return up(outline(img))


def shrub():
    img, d = canvas()
    # a dry, thorny bush: a dark tangle with pale twigs poking out of it and a few olive leaves left
    d.ellipse((8, 13, 24, 28), fill=(96, 68, 40))
    rnd = random.Random(5)
    for _ in range(18):
        ang = rnd.uniform(math.pi * 1.02, math.pi * 1.98)
        r = rnd.uniform(9, 13.5)
        x0, y0 = 16 + rnd.uniform(-2, 2), 27
        x1, y1 = 16 + math.cos(ang) * r * 1.1, 24 + math.sin(ang) * r
        d.line((x0, y0, x1, y1), fill=rnd.choice([(150, 108, 62), (176, 134, 80), (196, 156, 98)]))
        if rnd.random() < 0.5:                  # a fork near the tip
            d.line((x1, y1, x1 + rnd.choice((-2, 2)), y1 - 2), fill=(176, 134, 80))
    for _ in range(7):
        x, y = rnd.randint(9, 23), rnd.randint(14, 23)
        d.point((x, y), fill=(140, 146, 70)); d.point((x + 1, y), fill=(162, 166, 86)); d.point((x, y + 1), fill=(118, 124, 58))
    d.line((12, 28, 20, 28), fill=(104, 72, 42))
    return up(outline(img))


def husks():
    img, d = canvas()
    # three fibrous coconut husks and a split shell showing its white flesh
    for (cx, cy, rx, ry) in ((10, 23, 6, 4), (21, 24, 6, 4), (15, 17, 6, 4)):
        d.ellipse((cx - rx, cy - ry, cx + rx, cy + ry), fill=(140, 92, 50))
        d.ellipse((cx - rx + 1, cy - ry, cx + rx - 2, cy - 1), fill=(170, 118, 66))
        for k in range(-rx + 2, rx - 1, 2):
            d.point((cx + k, cy + 1), fill=(104, 66, 34)); d.point((cx + k + 1, cy - 1), fill=(190, 140, 84))
    d.ellipse((20, 12, 29, 19), fill=(118, 78, 44)); d.ellipse((21, 12, 28, 16), fill=(244, 238, 222))
    d.line((22, 14, 27, 14), fill=(220, 212, 190))
    return up(outline(img))


def banana_stump():
    img, d = canvas()
    # a cut pseudo-stem: striped green sheath, pale rings on the cut, a dry leaf hanging off it, a sucker at the foot
    d.rectangle((9, 13, 22, 26), fill=(120, 154, 62))
    for x in range(9, 23):
        k = h01(x, 4)
        col = (150, 172, 74) if k < 0.35 else (98, 132, 52) if k < 0.6 else (138, 104, 56) if k < 0.72 else None
        if col: d.line((x, 14, x, 26), fill=col)
    d.ellipse((9, 23, 22, 29), fill=(110, 140, 56))
    d.ellipse((9, 10, 22, 16), fill=(226, 220, 172))
    d.ellipse((11, 11, 20, 15), fill=(200, 198, 134)); d.ellipse((13, 12, 18, 14), fill=(176, 184, 104))
    d.point((15, 13), fill=(226, 220, 172))
    d.polygon([(22, 15), (27, 18), (28, 24), (26, 28), (24, 22), (22, 19)], fill=(156, 114, 58))
    d.line((23, 17, 26, 25), fill=(122, 86, 44))
    d.polygon([(8, 26), (4, 20), (6, 19), (9, 23)], fill=(96, 168, 64)); d.point((5, 20), fill=(132, 200, 92))
    return up(outline(img))


def obstacles(art_dir):
    made = dict(driftwood=driftwood(), shrub=shrub(), husks=husks(), banana_stump=banana_stump())
    for name, im in made.items():
        im.save(os.path.join(art_dir, f"obstacle_{name}.png"))
    return made


# ---------------------------------------------------------------------------------------------- field edges
# Same frame as the old fence piece (props_00, 212 x 201): the ground runs from (24, 110) to (192, 199), down to the right.
EW, EH = 53, 50
def ground(x): return 27.5 + (x - 6) * 0.53


def stone_wall():
    img, d = canvas(EW, EH)
    px = img.load()
    H, T = 10, 3                                 # wall height and top depth (towards the back, up-right)
    for x in range(2, 51):
        g = ground(x)
        for y in range(round(g - H), min(EH, round(g) + 1)):
            v = g - y                            # height above the ground
            row = 0 if v < H / 2 else 1
            u = x + row * 4
            j = u // 7
            mortar = abs(v - H / 2) < 0.6 or u % 7 == 0
            base = shade((148, 144, 134), 0.86 + 0.24 * h01(j, row))
            px[x, y] = ((84, 80, 72) if mortar else base) + (255,)
    # the wall's capstones, a little lighter, with moss here and there (filled as one shape so it has no gaps)
    top = Image.new("L", (EW, EH), 0)
    ImageDraw.Draw(top).polygon([(2, ground(2) - H), (50, ground(50) - H), (50 + T, ground(50) - H - T), (2 + T, ground(2) - H - T)], fill=255)
    tm = top.load()
    for y in range(EH):
        for x in range(EW):
            if not tm[x, y] or px[x, y][3]: continue
            u = x - (ground(x) - H - y)          # position along the wall, measured at its front edge
            cap = int(u + 2) // 7
            joint = int(u + 2) % 7 == 0
            moss = h01(cap, 7) < 0.3 and h01(x, y, 3) < 0.45
            px[x, y] = ((96, 92, 84) if joint else (108, 144, 64) if moss else shade((184, 180, 168), 0.92 + 0.12 * h01(cap, 1))) + (255,)
    return up(outline(img, (52, 46, 40)))


def bamboo_fence():
    img, d = canvas(EW, EH)
    light, mid, dark, node = (208, 204, 112), (172, 176, 78), (124, 130, 52), (96, 98, 38)

    def pole(x, y_top, y_bot):
        d.rectangle((x, y_top, x + 3, y_bot), fill=mid)
        d.line((x + 1, y_top + 1, x + 1, y_bot), fill=light); d.line((x + 3, y_top, x + 3, y_bot), fill=dark)
        for y in range(y_top + 6, y_bot - 1, 7):
            d.line((x, y, x + 3, y), fill=node)
        d.rectangle((x, y_top, x + 3, y_top + 1), fill=(226, 214, 150))

    def rail(y0):
        for t in range(3):
            col = (light, mid, dark)[t]
            d.line((6, ground(6) - y0 + t, 47, ground(47) - y0 + t), fill=col)
        for x in range(12, 46, 9):
            y = round(ground(x) - y0)
            d.line((x, y, x, y + 2), fill=node)

    pole(3, round(ground(5)) - 26, round(ground(5)))
    rail(19); rail(10)
    pole(45, round(ground(47)) - 26, round(ground(47)))
    for x, y0 in ((5, 19), (5, 10), (46, 19), (46, 10)):          # rope lashings where the rails meet the poles
        y = round(ground(x) - y0)
        d.line((x - 1, y, x + 2, y + 2), fill=(196, 160, 100))
    return up(outline(img, (66, 60, 26)))


def coconut_log():
    img, d = canvas(EW, EH)
    px = img.load()
    R = 4                                        # log radius in art px
    for x in range(3, 49):
        g = ground(x) - 1
        for y in range(round(g - 2 * R), min(EH, round(g) + 1)):
            v = (g - y) / (2 * R)                # 0 at the bottom, 1 at the top
            ring = (x + round(v * 3)) % 5 == 0   # coconut trunks are ringed with old leaf scars
            base = (164, 140, 108) if v > 0.7 else (132, 108, 82) if v > 0.3 else (100, 80, 60)
            px[x, y] = (shade(base, 0.8) if ring else base) + (255,)
    # the cut end facing the field: fibrous, pale
    cx, cy = 48, ground(48) - 1 - R
    d.ellipse((cx - 2, cy - R, cx + 3, cy + R), fill=(204, 176, 128))
    for k in range(-2, 3):
        d.point((cx + (k % 2), cy + k * 1.5), fill=(170, 140, 96))
    # a fallen coconut in front of it
    gx = 14; gy = round(ground(gx)) + 1
    d.ellipse((gx - 2, gy - 3, gx + 2, gy + 1), fill=(124, 92, 52)); d.point((gx - 1, gy - 2), fill=(160, 124, 74))
    return up(outline(img, (52, 40, 26)))


def edges(pieces_dir):
    made = {"edge_00": stone_wall(), "edge_01": bamboo_fence(), "edge_02": coconut_log()}
    for name, im in made.items():
        # the builder sizes pieces from their full canvas, so keep the old fence's 212 x 201 frame
        frame = Image.new("RGBA", (212, 201), (0, 0, 0, 0)); frame.alpha_composite(im, (0, 1))
        frame.save(os.path.join(pieces_dir, name + ".png"))
    return made


if __name__ == "__main__":
    art_dir, pieces_dir = sys.argv[1:3]
    t = tiles(art_dir); o = obstacles(art_dir); e = edges(pieces_dir)
    if len(sys.argv) > 3:
        sheet = Image.new("RGBA", (3 * 270 + 10, 3 * 175 + 2 * 140 + 230), (70, 90, 60, 255))
        for i, (loc, ims) in enumerate(t.items()):
            for j, im in enumerate(ims): sheet.alpha_composite(im, (10 + j * 270, 10 + i * 175))
        x = 10
        for name in ("obstacle_rock", "obstacle_stump"):
            sheet.alpha_composite(Image.open(os.path.join(art_dir, name + ".png")).convert("RGBA"), (x, 545)); x += 135
        for im in o.values(): sheet.alpha_composite(im, (x, 545)); x += 135
        x = 10
        for im in e.values(): sheet.alpha_composite(im, (x, 690)); x += 260
        sheet.save(sys.argv[3])
