"""
Cuts an AI-generated asset sheet (separate objects on a transparent background) into one PNG per object,
reading order (rows top to bottom, left to right). Objects closer than GAP px are treated as one.
Usage: slice_sheet.py sheet.png out_prefix [min_px]
Writes out_prefix_00.png, out_prefix_01.png, ... and prints each name with its size.
"""
import sys
from PIL import Image, ImageFilter

src, prefix = sys.argv[1], sys.argv[2]
MIN = int(sys.argv[3]) if len(sys.argv) > 3 else 24
GAP = 6
im = Image.open(src).convert("RGBA")
W, H = im.size
solid = im.split()[3].point(lambda a: 255 if a > 40 else 0)

# work at quarter size for speed; dilate so nearby parts (a leaf, a hat) join their object
S = 4
small = solid.resize((W // S, H // S), Image.BOX).point(lambda a: 255 if a > 20 else 0)
small = small.filter(ImageFilter.MaxFilter(2 * (GAP // S) + 1))
w, h = small.size
px = small.load()
seen = [[False] * w for _ in range(h)]
boxes = []
for y in range(h):
    for x in range(w):
        if px[x, y] and not seen[y][x]:
            stack = [(x, y)]; seen[y][x] = True
            x0 = x1 = x; y0 = y1 = y
            while stack:
                cx, cy = stack.pop()
                x0, x1, y0, y1 = min(x0, cx), max(x1, cx), min(y0, cy), max(y1, cy)
                for nx, ny in ((cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)):
                    if 0 <= nx < w and 0 <= ny < h and px[nx, ny] and not seen[ny][nx]:
                        seen[ny][nx] = True; stack.append((nx, ny))
            box = (x0 * S, y0 * S, min(W, (x1 + 1) * S), min(H, (y1 + 1) * S))
            if box[2] - box[0] >= MIN and box[3] - box[1] >= MIN:
                boxes.append(box)

# reading order: group into rows by vertical centre
boxes.sort(key=lambda b: (b[1] + b[3]) / 2)
rows = []
for b in boxes:
    cy = (b[1] + b[3]) / 2
    if rows and abs(cy - rows[-1][0]) < (b[3] - b[1]) * 0.6:
        rows[-1][1].append(b)
    else:
        rows.append([cy, [b]])
ordered = [b for _, row in rows for b in sorted(row, key=lambda b: b[0])]

for i, b in enumerate(ordered):
    piece = im.crop(b)
    tight = piece.split()[3].point(lambda a: 255 if a > 40 else 0).getbbox()
    piece = piece.crop(tight)
    name = f"{prefix}_{i:02d}.png"
    piece.save(name)
    print(name, piece.size)
