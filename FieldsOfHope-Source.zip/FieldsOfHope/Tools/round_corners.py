"""Rounds the corners of a framed UI sprite and redraws its border along the curve.

usage: python round_corners.py <in.png> <out.png> <radius>

The frame's own edge profile (the strip of pixels from the outside in, sampled at the middle of each
edge) is swept around each corner, so the rounded border keeps the same colours and thickness as the
straight edges. Pixels outside the curve become transparent (anti-aliased). The radius must stay inside
the sprite's 9-slice border (UI.Borders) or the curve gets stretched.
"""
import math
import sys

from PIL import Image


def opaque_span(pixels, coords):
    """First and last index along coords whose alpha is solid."""
    idx = [i for i, c in enumerate(coords) if pixels[c][3] > 160]
    return idx[0], idx[-1]


def round_top_left(im, r):
    w, h = im.size
    p = im.load()
    row, col = h // 2, int(w * 0.2)          # 0.2: clear of the panel's centre notch
    x0, _ = opaque_span(p, [(x, row) for x in range(w)])
    y0, _ = opaque_span(p, [(col, y) for y in range(h)])
    left = [p[x0 + d, row] for d in range(r + 1)]
    top = [p[col, y0 + d] for d in range(r + 1)]
    cx, cy = x0 + r, y0 + r
    # stray decoration outside the frame's edge next to the corner would poke past the curve
    for y in range(0, y0 + r):
        for x in range(0, x0): p[x, y] = (0, 0, 0, 0)
    for x in range(x0, x0 + r):
        for y in range(0, y0): p[x, y] = (0, 0, 0, 0)
    for y in range(y0, y0 + r):
        for x in range(x0, x0 + r):
            dx, dy = cx - (x + 0.5), cy - (y + 0.5)
            dist = math.hypot(dx, dy)
            cover = max(0.0, min(1.0, r + 0.5 - dist))
            depth = min(r, max(0, int(r - dist)))
            t = abs(dy) / (abs(dx) + abs(dy) + 1e-6)   # 0 = beside the left edge, 1 = under the top edge
            a, b = left[depth], top[depth]
            c = tuple(round(a[i] * (1 - t) + b[i] * t) for i in range(4))
            p[x, y] = c[:3] + (round(c[3] * cover),)
    return im


def round_all(im, r):
    flips = [[], [Image.FLIP_LEFT_RIGHT], [Image.FLIP_TOP_BOTTOM], [Image.FLIP_LEFT_RIGHT, Image.FLIP_TOP_BOTTOM]]
    for ops in flips:
        for op in ops: im = im.transpose(op)
        im = round_top_left(im, r)
        for op in reversed(ops): im = im.transpose(op)
    return im


if __name__ == "__main__":
    src, dst, radius = sys.argv[1], sys.argv[2], int(sys.argv[3])
    round_all(Image.open(src).convert("RGBA"), radius).save(dst)
