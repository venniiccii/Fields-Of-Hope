"""
Turns an AI-generated walk-cycle sheet (4 figures in a row, transparent background) into a game strip:
N square frames side by side, feet on a shared baseline, every figure the same height, heads lined up so the walk doesn't jitter.
Usage: slice_walk.py sheet.png out.png [frame_px] [--cols N]
  --cols N: the sheet holds N evenly spaced figures whose tools touch (a hoe, a plank): split near each nominal
  column boundary at the emptiest pixel column instead of at gaps.
"""
import sys
from PIL import Image

args = sys.argv[1:]
cols_n = None
if "--cols" in args:
    i = args.index("--cols"); cols_n = int(args[i + 1]); del args[i:i + 2]
src, out = args[0], args[1]
F = int(args[2]) if len(args) > 2 else 144
im = Image.open(src).convert("RGBA")
alpha = im.split()[3].point(lambda a: 255 if a > 40 else 0)
W, H = im.size

# columns that contain the figure, grouped into separate figures by empty gaps
cols = [any(alpha.getpixel((x, y)) for y in range(0, H, 2)) for x in range(W)]
runs, start = [], None
for x, on in enumerate(cols + [False]):
    if on and start is None: start = x
    if not on and start is not None:
        if x - start > W * 0.04: runs.append((start, x))
        start = None
# merge slivers that belong to one figure (e.g. a swinging basket separated by a gap)
merged = []
for r in runs:
    if merged and r[0] - merged[-1][1] < W * 0.02: merged[-1] = (merged[-1][0], r[1])
    else: merged.append(r)
if cols_n:
    counts = [sum(1 for y in range(0, H, 2) if alpha.getpixel((x, y))) for x in range(W)]
    cuts = [0]
    for k in range(1, cols_n):
        mid, r = round(W * k / cols_n), round(W * 0.09)
        cuts.append(min(range(mid - r, mid + r), key=lambda x: (counts[x], abs(x - mid))))
    cuts.append(W)
    merged = list(zip(cuts, cuts[1:]))
if len(merged) < 2: sys.exit(f"found {len(merged)} figures in {src}")

frames = []
for x0, x1 in merged:
    piece = im.crop((x0, 0, x1, H))
    # measure only solid pixels: faint near-transparent specks would inflate the bounding box
    bx = piece.split()[3].point(lambda a: 255 if a > 40 else 0).getbbox()
    piece = piece.crop(bx)
    # horizontal anchor = centre of the head/hat (top 30% of the figure), so the body sways but the head stays put
    a = piece.split()[3]
    top = int(piece.height * 0.3)
    xs = [x for x in range(piece.width) for y in range(0, top, 2) if a.getpixel((x, y)) > 40]
    anchor = sum(xs) / len(xs) if xs else piece.width / 2
    frames.append((piece, anchor))

# AI frames are not drawn at a consistent size, so every frame is scaled to the same height
# (the game adds the up-and-down step bounce itself)
target = F * 0.84
strip = Image.new("RGBA", (F * len(frames), F), (0, 0, 0, 0))
for i, (p, anchor) in enumerate(frames):
    scale = target / p.height
    w, h = max(1, round(p.width * scale)), max(1, round(p.height * scale))
    p = p.resize((w, h), Image.LANCZOS)
    x = i * F + round(F / 2 - anchor * scale)
    x = min(max(i * F, x), i * F + F - w)   # keep the figure inside its own frame
    y = F - 4 - h                           # feet 4px above the bottom edge
    strip.alpha_composite(p, (x, y))
strip.save(out)
print(out, len(frames), "frames")
