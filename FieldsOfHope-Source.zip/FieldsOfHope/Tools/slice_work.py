"""
Turns an AI-generated in-place animation sheet (4 poses in a row, transparent background) into a game strip of square frames.
Unlike walk cycles, poses keep their natural size changes (bending, raising a tool): one scale for the whole strip,
feet planted on a shared baseline and lined up horizontally by the feet, so the character never slides.
Prints JSON: {"frames": n, "figure": typical body height as a share of the frame}.
Usage: slice_work.py sheet.png out.png [frame_px] [--even N]
  --even N: the sheet is N evenly spaced columns; split there instead of at gaps (for poses whose tools touch).
"""
import json, sys
from PIL import Image

args = [a for a in sys.argv[1:]]
even = None
if "--even" in args:
    i = args.index("--even"); even = int(args[i + 1]); del args[i:i + 2]
src, out = args[0], args[1]
F = int(args[2]) if len(args) > 2 else 160
im = Image.open(src).convert("RGBA")
solid = im.split()[3].point(lambda a: 255 if a > 40 else 0)
W, H = im.size

cols = [solid.crop((x, 0, x + 1, H)).getbbox() is not None for x in range(W)]
runs, start = [], None
for x, on in enumerate(cols + [False]):
    if on and start is None: start = x
    if not on and start is not None:
        if x - start > W * 0.03: runs.append((start, x))
        start = None
merged = []
for r in runs:   # a tool or splash separated by a small gap still belongs to its figure
    if merged and r[0] - merged[-1][1] < W * 0.025: merged[-1] = (merged[-1][0], r[1])
    else: merged.append(r)
if even:
    merged = [(round(W * k / even), round(W * (k + 1) / even)) for k in range(even)]
if len(merged) < 2: sys.exit(f"found {len(merged)} figures in {src}")

pieces = []
for x0, x1 in merged:
    piece = im.crop((x0, 0, x1, H))
    bx = piece.split()[3].point(lambda a: 255 if a > 40 else 0).getbbox()
    piece = piece.crop(bx)
    a = piece.split()[3]
    # horizontal anchor = centre of the feet (bottom 12% of the figure)
    y0 = int(piece.height * 0.88)
    xs = [x for x in range(piece.width) for y in range(y0, piece.height) if a.getpixel((x, y)) > 40]
    anchor = sum(xs) / len(xs) if xs else piece.width / 2
    pieces.append((piece, anchor))

heights = sorted(p.height for p, _ in pieces)
typical = heights[len(heights) // 2]
widest = max(max(anchor, p.width - anchor) for p, anchor in pieces)
scale = min(F * 0.70 / typical, (F - 6) / heights[-1], (F / 2 - 2) / widest)

strip = Image.new("RGBA", (F * len(pieces), F), (0, 0, 0, 0))
for i, (p, anchor) in enumerate(pieces):
    w, h = max(1, round(p.width * scale)), max(1, round(p.height * scale))
    p = p.resize((w, h), Image.LANCZOS)
    x = i * F + round(F / 2 - anchor * scale)
    x = min(max(i * F, x), i * F + F - w)
    strip.alpha_composite(p, (x, F - 4 - h))
strip.save(out)
print(json.dumps({"frames": len(pieces), "figure": round(typical * scale / F, 4)}))
