"""
Builds a 'living painting' mask for a background, at half resolution:
  R = foliage (sways in the wind)      G = water (ripples and sparkles)
  B = character motion code (type * 32 + phase)
  A = character weight: 0 at the feet and box edges, up to 1 at chest/head height
Usage: make_masks.py src.png out.png preview.png [farm]
"""
import math, random, sys
from PIL import Image, ImageFilter, ImageChops

src, out, preview = sys.argv[1:4]
with_people = len(sys.argv) > 4 and sys.argv[4] == "farm"
im = Image.open(src).convert("RGB")
W, H = im.size
h, s, v = im.convert("HSV").split()
lum = im.convert("L")

def band(ch, lo, hi):
    return ch.point(lambda x: 255 if lo <= x <= hi else 0)

# texture = local contrast; flat grass has little, leaves and crops have a lot
detail = ImageChops.difference(lum, lum.filter(ImageFilter.BoxBlur(2))).filter(ImageFilter.BoxBlur(5))
textured = detail.point(lambda x: 255 if x > 9 else 0)
green = band(h, 40, 118)                      # yellow-green .. teal
dark_green = ImageChops.multiply(green, v.point(lambda x: 255 if x < 150 else 0))
foliage = ImageChops.lighter(ImageChops.multiply(green, textured), dark_green)
foliage = foliage.filter(ImageFilter.MinFilter(7)).filter(ImageFilter.MaxFilter(9)).filter(ImageFilter.GaussianBlur(3))

water = ImageChops.multiply(ImageChops.multiply(band(h, 128, 160), band(s, 70, 255)), band(v, 110, 255))
if not with_people:
    # title art: the sky and a teal roof are blue too, but must stay still
    from PIL import ImageDraw
    d = ImageDraw.Draw(water)
    d.rectangle((0, 0, W, int(H * 0.2)), fill=0)
    d.rectangle((790, 150, 970, 280), fill=0)
water = water.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.MaxFilter(3)).filter(ImageFilter.GaussianBlur(2))

# characters on the farm painting: (x0, y0, x1, y1 = feet line, type)
# types: 0 idle, 1 working, 2 chatting/eating, 3 scarecrow sway, 4 animal, 5 swan
IDLE, WORK, CHAT, SWAY, ANIMAL, SWAN = range(6)
PEOPLE = [   # painted figures the shader animates; the villagers themselves are animated sprites (Walkers/Villagers.cs)
    (115, 300, 160, 395, SWAY),    # scarecrows
    (647, 582, 700, 668, SWAY),
    (712, 95, 752, 178, SWAY),
    (1492, 197, 1568, 290, ANIMAL),  # deer
    (150, 145, 200, 200, ANIMAL),    # white goat
    (282, 702, 332, 747, SWAN),      # swans
    (597, 690, 637, 752, SWAN),
]

code = Image.new("L", (W, H), 0)
weight = Image.new("L", (W, H), 0)
if with_people:
    rnd = random.Random(5)
    cp, wp = code.load(), weight.load()
    for (x0, y0, x1, y1, kind) in PEOPLE:
        x0 -= 6; x1 += 6; y0 -= 8            # margin so the fade-out happens on background, not on the figure
        bw, bh = x1 - x0, y1 - y0
        c = kind * 32 + rnd.randrange(32)
        for y in range(y0, y1 + 1):
            fy = (y1 - y) / bh                                  # 0 at the feet, 1 at the top
            top = min(1.0, (y - y0) / (bh * 0.18))              # fade out over the top margin
            for x in range(x0, x1 + 1):
                fx = math.sin(math.pi * (x - x0) / bw)          # fade out at both sides
                wgt = max(0.0, min(1.0, fy * 1.25)) * fx * top
                if wgt > wp[x, y] / 255:
                    wp[x, y] = int(wgt * 255); cp[x, y] = c

if with_people:
    # people in green clothes must not rustle like leaves
    fp = foliage.load()
    for (x0, y0, x1, y1, kind) in PEOPLE:
        for y in range(y0 - 8, y1 + 1):
            for x in range(x0 - 6, x1 + 7):
                fp[x, y] = 0

# half resolution keeps the build small; codes must not be blended, so use nearest for B
half = (W // 2, H // 2)
# resize each channel on its own: Pillow premultiplies RGBA by alpha when resizing, which would erase R/G
r, g, a = (ch.resize(half, Image.BILINEAR) for ch in (foliage, water, weight))
b = code.resize(half, Image.NEAREST)
Image.merge("RGBA", (r, g, b, a)).save(out)

tint = Image.merge("RGB", (foliage, water, weight))
Image.blend(im, tint, 0.55).save(preview)
print("mask", half, "characters", len(PEOPLE) if with_people else 0)
