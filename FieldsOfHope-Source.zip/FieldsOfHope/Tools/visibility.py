"""How much of each villager can actually be seen on the map: draws everything in the game's depth order and measures
the share of each villager's pixels that nothing in front covers. Flags anyone mostly hidden.

usage: python visibility.py <Assets/Resources> [threshold=0.6]
"""
import json
import os
import sys

from PIL import Image, ImageChops

FIGURE, FEET = 0.7, 4 / 160


def sprite(res, name, w, h, flip=False, squash=1.0):
    im = Image.open(os.path.join(res, "Map", name + ".png")).convert("RGBA").resize((max(1, round(w * squash)), max(1, round(h))))
    return im.transpose(Image.FLIP_LEFT_RIGHT) if flip else im


def villager_frame(res, v):
    strip = Image.open(os.path.join(res, "Art", f"act_{v['name']}.png")).convert("RGBA")
    F = strip.height
    size = round(v["height"] / FIGURE)
    return strip.crop((0, 0, F, F)).resize((size, size)), size


def check(res, loc, threshold):
    d = json.load(open(os.path.join(res, "Map", f"layout_{loc}.json")))
    W, H = 1700, 952
    layers = []                                   # (depth, image, x, y)
    for o in d["objects"]:
        im = sprite(res, o["s"], o["w"], o["h"], o["flip"], o.get("squash", 1))
        if o.get("spin"): x, y = o["x"] - im.width / 2, o["y"] - im.height / 2
        else: x, y = o["x"] - im.width / 2, o["y"] - im.height
        layers.append((o["depth"], im, round(x), round(y), None))
    for v in d["villagers"]:
        im, size = villager_frame(res, v)
        layers.append((v.get("depth") or v["y"], im, round(v["x"] - size / 2), round(v["y"] - size + size * FEET), v["name"]))
    layers.sort(key=lambda t: t[0])
    report = []
    for i, (dep, im, x, y, name) in enumerate(layers):
        if name is None: continue
        mine = Image.new("L", (W, H), 0); mine.paste(im.split()[3], (x, y))
        cover = Image.new("L", (W, H), 0)
        for dep2, im2, x2, y2, _ in layers[i + 1:]:
            if x2 > x + im.width or x2 + im2.width < x or y2 > y + im.height or y2 + im2.height < y: continue
            layer = Image.new("L", (W, H), 0); layer.paste(im2.split()[3], (x2, y2))
            cover = ImageChops.lighter(cover, layer)
        box = (max(0, x), max(0, y), min(W, x + im.width), min(H, y + im.height))
        m, c = mine.crop(box), cover.crop(box)
        total = sum(1 for p in m.getdata() if p > 100)
        seen = sum(1 for p, q in zip(m.getdata(), c.getdata()) if p > 100 and q < 100)
        share = seen / max(1, total)
        report.append((share, name))
    for share, name in sorted(report):
        flag = "  <-- mostly hidden" if share < threshold else ""
        if share < 0.9: print(f"{loc:7s} {name:16s} {share:5.0%} visible{flag}")


if __name__ == "__main__":
    res = sys.argv[1]
    th = float(sys.argv[2]) if len(sys.argv) > 2 else 0.6
    for loc in ("baguio", "ilocos", "davao"):
        check(res, loc, th)
