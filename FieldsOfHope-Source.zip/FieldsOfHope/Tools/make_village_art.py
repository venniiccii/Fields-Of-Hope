"""
Village night life art: the campfire that villagers gather round on some evenings (8 to 9 pm).

  python -I make_village_art.py <map pieces dir> <Resources/Art dir> [preview png]

Writes campfire.png to the pieces dir for map_builder.py: a ring of stones round a bed of ash with a teepee of logs,
unlit. The flames, glow and sparks are drawn by the game (Client/Ambience.cs) only while the fire burns.
Writes icon_moon.png to Art: the night badge (a crescent moon and stars on a night-sky disc) that covers the clock's sun.
Pixel art on a 4 px grid with the field art's outline colour (make_field_art.py). Deterministic.
"""
import math, os, sys
from PIL import Image, ImageDraw

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from make_field_art import up, outline, h01

W, H = 40, 30                     # logical px; the builder draws it 60 map px wide
CX, CY = 20, 21                   # centre of the fire bed (map_builder places the spot here)


def stone(d, x, y, k):
    base = [(128, 124, 116), (142, 136, 126), (116, 112, 106)][k % 3]
    d.ellipse((x - 2, y - 1.5, x + 2, y + 1.5), fill=base)
    d.line((x - 1, y - 1, x + 1, y - 1), fill=tuple(min(255, c + 30) for c in base))
    d.line((x - 1, y + 1, x + 1, y + 1), fill=tuple(c - 30 for c in base))


def log(d, a, b):
    """One thin log leaning into the teepee: bark, a lit edge, and a charred tip."""
    d.line((a, b), fill=(112, 72, 38), width=2)
    d.line(((a[0] + 1, a[1]), (b[0] + 1, b[1])), fill=(160, 112, 64), width=1)
    t = 0.8
    m = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
    d.line((m, b), fill=(62, 48, 40), width=2)


def campfire():
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # bed of ash and burnt earth
    d.ellipse((CX - 14, CY - 5, CX + 14, CY + 6), fill=(78, 66, 58))
    d.ellipse((CX - 9, CY - 3, CX + 9, CY + 3), fill=(104, 96, 90))
    for i in range(14):
        x, y = CX - 8 + h01(i, 1) * 16, CY - 2.5 + h01(i, 2) * 5
        d.point((round(x), round(y)), fill=(140, 134, 128) if h01(i, 3) < 0.6 else (60, 52, 48))
    ring = [(CX + math.cos(a) * 15, CY + math.sin(a) * 6.2) for a in (k * math.tau / 11 + 0.2 for k in range(11))]
    back = [p for p in ring if p[1] < CY]; front = [p for p in ring if p[1] >= CY]
    for k, (x, y) in enumerate(back): stone(d, x, y, k)
    # a teepee of four logs leaning together over the fire bed
    apex = (CX, 9)
    for base in ((CX - 9, CY + 1), (CX + 9, CY), (CX - 3, CY + 3), (CX + 4, CY - 3)):
        log(d, base, (apex[0] + (base[0] - CX) * 0.22, apex[1] + (1 if base[1] > CY else 0)))
    # a split log and kindling lying by the front stones
    d.line(((CX - 12, CY + 6), (CX - 4, CY + 8)), fill=(132, 90, 50), width=2)
    d.line(((CX - 11, CY + 5), (CX - 5, CY + 7)), fill=(176, 130, 78), width=1)
    for k, (x, y) in enumerate(front): stone(d, x, y, k + 5)
    return up(outline(img))


def moon_icon():
    """32 x 32: a round patch of night sky, big enough to hide the clock bar's painted sun and its rays."""
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((1, 1, 30, 30), fill=(30, 40, 86))
    d.ellipse((3, 3, 27, 25), fill=(40, 54, 112))
    d.ellipse((5, 4, 21, 14), fill=(48, 64, 128))
    # the crescent: a pale disc with a night-coloured disc bitten out of it
    d.ellipse((7, 7, 23, 23), fill=(248, 232, 160))
    d.ellipse((8, 8, 20, 20), fill=(255, 246, 196))
    for x in range(32):
        for y in range(32):
            if (x - 19.5) ** 2 + (y - 12.5) ** 2 < 7.5 ** 2 and img.getpixel((x, y))[0] > 200:
                img.putpixel((x, y), (40, 54, 112, 255))
    d.point((11, 18), fill=(222, 198, 126)); d.point((12, 20), fill=(222, 198, 126))
    for x, y, big in ((24, 8, True), (25, 21, False), (9, 6, False), (20, 25, True)):
        d.point((x, y), fill=(255, 250, 214))
        if big:
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)): d.point((x + dx, y + dy), fill=(214, 220, 255))
    return up(outline(img))


if __name__ == "__main__":
    pieces, art = sys.argv[1], sys.argv[2]
    moon_icon().save(os.path.join(art, "icon_moon.png"))
    im = campfire()
    im.save(os.path.join(pieces, "campfire.png"))
    if len(sys.argv) > 3:
        prev = Image.new("RGBA", (im.width * 2 + 20, im.height * 2 + 20), (96, 150, 60, 255))
        prev.alpha_composite(im.resize((im.width * 2, im.height * 2), Image.NEAREST), (10, 10))
        prev.save(sys.argv[3])
    print("campfire", im.size)
