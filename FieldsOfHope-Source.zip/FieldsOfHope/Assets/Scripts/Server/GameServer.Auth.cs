using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using UnityEngine;

namespace FieldsOfHope
{
    public partial class GameServer
    {
        const int HashIterations = 120000;
        static readonly Regex UsernameRule = new Regex("^[A-Za-z][A-Za-z0-9_]{3,15}$");
        static readonly string[] BlockedWords = { "fuck", "shit", "bitch", "dick", "pussy", "cunt", "nigg", "fag", "slut", "whore", "puta", "gago", "tanga", "bobo", "ulol" };
        readonly Dictionary<string, List<long>> unknownUserFailures = new Dictionary<string, List<long>>();

        public static string ValidateUsername(string u)
        {
            if (string.IsNullOrEmpty(u)) return "Enter a username.";
            if (u.Length < 4 || u.Length > 16) return "Username must be 4 to 16 characters.";
            if (!char.IsLetter(u[0])) return "Username must start with a letter.";
            if (!UsernameRule.IsMatch(u)) return "Use only letters, numbers and underscores.";
            return null;
        }

        public static string ValidatePassword(string p, string username)
        {
            if (string.IsNullOrEmpty(p)) return "Enter a password.";
            if (p.Length < 8) return "Password must be at least 8 characters.";
            if (!p.Any(char.IsLetter) || !p.Any(char.IsDigit)) return "Password needs at least one letter and one number.";
            if (!string.IsNullOrEmpty(username) && string.Equals(p, username, StringComparison.OrdinalIgnoreCase)) return "Password cannot be the same as your username.";
            return null;
        }

        static string Hash(string password, byte[] salt)
        {
            using var kdf = new Rfc2898DeriveBytes(password, salt, HashIterations, HashAlgorithmName.SHA256);
            return Convert.ToBase64String(kdf.GetBytes(32));
        }

        static string RandomToken(int bytes = 32)
        {
            var b = new byte[bytes];
            using (var r = RandomNumberGenerator.Create()) r.GetBytes(b);
            return Convert.ToBase64String(b).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        }

        static bool SlowEquals(string a, string b)
        {
            if (a == null || b == null || a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }

        static long WallNow => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        /// <summary>AUTH-01..04. Returns field-keyed errors ("username", "password", "confirm") or null on success.</summary>
        public Dictionary<string, string> Register(string username, string password, string confirm)
        {
            var errors = new Dictionary<string, string>();
            username = (username ?? "").Trim();
            var ue = ValidateUsername(username); if (ue != null) errors["username"] = ue;
            var pe = ValidatePassword(password, username); if (pe != null) errors["password"] = pe;
            if (password != confirm) errors["confirm"] = "Passwords do not match";
            if (errors.Count > 0) return errors;

            string lower = username.ToLowerInvariant();
            if (BlockedWords.Any(w => lower.Contains(w))) { errors["username"] = "Please choose a different username."; return errors; }
            var db = LoadAccounts();
            if (db.accounts.Any(a => a.usernameLower == lower)) { errors["username"] = "That username is already taken. Try another."; return errors; }

            var salt = new byte[16];
            using (var r = RandomNumberGenerator.Create()) r.GetBytes(salt);
            var acc = new AccountRecord
            {
                id = Guid.NewGuid().ToString("N"), username = username, usernameLower = lower,
                salt = Convert.ToBase64String(salt), hash = Hash(password, salt), createdAt = WallNow,
                tzOffsetMin = WebStorage.LocalUtcOffsetMinutes(),
            };
            db.accounts.Add(acc);
            SaveAccounts(db);
            CreateInitialSave(acc);
            return null;
        }

        /// <summary>
        /// Name-only accounts (the client's request): a new name starts a new farm on this device, a name that is
        /// already here continues that farm. Progress lives in the game's local storage; nothing is synced.
        /// </summary>
        public Result PlayAs(string username, out string token)
        {
            token = null;
            username = (username ?? "").Trim();
            var error = ValidateUsername(username);
            if (error != null) return Result.Fail(error);
            string lower = username.ToLowerInvariant();
            var db = LoadAccounts();
            var acc = db.accounts.FirstOrDefault(a => a.usernameLower == lower);
            if (acc == null)
            {
                if (BlockedWords.Any(w => lower.Contains(w))) return Result.Fail("Please choose a different username.");
                acc = new AccountRecord
                {
                    id = Guid.NewGuid().ToString("N"), username = username, usernameLower = lower, createdAt = WallNow,
                    tzOffsetMin = WebStorage.LocalUtcOffsetMinutes(),
                };
                db.accounts.Add(acc);
                CreateInitialSave(acc);
            }
            StartSession(acc);
            SaveAccounts(db);
            token = acc.id + ":" + acc.refreshToken;
            return LoadGame(acc);
        }

        /// <summary>Names of the farms saved on this device, most recently played first.</summary>
        public List<string> DeviceFarms() =>
            LoadAccounts().accounts.OrderByDescending(a => Math.Max(a.lastLoginAt, a.createdAt)).Select(a => a.username).ToList();

        public float LockSecondsRemaining(string username)
        {
            var acc = LoadAccounts().accounts.FirstOrDefault(a => a.usernameLower == (username ?? "").Trim().ToLowerInvariant());
            long locked = acc?.lockedUntil ?? 0;
            return Mathf.Max(0, (locked - WallNow) / 1000f);
        }

        /// <summary>AUTH-05/06. On success returns the refresh token to store on the device.</summary>
        public Result Login(string username, string password, out string refreshToken)
        {
            refreshToken = null;
            string lower = (username ?? "").Trim().ToLowerInvariant();
            var db = LoadAccounts();
            var acc = db.accounts.FirstOrDefault(a => a.usernameLower == lower);
            long now = WallNow;

            if (acc != null && acc.lockedUntil > now)
                return Result.Fail("Too many attempts. Try again in " + Mathf.CeilToInt((acc.lockedUntil - now) / 1000f) + "s.");

            bool valid = acc != null && SlowEquals(Hash(password ?? "", Convert.FromBase64String(acc.salt)), acc.hash);
            if (!valid)
            {
                List<long> fails;
                if (acc != null) fails = acc.failedLogins;
                else if (!unknownUserFailures.TryGetValue(lower, out fails)) unknownUserFailures[lower] = fails = new List<long>();
                fails.RemoveAll(t => t < now - 10 * 60000);
                fails.Add(now);
                if (fails.Count >= 5 && acc != null) { acc.lockedUntil = now + 5 * 60000; fails.Clear(); }
                if (acc != null) SaveAccounts(db);
                return Result.Fail("Username or password is incorrect.");
            }

            acc.failedLogins.Clear();
            acc.lockedUntil = 0;
            StartSession(acc);
            SaveAccounts(db);
            refreshToken = acc.id + ":" + acc.refreshToken;
            return LoadGame(acc);
        }

        void StartSession(AccountRecord acc)
        {
            // single active session: a new login replaces any previous session id
            acc.sessionId = RandomToken();
            acc.refreshToken = RandomToken();
            acc.accessExpires = WallNow + 60 * 60000;
            acc.refreshExpires = WallNow + 30L * 24 * 60 * 60000;
            acc.lastLoginAt = WallNow;
        }

        /// <summary>START with a stored session (flow step 2). Returns false when the token is missing or expired.</summary>
        public Result ResumeSession(string stored, out string newToken)
        {
            newToken = null;
            if (string.IsNullOrEmpty(stored) || !stored.Contains(":")) return Result.Fail("");
            var parts = stored.Split(':');
            var db = LoadAccounts();
            var acc = db.accounts.FirstOrDefault(a => a.id == parts[0]);
            if (acc == null || !SlowEquals(acc.refreshToken, parts[1])) return Result.Fail("Your session ended because you logged in elsewhere.");
            if (acc.refreshExpires < WallNow) return Result.Fail("Session expired. Please log in again.");
            StartSession(acc);
            SaveAccounts(db);
            newToken = acc.id + ":" + acc.refreshToken;
            return LoadGame(acc);
        }

        public void Logout()
        {
            if (Save != null) { Advance(); Persist(); }
            if (Account != null)
            {
                var db = LoadAccounts();
                var acc = db.accounts.FirstOrDefault(a => a.id == Account.id);
                if (acc != null) { acc.sessionId = null; acc.refreshToken = null; acc.refreshExpires = 0; SaveAccounts(db); }
            }
            Save = null; Account = null;
            processedTx.Clear(); processedOrder.Clear(); Outbox.Clear();
        }

        /// <summary>Returning to the title keeps the session so START resumes directly.</summary>
        public void Suspend()
        {
            if (Save != null) { Advance(); Persist(); }
            Save = null; Account = null; Outbox.Clear();
        }

        public Result SetTimezone(int offsetMin)
        {
            var db = LoadAccounts();
            var acc = db.accounts.First(a => a.id == Save.accountId);
            if (acc.tzChangedAt > 0 && WallNow - acc.tzChangedAt < 7L * 24 * 60 * 60000)
                return Result.Fail("The timezone can be changed once every 7 days.");
            offsetMin = Mathf.Clamp(offsetMin, -12 * 60, 14 * 60);
            acc.tzOffsetMin = offsetMin; acc.tzChangedAt = WallNow;
            SaveAccounts(db);
            Save.tzOffsetMin = offsetMin;
            Save.lastResetDay = Math.Min(Save.lastResetDay, Today);   // never replays a reset that already ran
            Persist();
            return Result.Ok("Timezone set to UTC" + (offsetMin >= 0 ? "+" : "") + (offsetMin / 60f).ToString("0.#"));
        }

        Result LoadGame(AccountRecord acc)
        {
            string path = SavePath(acc.id);
            if (!File.Exists(path)) CreateInitialSave(acc);
            try { Save = JsonUtility.FromJson<PlayerSave>(File.ReadAllText(path)); }
            catch (Exception e) { Save = null; return Result.Fail("Your save could not be loaded (" + e.Message + "). Please retry."); }
            if (Save == null) return Result.Fail("Your save could not be loaded. Please retry.");
            Account = acc;
            Save.tzOffsetMin = acc.tzOffsetMin;
            // left in a location that was only open for a preview: back home
            if (!OpenAllLocations && !Loc(Save.currentLocation).unlocked) Save.currentLocation = "baguio";
            // saves from before every field had its own look kept Baguio's rocks and stumps everywhere
            foreach (var l in Save.locations)
                foreach (var p in l.plots)
                    if (p.state == PlotState.Blocked && (p.obstacle == null || l.id != "baguio" && (p.obstacle == "rock" || p.obstacle == "stump")))
                        p.obstacle = Defs.Obstacle(l.id, p.index);
            processedTx.Clear(); processedOrder.Clear(); Outbox.Clear();
            CatchUp();
            return Result.Ok();
        }

        void CreateInitialSave(AccountRecord acc)
        {
            var s = new PlayerSave
            {
                accountId = acc.id, username = acc.username, createdAt = acc.createdAt, tzOffsetMin = acc.tzOffsetMin,
                coins = Defs.StartCoins, currentLocation = "baguio", lastSync = acc.createdAt, lastActivity = acc.createdAt,
            };
            foreach (var t in new[] { "tool_can", "tool_shovel", "tool_basket", "tool_axe" }) s.items.Add(new ItemStack { id = t, qty = 1 });
            s.items.Add(new ItemStack { id = "seed_lettuce", qty = 6 });
            s.items.Add(new ItemStack { id = "seed_cabbage", qty = 4 });
            s.items.Add(new ItemStack { id = "seed_carrot", qty = 4 });
            foreach (var def in Defs.Locations)
            {
                var l = new LocationState { id = def.id, unlocked = def.id == "baguio", tank = Defs.TankBase };
                for (int i = 0; i < Defs.MaxPlots; i++)
                    l.plots.Add(new Plot { index = i, state = i < 4 ? PlotState.Empty : PlotState.Blocked, obstacle = Defs.Obstacle(def.id, i) });
                s.locations.Add(l);
            }
            var prev = Save; Save = s;
            Save.lastResetDay = Today;
            GenerateRequests(Loc("baguio"));
            GenerateQuests();
            Save = prev;
            WriteAtomic(SavePath(acc.id), JsonUtility.ToJson(s));
        }
    }
}
