using System;
using System.Collections.Generic;

namespace FieldsOfHope
{
    public enum PlotState { Blocked, Cleared, Empty, Growing, Ready }
    public enum RequestStatus { Open, Completed, Missed }
    public enum EventPhase { Warning, Active, Resolved }

    [Serializable]
    public class AccountRecord
    {
        public string id, username, usernameLower, salt, hash;
        public long createdAt, lastLoginAt;
        public int tzOffsetMin;
        public long tzChangedAt;
        public string sessionId, refreshToken;
        public long accessExpires, refreshExpires;
        public List<long> failedLogins = new List<long>();
        public long lockedUntil;
    }

    [Serializable]
    public class AccountsDb { public List<AccountRecord> accounts = new List<AccountRecord>(); }

    [Serializable]
    public class ItemStack { public string id; public int qty; }

    [Serializable]
    public class Plot
    {
        public int index;
        public PlotState state;
        public string obstacle;          // while Blocked: one of Defs.ObstacleKinds (each location has its own)
        public string crop;
        public float progress, total;    // growth minutes accumulated / needed
        public int waterings;
        public bool fertilized, mulch, trench, cover, pest, tutorial;
        public float yieldMod = 1f;
        public int repeatCount;
        public string lastCrop;
        public int harvestsLeft;
        public bool established;         // orchard tree past establishment
        public float stalledMin;         // minutes stalled by drought while infested (crop-failure risk)
        public int failureWarnings;
        public long plantedAt;
    }

    [Serializable]
    public class Request
    {
        public string id, crop;
        public int qty, delivered, day, coins, cp;
        public long postedAt, deadline;
        public RequestStatus status;
        public bool essential, surge, large, partialUsed, crossRegion;
        public int Remaining => qty - delivered;
    }

    [Serializable]
    public class DayHistory
    {
        public int day, posted, completed;
        public bool delivered;
        public List<string> crops = new List<string>();
        public int meterAdjust;
    }

    [Serializable]
    public class GameEvent
    {
        public string id, type, location;
        public long warnAt, startAt, endAt;
        public EventPhase phase;
        public List<int> plots = new List<int>();
        public bool applied;
        public float stalledMin;
        public string summary;
    }

    [Serializable]
    public class LocationState
    {
        public string id;
        public bool unlocked, eligibleNotified, introShown;
        public List<Plot> plots = new List<Plot>();
        public List<Request> requests = new List<Request>();
        public List<DayHistory> history = new List<DayHistory>();
        public List<GameEvent> events = new List<GameEvent>();
        public float pantryUnits;
        public int meter, stableDays, requestsCompleted;
        public List<string> cropsDelivered = new List<string>();
        public long lastNegativeEventEnd, lastEventRoll;
        public int tank;
        public long wellReadyAt;
        public bool scarecrow;
        public int gatheringDay;         // game day of the last attended gathering
    }

    [Serializable]
    public class Quest
    {
        public string id, kind, title, icon;
        public int target, progress, coins, xp, cp;
        public bool claimed;
        public bool Done => progress >= target;
    }

    [Serializable]
    public class DeliveryLog { public string crop; public long at; }

    [Serializable]
    public class LedgerEntry { public string txId, type, detail; public long at; public int dCoins, dCp, dXp; }

    [Serializable]
    public class NotifRecord { public string title, body, kind; public long at; }

    [Serializable]
    public class PlayerSave
    {
        public string accountId, username;
        public long createdAt;
        public int tzOffsetMin;
        public int level = 1, xp, coins, cp;
        public string currentLocation = "baguio";
        public List<ItemStack> items = new List<ItemStack>();
        public int bonusSlots, smallCrates, largeCrates;
        public bool tankUpgrade;
        public List<LocationState> locations = new List<LocationState>();

        public int questDay;
        public List<Quest> quests = new List<Quest>();
        public List<int> questFullDays = new List<int>();
        public int weeklyBonusDay = -100;

        public bool tutorialDone, tutorialRewarded;
        public int tutorialStep;
        public bool orchardNoteShown, recoveryKitGiven;

        public long lastSync, lastActivity;
        public int lastResetDay, harvestXpDay, harvestXpToday, basketDay, streak;
        public List<DeliveryLog> deliveries = new List<DeliveryLog>();

        public bool sound = true, notifications = true;
        public List<NotifRecord> notifLog = new List<NotifRecord>();
        public List<LedgerEntry> ledger = new List<LedgerEntry>();
        public long devClockOffsetMs;
    }
}
