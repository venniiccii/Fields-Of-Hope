using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace FieldsOfHope
{
    public class Requirement { public string label, progress; public bool met; }
    public class Suggestion { public string id, title, reason, icon; public bool isItem; }

    public partial class GameServer
    {
        // ------------------------------------------------------------------ delivery and market (COMM-03..05)
        public int RequestXp(Request r, int qty)
        {
            float mul = r.essential ? 1.5f : 1f;
            long since = NowMs - Min(24 * 60);
            int repeats = Save.deliveries.Count(d => d.crop == r.crop && d.at >= since);
            float dim = Mathf.Max(0.2f, 1f - 0.2f * repeats);   // PROG-02
            return Mathf.RoundToInt((10 + 2 * qty) * mul * dim);
        }

        public int RequestCp(Request r) => (r.qty / 2) * (r.essential ? 2 : 1) + (r.surge ? 3 : 0);

        DayHistory History(LocationState l, int day)
        {
            var h = l.history.FirstOrDefault(x => x.day == day);
            if (h == null) { l.history.Add(h = new DayHistory { day = day }); l.history.RemoveAll(x => x.day < day - 8); }
            return h;
        }

        public Result Deliver(string tx, string requestId, bool partial) => Do(tx, "deliver", () =>
        {
            var l = Here;
            var r = l.requests.FirstOrDefault(x => x.id == requestId);
            if (r == null || r.status != RequestStatus.Open) return Result.Fail("This request is no longer open.");
            if (NowMs >= r.deadline) return Result.Fail("This request has expired.");
            var c = Defs.Crop(r.crop);
            int stock = Count(c.CropItemId);
            int need = r.Remaining;
            var today = History(l, Today);

            if (stock >= need)
            {
                TakeItem(c.CropItemId, need);
                int xp = RequestXp(r, r.qty);
                int coins = Mathf.RoundToInt(need * c.price * (r.surge ? 1.25f : 1f));
                int cp = RequestCp(r);
                Save.coins += coins; Save.cp += cp;
                r.delivered = r.qty;
                r.status = RequestStatus.Completed;
                l.pantryUnits += need;
                l.requestsCompleted++;
                if (!l.cropsDelivered.Contains(r.crop)) l.cropsDelivered.Add(r.crop);
                today.completed++; today.delivered = true;
                if (!today.crops.Contains(r.crop)) today.crops.Add(r.crop);
                Save.deliveries.Add(new DeliveryLog { crop = r.crop, at = NowMs });
                Save.deliveries.RemoveAll(d => d.at < NowMs - Min(48 * 60));
                AddXp(xp);
                TrackQuest("deliver");
                CheckBalancedBasket();
                RecomputeMeter(l);
                return Result.Ok("Delivered! +" + coins + " coins, +" + xp + " XP, +" + cp + " CP");
            }
            if (!partial) return Result.Fail("Need " + (need - stock) + " more " + c.name);
            if (r.partialUsed) return Result.Fail("A partial delivery was already made for this request.");
            if (stock <= 0) return Result.Fail("You have no " + c.name + " to deliver.");
            TakeItem(c.CropItemId, stock);
            int pay = Mathf.RoundToInt(stock * c.price * (r.surge ? 1.25f : 1f));
            Save.coins += pay;
            r.delivered += stock;
            r.partialUsed = true;
            l.pantryUnits += stock;
            today.delivered = true;
            if (!today.crops.Contains(r.crop)) today.crops.Add(r.crop);
            RecomputeMeter(l);
            return Result.Ok("Partial delivery: +" + pay + " coins. " + r.Remaining + " " + c.name + " still needed.");
        });

        void CheckBalancedBasket()
        {
            if (Save.basketDay == Today) return;
            int dayStart = Today;
            var crops = new HashSet<string>(Save.deliveries.Where(d => LocalDayOf(d.at) == dayStart).Select(d => d.crop));
            if (crops.Count < 3) return;
            Save.basketDay = Today;
            Save.cp += 5;
            AddXp(25);
            Notify("info", "Balanced basket!", "You delivered 3 different crops today: +25 XP, +5 CP.", "icon_basket_reply");
        }

        public int MarketPrice(string cropId) => Mathf.Max(1, Mathf.FloorToInt(Defs.Crop(cropId).price * Defs.MarketRate));

        public Result SellMarket(string tx, string cropItemId, int qty) => Do(tx, "market", () =>
        {
            if (!cropItemId.StartsWith("crop_")) return Result.Fail("Only harvested crops can be sold at the market.");
            if (qty <= 0 || Count(cropItemId) < qty) return Result.Fail("You do not have that many.");
            var c = Defs.Crop(cropItemId.Substring(5));
            TakeItem(cropItemId, qty);
            int pay = MarketPrice(c.id) * qty;
            Save.coins += pay;
            return Result.Ok("Sold " + qty + " " + c.name + " for " + pay + " coins");
        });

        // ------------------------------------------------------------------ shop (SHOP-01..03)
        public int OwnedCount(ShopItem it) => it.id switch
        {
            "crate_small" => Save.smallCrates,
            "crate_large" => Save.largeCrates,
            "tank_upgrade" => Save.tankUpgrade ? 1 : 0,
            "scarecrow" => Here.scarecrow ? 1 : 0,
            _ => Count(it.id)
        };

        public string BuyBlockReason(ShopItem it, int qty)
        {
            if (it.level > Save.level) return "Reach Level " + it.level;
            if (it.needsLocation != null && !Loc(it.needsLocation).unlocked) return "Unlocks with " + Defs.Loc(it.needsLocation).name;
            if (it.id == "tank_upgrade" && Save.currentLocation != "ilocos" && !Loc("ilocos").unlocked) return "Unlocks with Ilocos Norte";
            if (OwnedCount(it) + qty > it.maxOwned) return it.maxOwned == 1 ? "Already owned" : "Limit reached";
            if (Save.coins < it.coins * qty) return "Need " + (it.coins * qty - Save.coins) + " more coins";
            if (Save.cp < it.cp * qty) return "Need " + (it.cp * qty - Save.cp) + " more CP";
            if ((it.kind == ItemKind.Seed || it.kind == ItemKind.Supply) && !HasSpaceFor(it.id, qty)) return "Storage full";
            return null;
        }

        public Result Buy(string tx, string itemId, int qty) => Do(tx, "buy", () =>
        {
            var it = Defs.Item(itemId);
            if (it == null || qty <= 0) return Result.Fail("Unknown item.");
            var reason = BuyBlockReason(it, qty);
            if (reason != null) return Result.Fail(reason);
            Spend(it.coins * qty, it.cp * qty);
            switch (it.id)
            {
                case "crate_small": Save.smallCrates += qty; Save.bonusSlots += 10 * qty; break;
                case "crate_large": Save.largeCrates += qty; Save.bonusSlots += 25 * qty; break;
                case "tank_upgrade": Save.tankUpgrade = true; Loc("ilocos").tank = TankCapacity; break;
                case "scarecrow": Here.scarecrow = true; break;
                default: AddItem(it.id, qty); break;
            }
            return Result.Ok("Bought " + (qty > 1 ? qty + " x " : "") + it.name);
        });

        // ------------------------------------------------------------------ quests (PROG-04)
        void GenerateQuests()
        {
            Save.questDay = Today;
            Save.quests.Clear();
            int lv = Save.level;
            Quest Q(string kind, string title, int target, string icon) => new Quest
            {
                id = Guid.NewGuid().ToString("N").Substring(0, 8), kind = kind, title = title, target = target, icon = icon,
                coins = 30 + rng.Next(0, 11) * 5, xp = 20 + rng.Next(0, 7) * 5, cp = 3 + rng.Next(0, 8),
            };
            Save.quests.Add(lv >= 4 && Save.currentLocation == "baguio"
                ? Q("harvest_hybrid", "Harvest 5 Rare Seed Hybrids", 5, "item_rare_seed")
                : Q("harvest", "Harvest " + Mathf.Min(12, 4 + lv) + " Crops", Mathf.Min(12, 4 + lv), "slot_basket"));
            Save.quests.Add(Q("water", "Water 10 Crops", 10, "slot_can"));
            Save.quests.Add(lv >= 4 ? Q("fertilize", "Use 3 Fertilizer Packs", 3, "item_fertilizer") : Q("plant", "Plant 6 Seeds", 6, "slot_seedbag"));
            Save.quests.Add(LocalDayOfWeek == DayOfWeek.Saturday
                ? Q("gathering", "Attend Community Gathering", 1, "icon_people")
                : Q("deliver", "Complete 3 Community Requests", 3, "icon_basket_reply"));
        }

        public Result ClaimQuest(string tx, string questId) => Do(tx, "quest", () =>
        {
            var q = Save.quests.FirstOrDefault(x => x.id == questId);
            if (q == null || q.claimed) return Result.Fail("Already claimed.");
            if (!q.Done) return Result.Fail("Finish the quest first (" + q.progress + "/" + q.target + ").");
            q.claimed = true;
            Save.coins += q.coins; Save.cp += q.cp;
            AddXp(q.xp);
            if (Save.quests.All(x => x.claimed) && !Save.questFullDays.Contains(Today))
            {
                Save.questFullDays.Add(Today);
                Save.questFullDays.RemoveAll(d => d < Today - 6);
                if (Save.questFullDays.Count >= 5 && Today - Save.weeklyBonusDay >= 7)
                {
                    Save.weeklyBonusDay = Today;
                    Save.coins += 200;
                    Notify("info", "Weekly bonus!", "All quests done on 5 of the last 7 days: +200 coins.", "icon_coin");
                }
            }
            return Result.Ok("+" + q.coins + " coins, +" + q.xp + " XP, +" + q.cp + " CP");
        });

        // ------------------------------------------------------------------ food security (COMM-07, G.6)
        public int CropsAvailableAt(string loc) => Defs.Crops.Count(c => c.location == loc && c.unlockLevel <= Save.level && !c.hybrid);
        public float DailyConsumption(LocationState l) => Mathf.Max(6, 2 * OwnedPlots(l));
        public float PantryDays(LocationState l) => l.pantryUnits / DailyConsumption(l);

        public void RecomputeMeter(LocationState l)
        {
            int today = Today;
            var last3 = l.history.Where(h => h.day > today - 3 && h.day <= today).ToList();
            int posted = last3.Sum(h => h.posted), done = last3.Sum(h => h.completed);
            float coverage = posted > 0 ? (float)done / posted : 0f;
            int variety = last3.SelectMany(h => h.crops).Distinct().Count();
            float varietyScore = Mathf.Clamp01(variety / (float)Mathf.Max(1, Mathf.Min(4, CropsAvailableAt(l.id))));
            float pantry = Mathf.Clamp01(PantryDays(l) / 3f);
            float consistency = l.history.Count(h => h.day > today - 7 && h.day <= today && h.delivered) / 7f;
            int adjust = last3.Sum(h => h.meterAdjust);
            l.meter = Mathf.Clamp(Mathf.RoundToInt(40 * coverage + 25 * varietyScore + 20 * pantry + 15 * consistency + adjust), 0, 100);
        }

        public static string Band(int meter) => meter >= 85 ? "Thriving" : meter >= 60 ? "Stable" : meter >= 30 ? "Strained" : "Critical";
        public static Color BandColor(int meter) => meter >= 85 ? new Color(0.35f, 0.8f, 0.3f) : meter >= 60 ? new Color(0.55f, 0.8f, 0.3f) : meter >= 30 ? new Color(0.95f, 0.7f, 0.2f) : new Color(0.9f, 0.3f, 0.25f);

        // ------------------------------------------------------------------ request generation (COMM-01, G.7)
        void GenerateRequests(LocationState l, bool surgeOnly = false)
        {
            int lv = Save.level;
            var pool = Defs.Crops.Where(c => c.location == l.id && c.unlockLevel <= lv).ToList();
            if (pool.Count == 0) return;
            var h = History(l, Today);
            float plotsFactor = Mathf.Max(4, OwnedPlots(l)) / 4f;
            var used = new Dictionary<string, int>();
            bool essentialUsed = false;

            Request Make(CropDef c, bool large, bool surge)
            {
                float q = c.yield * 0.5f * plotsFactor * (1f + (float)rng.NextDouble() * 0.6f);
                if (large) q *= 2; if (surge) q *= 1.5f;
                var r = new Request
                {
                    id = Guid.NewGuid().ToString("N").Substring(0, 10), crop = c.id, qty = Mathf.Clamp(Mathf.RoundToInt(q), 2, 40),
                    day = Today, postedAt = NowMs, large = large, surge = surge,
                    deadline = NowMs + Min(60 * (surge ? 12 : large ? 48 : 24)),
                    crossRegion = c.location != l.id,
                };
                if (!essentialUsed && c.essential && !surge) { r.essential = true; essentialUsed = true; }
                r.coins = Mathf.RoundToInt(r.qty * c.price * (surge ? 1.25f : 1f));
                r.cp = RequestCp(r);
                used[c.id] = (used.TryGetValue(c.id, out var u) ? u : 0) + 1;
                h.posted++;
                l.requests.Add(r);
                return r;
            }

            CropDef Pick(List<CropDef> from)
            {
                var candidates = from.Where(c => !used.TryGetValue(c.id, out var u) || u < 2).ToList();
                if (candidates.Count == 0) candidates = from;
                // favour crops the pantry has seen least of recently
                var weights = candidates.Select(c => 1f / (1f + l.history.Where(x => x.day > Today - 3).Count(x => x.crops.Contains(c.id)) * 1.5f)).ToList();
                float roll = (float)rng.NextDouble() * weights.Sum();
                for (int i = 0; i < candidates.Count; i++) { roll -= weights[i]; if (roll <= 0) return candidates[i]; }
                return candidates[candidates.Count - 1];
            }

            if (surgeOnly)
            {
                int n = rng.Next(1, 3);
                for (int i = 0; i < n; i++) Make(Pick(pool), false, true);
                return;
            }
            int count = Mathf.Min(3 + lv / 3, 6);
            var staples = pool.Where(c => c.essential).ToList();
            for (int i = 0; i < count; i++)
            {
                var c = i == 0 && staples.Count > 0 ? staples[rng.Next(staples.Count)] : Pick(pool);
                if (i == count - 1 && lv >= 7)
                {
                    var foreign = Defs.Crops.Where(x => x.location != l.id && Loc(x.location).unlocked && x.unlockLevel <= lv && !x.hybrid).ToList();
                    if (foreign.Count > 0) c = foreign[rng.Next(foreign.Count)];
                }
                Make(c, count >= 4 && i == 1, false);
            }
        }

        // ------------------------------------------------------------------ tutorial (TUT-01/02)
        public void SetTutorialStep(int step) { if (Save != null && !Save.tutorialDone) { Save.tutorialStep = step; Persist(); } }

        public Request EnsureTutorialRequest()
        {
            var l = Loc("baguio");
            var r = l.requests.FirstOrDefault(x => x.id == "tutorial");
            if (r != null) return r;
            r = new Request
            {
                id = "tutorial", crop = "lettuce", qty = 4, day = Today, postedAt = NowMs, deadline = NowMs + Min(24 * 60),
                essential = true, coins = 20,
            };
            r.cp = RequestCp(r);
            l.requests.Insert(0, r);
            History(l, Today).posted++;
            Persist();
            return r;
        }

        public Result CompleteTutorial(string tx) => Do(tx, "tutorial", () =>
        {
            Save.tutorialDone = true;
            if (Save.tutorialRewarded) return Result.Ok("Tutorial complete");
            Save.tutorialRewarded = true;
            Save.coins += 50;
            AddItem("fertilizer", 1);
            return Result.Ok("Tutorial complete! +50 coins, +1 Fertilizer Pack");
        });

        public void ReplayTutorial() { Save.tutorialDone = false; Save.tutorialStep = 0; Persist(); }

        // ------------------------------------------------------------------ locations (LOC-02, MAP-02/03, G.5)
        public List<Requirement> UnlockRequirements(string locId)
        {
            var list = new List<Requirement>();
            void Add(string label, bool met, string progress) => list.Add(new Requirement { label = label, met = met, progress = progress });
            if (locId == "ilocos")
            {
                var b = Loc("baguio");
                Add("Reach Level 5", Save.level >= 5, "Level " + Save.level);
                Add("Baguio Stable (60+) for 3 days in a row", b.stableDays >= 3, b.stableDays + "/3 days");
                Add("15 requests completed in Baguio", b.requestsCompleted >= 15, b.requestsCompleted + "/15");
                Add("Deliver at least 4 different crops in Baguio", b.cropsDelivered.Count >= 4, b.cropsDelivered.Count + "/4 crops");
                Add("Own 8 or more plots in Baguio", OwnedPlots(b) >= 8, OwnedPlots(b) + "/8 plots");
            }
            else if (locId == "davao")
            {
                var il = Loc("ilocos"); var b = Loc("baguio");
                Add("Ilocos Norte unlocked", il.unlocked, il.unlocked ? "Done" : "Locked");
                Add("Reach Level 10", Save.level >= 10, "Level " + Save.level);
                Add("Ilocos Norte Stable for 3 days in a row", il.stableDays >= 3, il.stableDays + "/3 days");
                Add("20 requests completed in Ilocos Norte", il.requestsCompleted >= 20, il.requestsCompleted + "/20");
                Add("Deliver at least 4 different crops in Ilocos Norte", il.cropsDelivered.Count >= 4, il.cropsDelivered.Count + "/4 crops");
                Add("Baguio at least Strained (30+)", b.meter >= 30, "Baguio " + b.meter);
            }
            return list;
        }

        public bool IsEligible(string locId) => !Loc(locId).unlocked && UnlockRequirements(locId).All(r => r.met);

        void CheckEligibility()
        {
            foreach (var def in Defs.Locations.Where(d => d.fee > 0))
            {
                var l = Loc(def.id);
                if (l.unlocked || l.eligibleNotified || !IsEligible(def.id)) continue;
                l.eligibleNotified = true;
                Notify("info", def.name + " is now open for farming!", "Open the Map to pay the " + def.fee.ToString("N0") + " coin settlement fee.", "hud_map");
            }
        }

        public Result PayUnlock(string tx, string locId) => Do(tx, "unlock", () =>
        {
            var def = Defs.Loc(locId); var l = Loc(locId);
            if (l.unlocked) return Result.Fail(def.name + " is already open.");
            if (!IsEligible(locId)) return Result.Fail("Not all requirements are met yet.");
            if (Save.coins < def.fee) return Result.Fail("Need " + (def.fee - Save.coins) + " more coins.");
            Spend(def.fee);
            l.unlocked = true;
            l.tank = TankCapacity;
            GenerateRequests(l);
            RecomputeMeter(l);
            return Result.Ok(def.name + " is unlocked! Tap its pin to travel.");
        });

        /// <summary>
        /// Evaluation previews can open every location for inspection without unlocking it in the save, so closing them
        /// again later is just turning this off (anyone standing in a still-locked place goes back to Baguio on load).
        /// </summary>
        public static bool OpenAllLocations;

        public bool CanVisit(string locId) => Loc(locId).unlocked || OpenAllLocations;

        public Result Travel(string tx, string locId) => Do(tx, "travel", () =>
        {
            var l = Loc(locId);
            if (!CanVisit(locId)) return Result.Fail(Defs.Loc(locId).name + " is locked.");
            if (Save.currentLocation == locId) return Result.Fail("You are already here.");
            Save.currentLocation = locId;
            if (!l.unlocked && l.requests.Count == 0) GenerateRequests(l);   // a preview visit: the community has requests too
            return Result.Ok("Welcome to " + Defs.Loc(locId).name + "!");
        });

        // ------------------------------------------------------------------ community gathering (I.2)
        public bool GatheringOpen
        {
            get { var t = LocalTime; return t.DayOfWeek == DayOfWeek.Saturday && t.Hour >= 10 && t.Hour < 22; }
        }

        public Result AttendGathering(string tx, string cropItemId) => Do(tx, "gathering", () =>
        {
            if (!GatheringOpen) return Result.Fail("The Community Gathering is on Saturdays, 10:00 to 22:00.");
            if (Here.gatheringDay == GameDay) return Result.Fail("You already attended today's gathering here.");
            if (!TakeItem(cropItemId, 1)) return Result.Fail("Bring one harvested crop to share.");
            Here.gatheringDay = GameDay;
            Save.cp += 10;
            History(Here, Today).meterAdjust += 5;
            AddXp(30);
            TrackQuest("gathering");
            RecomputeMeter(Here);
            return Result.Ok("Thanks for sharing! +30 XP, +10 CP, +5 food security");
        });

        // ------------------------------------------------------------------ farming suggestions (PROG-05)
        public List<Suggestion> PlantSuggestions()
        {
            var crops = Defs.Crops.Where(c => c.location == Save.currentLocation && c.unlockLevel <= Save.level).ToList();
            var open = Here.requests.Where(r => r.status == RequestStatus.Open).ToList();
            var scored = new List<(CropDef c, float score, string reason)>();
            foreach (var c in crops)
            {
                int need = open.Where(r => r.crop == c.id).Sum(r => r.Remaining) - Count(c.CropItemId);
                float perMin = c.Profit / (c.growMin + (c.orchard ? c.regrowMin * (c.harvests - 1) : 0));
                if (need > 0) scored.Add((c, 100 + need, "Needed by the community (" + need + " more)"));
                scored.Add((c, perMin * 10, "High profit next season"));
                if (c.growMin <= 10) scored.Add((c, 30 - c.growMin, "Fast growth for quests"));
                scored.Add((c, c.yield * (c.essential ? 2 : 1) * 2, c.essential ? "Staple food: best Community Points" : "Best Community Points"));
            }
            return scored.OrderByDescending(s => s.score).GroupBy(s => s.c.id).Select(g => g.First()).Take(4)
                .Select(s => new Suggestion { id = s.c.id, title = s.c.name, reason = s.reason, icon = s.c.icon }).ToList();
        }

        public List<Suggestion> UseSuggestions()
        {
            var list = new List<Suggestion>();
            var l = Here;
            int dry = l.plots.Count(p => p.state == PlotState.Growing && !IsWatered(p));
            if (dry > 0) list.Add(new Suggestion { id = "tool_can", title = "Watering Can", reason = dry + " dry plot(s) grow at half speed", icon = "slot_can", isItem = true });
            if (l.plots.Any(p => p.state == PlotState.Growing && FatiguePenaltyPct(p) > 0 && !p.fertilized))
                list.Add(new Suggestion { id = "fertilizer", title = "Fertilizer Pack", reason = "Critical for soil health (fatigue)", icon = "item_fertilizer", isItem = true });
            if (LocationHasEvent(l, "rain")) list.Add(new Suggestion { id = "rain_cover", title = "Shovel or Rain Cover", reason = "Heavy rain is coming: protect plots", icon = "item_rain_cover", isItem = true });
            if (l.plots.Any(p => p.pest)) list.Add(new Suggestion { id = "pest_spray", title = "Pest Spray", reason = "Pests cut yield by 25% until treated", icon = "item_pest_spray", isItem = true });
            if (LocationHasEvent(l, "drought")) list.Add(new Suggestion { id = "mulch", title = "Mulch", reason = "Drought: halves water need", icon = "item_mulch", isItem = true });
            if (list.Count == 0) list.Add(new Suggestion { id = "fertilizer", title = "Fertilizer Pack", reason = "+20% yield on your next planting", icon = "item_fertilizer", isItem = true });
            return list;
        }
    }
}
