using System;
using System.Runtime.InteropServices;

namespace FieldsOfHope
{
    /// <summary>Browser helpers for WebGL builds; plain .NET equivalents elsewhere.</summary>
    public static class WebStorage
    {
#if UNITY_WEBGL && !UNITY_EDITOR
        [DllImport("__Internal")] static extern void FoH_SyncFs();
        [DllImport("__Internal")] static extern int FoH_TzOffsetMinutes();
        public static void Flush() => FoH_SyncFs();
        public static int LocalUtcOffsetMinutes() => FoH_TzOffsetMinutes();
#else
        public static void Flush() { }
        public static int LocalUtcOffsetMinutes() => (int)TimeZoneInfo.Local.GetUtcOffset(DateTime.UtcNow).TotalMinutes;
#endif
    }
}
