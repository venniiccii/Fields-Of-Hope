using System;
using System.Linq;
using UnityEngine;

namespace FieldsOfHope
{
    public partial class GameServer
    {
        public Plot PlotAt(int index) => Here.plots[index];

        /// <summary>Why a crop cannot be planted here, or null when it can (FARM-05, LOC-01).</summary>
        public string PlantBlockReason(CropDef c, bool checkSeeds = true)
        {
            if (c.location != Save.currentLocation)
                return c.name + " needs " + Defs.Loc(c.location).name + "'s " + Defs.Loc(c.location).climate.ToLowerInvariant() + " climate.";
            if (c.unlockLevel > Save.level) return "Reach Level " + c.unlockLevel + " to grow " + c.name + ".";
            if (checkSeeds && Count(c.SeedId) <= 0) return "You have no " + c.name + " seeds. Buy some in the Community Shop.";
            return null;
        }

        public int FatiguePenaltyPct(Plot p) => p.repeatCount >= 3 ? Mathf.Min(30, 10 * (p.repeatCount - 2)) : 0;

        public int WateringsRequired(Plot p) => WateringsRequiredIn(Here, p);

        public bool IsWatered(Plot p) => ActiveEvent(Here, "rain") != null || p.waterings >= WateringsRequired(p);

        public int ExpectedYield(Plot p)
        {
            var c = Defs.Crop(p.crop);
            if (c == null) return 0;
            float y = c.yield * (p.fertilized ? 1.2f : 1f) * (1f - FatiguePenaltyPct(p) / 100f) * p.yieldMod * (p.pest ? 0.75f : 1f);
            return Mathf.Max(1, Mathf.RoundToInt(y));
        }

        public Result Plant(string tx, int index, string cropId, bool useFertilizer) => Do(tx, "plant", () =>
        {
            var p = PlotAt(index);
            var c = Defs.Crop(cropId);
            if (c == null) return Result.Fail("Unknown crop.");
            if (p.state == PlotState.Blocked) return Result.Fail("Clear this plot with the axe first.");
            if (p.state == PlotState.Cleared) return Result.Fail("Buy this plot before planting.");
            if (p.state != PlotState.Empty) return Result.Fail("This plot is already in use.");
            var reason = PlantBlockReason(c);
            if (reason != null) return Result.Fail(reason);
            if (useFertilizer && !Has("fertilizer")) return Result.Fail("You have no Fertilizer Packs.");

            TakeItem(c.SeedId, 1);
            p.repeatCount = p.lastCrop == c.id ? p.repeatCount + 1 : 1;
            p.lastCrop = c.id;
            p.crop = c.id;
            p.state = PlotState.Growing;
            p.progress = 0;
            p.total = c.growMin;
            p.waterings = 0;
            p.mulch = p.pest = p.trench = p.cover = false;
            p.yieldMod = 1f;
            p.stalledMin = 0; p.failureWarnings = 0;
            p.harvestsLeft = c.harvests;
            p.established = !c.orchard;
            p.plantedAt = NowMs;
            p.tutorial = !Save.tutorialDone && c.id == "lettuce" && Here.plots.All(o => !o.tutorial || o == p);
            if (p.tutorial) p.total = Defs.TutorialLettuceSeconds / 60f;
            p.fertilized = false;
            if (useFertilizer) { TakeItem("fertilizer", 1); p.fertilized = true; p.repeatCount = 0; TrackQuest("fertilize"); }

            TrackQuest("plant");
            Notify("info", "New crop planted!", "Your seeds are growing.", "icon_sprout_notif");
            if (FatiguePenaltyPct(p) > 0)
                Notify("warn", "Soil fatigue", c.name + " has grown here " + p.repeatCount + " times in a row: -" + FatiguePenaltyPct(p) + "% yield. Rotate crops or use fertilizer.", "icon_bug");
            if (c.orchard && !Save.orchardNoteShown)
            {
                Save.orchardNoteShown = true;
                Notify("info", "Time is compressed", "Real " + c.name.ToLowerInvariant() + " trees take months to years. The game shortens this to minutes.", "tree_young");
            }
            return Result.Ok("Planted " + c.name);
        });

        public Result Water(string tx, int index) => Do(tx, "water", () =>
        {
            var p = PlotAt(index);
            if (p.state != PlotState.Growing) return Result.Fail(p.state == PlotState.Ready ? "This crop is ready to harvest." : "There is nothing to water here.");
            var def = HereDef;
            if (ActiveEvent(Here, "rain") != null) return Result.Fail("The rain is watering your crops.");
            int max = def.waterings >= 2 && !p.mulch ? 2 : 1;
            if (p.waterings >= max) return Result.Fail("This plot is already watered.");
            if (max == 2 && p.waterings == 1 && p.progress < p.total / 2f) return Result.Fail("Water again in the second half of growth.");
            if (def.waterings >= 2)
            {
                if (Here.tank <= 0) return Result.Fail("The water tank is empty. Refill it at the well.");
                Here.tank--;
            }
            p.waterings++;
            TrackQuest("water");
            return Result.Ok(def.waterings == 0 ? "Watered. Davao's humid soil rarely needs it." : "Watered");
        });

        public Result Harvest(string tx, int index) => Do(tx, "harvest", () =>
        {
            var p = PlotAt(index);
            if (p.state != PlotState.Ready) return Result.Fail("This crop is not ready yet.");
            var c = Defs.Crop(p.crop);
            int qty = ExpectedYield(p);
            if (!HasSpaceFor(c.CropItemId, qty)) return Result.Fail("STORAGE_FULL");
            AddItem(c.CropItemId, qty);

            if (Save.harvestXpDay != Today) { Save.harvestXpDay = Today; Save.harvestXpToday = 0; }
            if (Save.harvestXpToday < 20) { Save.harvestXpToday++; AddXp(1); }
            TrackQuest("harvest");
            if (c.hybrid) TrackQuest("harvest_hybrid");

            if (c.orchard && --p.harvestsLeft > 0)
            {
                p.state = PlotState.Growing;
                p.established = true;
                p.progress = 0; p.total = c.regrowMin; p.waterings = 0;
                p.yieldMod = 1f; p.pest = false;
            }
            else ClearCrop(p);
            return Result.Ok("+" + qty + " " + c.name);
        });

        void ClearCrop(Plot p)
        {
            p.state = PlotState.Empty;
            p.crop = null;
            p.progress = p.total = 0;
            p.waterings = 0;
            p.fertilized = p.mulch = p.pest = p.tutorial = false;
            p.yieldMod = 1f;
            p.harvestsLeft = 0;
        }

        public Result Fertilize(string tx, int index) => Do(tx, "fertilize", () =>
        {
            var p = PlotAt(index);
            if (p.state != PlotState.Growing) return Result.Fail("Fertilizer is applied to a growing crop or at planting.");
            if (p.fertilized) return Result.Fail("This crop is already fertilized.");
            if (!TakeItem("fertilizer", 1)) return Result.Fail("You have no Fertilizer Packs. Buy them in the Supplies tab.");
            p.fertilized = true;
            p.repeatCount = 0;
            TrackQuest("fertilize");
            return Result.Ok("Fertilized: +20% yield, soil refreshed");
        });

        public Result ClearObstacle(string tx, int index) => Do(tx, "clear", () =>
        {
            var p = PlotAt(index);
            if (p.state != PlotState.Blocked) return Result.Fail("There is nothing to clear here.");
            if (!Has("tool_axe")) return Result.Fail("You need an axe.");
            p.state = PlotState.Cleared;
            return Result.Ok("Land cleared. This plot can now be bought.");
        });

        public int NextPlotNumber(LocationState l) => OwnedPlots(l) + 1;

        public Result BuyPlot(string tx, int index) => Do(tx, "buy_plot", () =>
        {
            var p = PlotAt(index);
            if (p.state == PlotState.Blocked) return Result.Fail("Clear the land with the axe first.");
            if (p.state != PlotState.Cleared) return Result.Fail("You already own this plot.");
            int n = NextPlotNumber(Here);
            if (n > Defs.MaxPlots) return Result.Fail("This farm has reached its 12-plot limit.");
            if (Save.level < Defs.PlotLevels[n]) return Result.Fail("Reach Level " + Defs.PlotLevels[n] + " to buy plot " + n + ".");
            int price = Defs.PlotPrice(Save.currentLocation, n);
            if (Save.coins < price) return Result.Fail("Need " + (price - Save.coins) + " more coins.");
            Spend(price);
            p.state = PlotState.Empty;
            p.lastCrop = null; p.repeatCount = 0;
            return Result.Ok("Plot " + n + " is yours!");
        });

        public Result DigTrench(string tx, int index) => Do(tx, "trench", () =>
        {
            if (!LocationHasEvent(Here, "rain")) return Result.Fail("No heavy rain is expected. Dig drainage trenches when a rain warning appears.");
            var p = PlotAt(index);
            if (p.state < PlotState.Empty) return Result.Fail("You do not own this plot.");
            if (Has("tool_spade"))
            {
                foreach (var o in Here.plots.Where(o => o.state >= PlotState.Empty)) o.trench = true;
                return Result.Ok("Gilded Spade: every plot is drained!");
            }
            if (p.trench || p.cover) return Result.Fail("This plot is already protected.");
            p.trench = true;
            return Result.Ok("Drainage trench dug");
        });

        public Result UseOnPlot(string tx, int index, string item) => Do(tx, "use_" + item, () =>
        {
            var p = PlotAt(index);
            switch (item)
            {
                case "rain_cover":
                    if (!LocationHasEvent(Here, "rain")) return Result.Fail("Rain covers are placed when heavy rain is coming.");
                    if (p.state < PlotState.Empty) return Result.Fail("You do not own this plot.");
                    if (p.cover || p.trench) return Result.Fail("This plot is already protected.");
                    if (!TakeItem("rain_cover", 1)) return Result.Fail("You have no Rain Covers.");
                    p.cover = true;
                    return Result.Ok("Rain cover placed");
                case "pest_spray":
                    if (!p.pest) return Result.Fail("This plot has no pests.");
                    if (!TakeItem("pest_spray", 1)) return Result.Fail("You have no Pest Spray.");
                    p.pest = false; p.stalledMin = 0;
                    return Result.Ok("Pests treated");
                case "mulch":
                    if (p.state != PlotState.Growing) return Result.Fail("Mulch is spread on a growing crop.");
                    if (p.mulch) return Result.Fail("This plot is already mulched.");
                    if (!TakeItem("mulch", 1)) return Result.Fail("You have no Mulch.");
                    p.mulch = true;
                    return Result.Ok("Mulched: this crop needs half the water");
            }
            return Result.Fail("That item cannot be used here.");
        });

        public int TankCapacity => Save.tankUpgrade ? Defs.TankUpgraded : Defs.TankBase;

        public Result RefillTank(string tx) => Do(tx, "well", () =>
        {
            if (HereDef.waterings < 2) return Result.Fail("There is no well on this farm.");
            if (Here.tank >= TankCapacity) return Result.Fail("The tank is already full.");
            if (NowMs < Here.wellReadyAt) return Result.Fail("The well refills in " + FormatDuration((Here.wellReadyAt - NowMs) / 60000f) + ".");
            Here.tank = TankCapacity;
            bool drought = ActiveEvent(Here, "drought") != null;
            Here.wellReadyAt = NowMs + Min(Defs.WellCooldownMin * (drought ? 2 : 1));
            return Result.Ok("Water tank refilled" + (drought ? " (drought: the well is slow)" : ""));
        });

        /// <summary>Growth for one plot over dtMin minutes at time t (FARM-06/07).</summary>
        void GrowPlot(LocationState l, Plot p, float dtMin, long t, bool online)
        {
            if (p.state != PlotState.Growing) return;
            bool rain = ActiveEvent(l, "rain") != null;
            bool drought = ActiveEvent(l, "drought") != null;
            bool watered = rain || p.waterings >= WateringsRequiredIn(l, p);
            float rate = watered ? 1f : Defs.UnwateredRate;
            bool stalled = false;
            if (drought && !watered) { rate = p.mulch ? 0.5f : 0f; stalled = rate == 0f; }
            if (p.pest) rate *= 0.7f;
            p.progress += rate * dtMin;

            if (stalled && p.pest && online && !catchingUp) CheckCropFailure(l, p, dtMin);
            if (p.progress >= p.total)
            {
                p.progress = p.total;
                p.state = PlotState.Ready;
                if (catchingUp) awayReady++;
                else if (l.id == Save.currentLocation) Notify("info", Defs.Crop(p.crop).name + " is ready!", "Harvest it with the basket.", Defs.Crop(p.crop).icon);
            }
        }

        int WateringsRequiredIn(LocationState l, Plot p)
        {
            int need = Defs.Loc(l.id).waterings;
            if (need == 0) return 0;
            if (need >= 2 && !p.mulch) return p.progress < p.total / 2f ? 1 : 2;
            return 1;
        }

        void CheckCropFailure(LocationState l, Plot p, float dtMin)
        {
            p.stalledMin += dtMin;
            var name = Defs.Crop(p.crop).name;
            if (p.stalledMin >= 10 && p.failureWarnings == 0)
            { p.failureWarnings = 1; Notify("warn", "Crop at risk!", name + " has pests and no water. Spray or water it now."); }
            else if (p.stalledMin >= 20 && p.failureWarnings == 1)
            { p.failureWarnings = 2; Notify("warn", "Last warning!", name + " will fail in 10 minutes without water or pest spray."); }
            else if (p.stalledMin >= 30)
            {
                ClearCrop(p);
                string kit = "";
                if (!Save.recoveryKitGiven)
                {
                    Save.recoveryKitGiven = true;
                    var cheap = Defs.Crops.Where(c => c.location == l.id && c.unlockLevel <= Save.level).OrderBy(c => c.seedPrice).First();
                    AddItem(cheap.SeedId, 3);
                    kit = " A free Recovery Seed Kit (3 " + cheap.name + " seeds) was added to your inventory.";
                }
                Notify("warn", "Crop failure", name + " was lost to pests during the drought. Treating pests and saving water would have helped." + kit);
            }
        }
    }
}
