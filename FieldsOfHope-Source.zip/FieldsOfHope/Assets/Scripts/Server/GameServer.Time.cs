using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace FieldsOfHope
{
    public partial class GameServer
    {
        bool catchingUp;
        int awayReady, awayMissed, awayEvents;
        long advancedTo;

        /// <summary>TIME-02 / J.4: apply time elapsed since the last sync and build the "While you were away" summary.</summary>
        void CatchUp()
        {
            AwaySummary.Clear();
            advancedTo = Math.Max(Save.lastSync, Save.createdAt);
            float awayMin = (NowMs - advancedTo) / 60000f;
            int startDay = Save.lastResetDay;
            catchingUp = true; awayReady = awayMissed = awayEvents = 0;
            Advance();
            catchingUp = false;
            foreach (var l in Save.locations.Where(l => l.unlocked)) RecomputeMeter(l);
            if (awayMin >= 1 && Save.tutorialDone)
            {
                AwaySummary.Add("You were away for " + FormatDuration(awayMin) + ".");
                int ready = Save.locations.Sum(l => l.plots.Count(p => p.state == PlotState.Ready));
                if (ready > 0) AwaySummary.Add(ready + " crop(s) are ready to harvest.");
                if (awayMissed > 0) AwaySummary.Add(awayMissed + " community request(s) expired and were marked Missed.");
                if (awayEvents > 0) AwaySummary.Add(awayEvents + " event(s) ended while you were away (losses capped at 25%).");
                if (Save.lastResetDay > startDay) AwaySummary.Add("A new day began: fresh community requests and Daily Quests are waiting.");
                var expiring = Save.locations.Where(l => l.unlocked).SelectMany(l => l.requests)
                    .Count(r => r.status == RequestStatus.Open && r.deadline - NowMs < Min(3 * 60));
                if (expiring > 0) AwaySummary.Add(expiring + " request(s) expire within 3 hours.");
            }
            Persist();
        }

        /// <summary>Moves the world forward to the server clock in steps of at most one minute.</summary>
        public void Advance()
        {
            if (Save == null) return;
            long now = NowMs;
            if (advancedTo == 0) advancedTo = Math.Max(Save.lastSync, Save.createdAt);
            if (now <= advancedTo) return;
            bool wasCatching = catchingUp;
            if (now - advancedTo > Min(5)) catchingUp = true;   // long gaps (sleep, dev skip) resolve with offline rules
            while (advancedTo < now)
            {
                long t = Math.Min(now, advancedTo + 60000);
                float dt = (t - advancedTo) / 60000f;
                Step(t, dt);
                advancedTo = t;
            }
            catchingUp = wasCatching;
        }

        void Step(long t, float dtMin)
        {
            int day = LocalDayOf(t);
            if (day > Save.lastResetDay) DailyReset(day, t);
            bool online = t - Save.lastActivity <= Min(30);

            foreach (var l in Save.locations)
            {
                if (!l.unlocked && !(OpenAllLocations && l.id == Save.currentLocation)) continue;   // a preview visit still grows
                UpdateEvents(l, t, dtMin, online);
                foreach (var p in l.plots) GrowPlot(l, p, dtMin, t, online);
                l.pantryUnits = Mathf.Max(0, l.pantryUnits - DailyConsumption(l) * dtMin / 1440f);
                foreach (var r in l.requests.Where(r => r.status == RequestStatus.Open && r.deadline <= t))
                {
                    r.status = RequestStatus.Missed;
                    History(l, day).meterAdjust -= r.surge ? 5 : 2;
                    if (catchingUp) awayMissed++;
                    else Notify("warn", "Request missed", Defs.Crop(r.crop).name + " x" + r.qty + " for " + Defs.Loc(l.id).name + " expired.", Defs.Crop(r.crop).icon);
                    RecomputeMeter(l);
                }
                if (online && !catchingUp && Save.tutorialDone && Save.level >= 2 && t - l.lastEventRoll >= Min(10))
                {
                    l.lastEventRoll = t;
                    RollEvent(l, t);
                }
            }
            if (!catchingUp) CheckEligibility();
        }

        // ------------------------------------------------------------------ daily reset (TIME-03, J.4 step 5)
        void DailyReset(int day, long t)
        {
            for (int d = Save.lastResetDay + 1; d <= day; d++)
            {
                bool anyStable = false;
                foreach (var l in Save.locations.Where(l => l.unlocked))
                {
                    RecomputeMeter(l);
                    if (l.meter >= 60) { l.stableDays++; anyStable = true; } else l.stableDays = 0;
                }
                if (anyStable) { Save.streak++; AddXp(Mathf.Min(20 * Save.streak, 100)); } else Save.streak = 0;
            }
            Save.lastResetDay = day;
            foreach (var l in Save.locations.Where(l => l.unlocked))
            {
                l.requests.RemoveAll(r => r.status != RequestStatus.Open && r.day < day);
                var yesterday = l.history.FirstOrDefault(h => h.day == day - 1);
                bool failedDay = yesterday != null && yesterday.posted > 0 && yesterday.completed * 2 < yesterday.posted;
                GenerateRequests(l);
                if (Save.tutorialDone && Save.level >= 2 && (failedDay || PantryDays(l) < 1f) && rng.NextDouble() < 0.5)
                {
                    GenerateRequests(l, surgeOnly: true);
                    if (!catchingUp) Notify("warn", "Demand surge!", Defs.Loc(l.id).name + " urgently needs food. Extra requests pay +25% for 12 hours.", "icon_people");
                }
                RecomputeMeter(l);
            }
            GenerateQuests();
            if (!catchingUp)
            {
                Notify("info", "A new day begins", "Fresh community requests and Daily Quests are ready.", "icon_sun");
                if (LocalDayOfWeek == DayOfWeek.Friday)
                    Notify("info", "Community Gathering tomorrow", "Saturday 10:00 to 22:00. Bring one crop to share.", "icon_people");
            }
        }

        // ------------------------------------------------------------------ environmental events (I.1, I.2)
        void RollEvent(LocationState l, long t)
        {
            if (l.events.Any(e => e.phase != EventPhase.Resolved)) return;
            if (t - l.lastNegativeEventEnd < Min(4 * 60)) return;
            var def = Defs.Loc(l.id);
            double roll = rng.NextDouble();
            int today = LocalDayOf(t);

            bool rainToday = l.events.Any(e => e.type == "rain" && LocalDayOf(e.warnAt) == today);
            if (!rainToday && roll < def.rainChance) { StartEvent(l, "rain", t); return; }
            roll -= def.rainChance;

            var growing = l.plots.Where(p => p.state == PlotState.Growing).ToList();
            var biggest = growing.GroupBy(p => p.crop).OrderByDescending(g => g.Count()).FirstOrDefault();
            if (biggest != null && biggest.Count() >= 2)
            {
                float mono = growing.Count > 0 ? biggest.Count() / (float)growing.Count : 0;
                float chance = def.pestChance * (0.5f + mono) * (l.scarecrow ? 0.75f : 1f);
                if (roll < chance) { StartEvent(l, "pest", t); return; }
                roll -= chance;
            }
            if (roll < def.droughtChance) StartEvent(l, "drought", t);
        }

        public GameEvent StartEvent(LocationState l, string type, long t)
        {
            var e = new GameEvent { id = Guid.NewGuid().ToString("N").Substring(0, 8), type = type, location = l.id, warnAt = t };
            switch (type)
            {
                case "rain":
                    e.startAt = t + Min(30); e.endAt = e.startAt + Min(20); e.phase = EventPhase.Warning;
                    Notify("warn", "Heavy rain is coming!", "Protect your crops! Dig trenches with the shovel or place Rain Covers.", "icon_rain", e.id);
                    break;
                case "drought":
                    e.startAt = t + Min(60); e.endAt = e.startAt + Min(120); e.phase = EventPhase.Warning;
                    Notify("warn", "Drought is coming!", "Fill the tank and mulch your plots. Unwatered crops will stop growing.", "icon_sun", e.id);
                    break;
                case "pest":
                    var target = l.plots.Where(p => p.state == PlotState.Growing).GroupBy(p => p.crop).OrderByDescending(g => g.Count()).First().ToList();
                    int n = Mathf.Clamp(rng.Next(2, 5), 1, target.Count);
                    foreach (var p in target.OrderBy(_ => rng.Next()).Take(n)) { p.pest = true; e.plots.Add(p.index); }
                    e.startAt = t; e.endAt = t + Min(60); e.phase = EventPhase.Active; e.applied = true;
                    Notify("warn", "Pest outbreak!", n + " " + Defs.Crop(target[0].crop).name + " plot(s) infested. Apply Pest Spray within 60 min.", "icon_bug", e.id);
                    break;
            }
            l.events.Add(e);
            l.events.RemoveAll(x => x.phase == EventPhase.Resolved && x.endAt < t - Min(24 * 60));
            return e;
        }

        void UpdateEvents(LocationState l, long t, float dtMin, bool online)
        {
            foreach (var e in l.events)
            {
                if (e.phase == EventPhase.Warning && t >= e.startAt)
                {
                    e.phase = EventPhase.Active;
                    if (e.type == "rain") ApplyRain(l, e);
                }
                if (e.phase == EventPhase.Active && e.type == "drought")
                {
                    if (l.plots.Any(p => p.state == PlotState.Growing && !p.mulch && p.waterings < WateringsRequiredIn(l, p)))
                        e.stalledMin += dtMin;
                }
                if (e.phase == EventPhase.Active && t >= e.endAt) ResolveEvent(l, e);
            }
        }

        void ApplyRain(LocationState l, GameEvent e)
        {
            e.applied = true;
            foreach (var p in l.plots.Where(p => p.state == PlotState.Growing || p.state == PlotState.Ready))
            {
                bool protectedPlot = p.trench || p.cover;
                var c = Defs.Crop(p.crop);
                if (!protectedPlot)
                {
                    e.plots.Add(p.index);
                    if (c.rootOrLeafy) p.yieldMod *= 0.85f;
                    if (p.state == PlotState.Ready) p.yieldMod *= 0.9f;
                    p.yieldMod = Mathf.Max(0.75f, p.yieldMod);   // offline loss is capped at 25%
                }
                p.waterings = Mathf.Max(p.waterings, 2);
            }
        }

        void ResolveEvent(LocationState l, GameEvent e)
        {
            e.phase = EventPhase.Resolved;
            l.lastNegativeEventEnd = e.endAt;
            if (catchingUp) awayEvents++;
            bool here = l.id == Save.currentLocation;
            switch (e.type)
            {
                case "rain":
                    if (e.plots.Count == 0) { Save.cp += 2; AddXp(10); e.summary = "Every plot was protected: no losses! +10 XP, +2 CP."; }
                    else e.summary = e.plots.Count + " unprotected plot(s) lost yield. Drainage trenches or Rain Covers would have helped.";
                    foreach (var p in l.plots) { p.trench = false; p.cover = false; }
                    break;
                case "pest":
                    bool treated = e.plots.All(i => !l.plots[i].pest);
                    if (treated) { AddXp(10); e.summary = "All infested plots were treated in time. +10 XP."; }
                    else e.summary = "Untreated plots grow slower and yield 25% less. Pest Spray, scarecrows and crop variety help.";
                    break;
                case "drought":
                    if (e.stalledMin < 30) { Save.cp += 3; AddXp(15); e.summary = "Water was managed well during the drought. +15 XP, +3 CP."; }
                    else e.summary = "Some crops stalled without water for " + Mathf.RoundToInt(e.stalledMin) + " min. Mulch and a full tank help.";
                    break;
            }
            Notify("result", EventName(e.type) + " is over", e.summary, e.type == "pest" ? "icon_bug" : e.type == "rain" ? "icon_rain" : "icon_sun", e.id);
            if (!here && !catchingUp) Notify("info", Defs.Loc(l.id).name, e.summary);
        }

        public static string EventName(string type) => type switch { "rain" => "Heavy rain", "pest" => "Pest outbreak", "drought" => "Drought", _ => type };

        /// <summary>Card text that updates in place: "Rain in 12 min", "Rain active, 8 min left".</summary>
        public string EventStatusLine(GameEvent e)
        {
            float toStart = (e.startAt - NowMs) / 60000f, toEnd = (e.endAt - NowMs) / 60000f;
            return e.phase switch
            {
                EventPhase.Warning => EventName(e.type) + " in " + FormatDuration(toStart),
                EventPhase.Active => EventName(e.type) + " active, " + FormatDuration(toEnd) + " left",
                _ => e.summary,
            };
        }

        public GameEvent FindEvent(string id) => Save?.locations.SelectMany(l => l.events).FirstOrDefault(e => e.id == id);

        // ------------------------------------------------------------------ developer tools (editor and development builds only)
        public void DevAdvance(float minutes)
        {
            Save.devClockOffsetMs += Min(minutes);
            Save.lastActivity = NowMs;
            Advance();
            Persist();
        }

        public void DevTrigger(string type)
        {
            var l = Here;
            foreach (var e in l.events.Where(e => e.phase != EventPhase.Resolved).ToList()) ResolveEvent(l, e);
            l.lastNegativeEventEnd = 0;
            if (type == "pest" && !l.plots.Any(p => p.state == PlotState.Growing)) { Notify("warn", "Dev", "Plant something first to test pests."); return; }
            if (type == "pest" && l.plots.Where(p => p.state == PlotState.Growing).GroupBy(p => p.crop).Max(g => g.Count()) < 1) return;
            StartEvent(l, type, NowMs);
            Persist();
        }

        public void DevGrant(int coins, int xp)
        {
            Save.coins += coins;
            AddXp(xp);
            Persist();
        }
    }
}
