using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace FieldsOfHope
{
    public struct Result
    {
        public bool ok;
        public string message;
        public static Result Ok(string msg = null) => new Result { ok = true, message = msg };
        public static Result Fail(string msg) => new Result { ok = false, message = msg };
    }

    public class ServerMsg
    {
        public string kind;      // info, warn, result, levelup, eligible
        public string title, body, icon, eventId, location;
        public int level;
    }

    /// <summary>
    /// Server-authoritative game logic. It runs in-process and persists JSON to disk, standing in for the
    /// REST backend described in section J; the client only reads <see cref="Save"/> and calls actions.
    /// Every coin, stock, XP and timer change happens here, against the server clock.
    /// </summary>
    public partial class GameServer
    {
        public PlayerSave Save { get; private set; }
        public AccountRecord Account { get; private set; }
        public readonly Queue<ServerMsg> Outbox = new Queue<ServerMsg>();
        public readonly List<string> AwaySummary = new List<string>();

        readonly string root;
        readonly System.Random rng = new System.Random();
        readonly Dictionary<string, Result> processedTx = new Dictionary<string, Result>();
        readonly Queue<string> processedOrder = new Queue<string>();
        bool suppressEvents;

        /// <param name="dataRoot">Folder for accounts and saves; tests pass a temporary folder.</param>
        public GameServer(string dataRoot = null)
        {
            root = dataRoot ?? Path.Combine(Application.persistentDataPath, "FieldsOfHope");
            Directory.CreateDirectory(Path.Combine(root, "saves"));
        }

        // ------------------------------------------------------------------ time
        public long NowMs => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() + (Save?.devClockOffsetMs ?? 0);
        public static long Min(float m) => (long)(m * 60000);
        int LocalDayOf(long ms) => (int)Math.Floor((ms + Save.tzOffsetMin * 60000.0) / 86400000.0);
        public int Today => LocalDayOf(NowMs);
        public int GameDay => Today - LocalDayOf(Save.createdAt) + 1;
        public DateTime LocalTime => DateTimeOffset.FromUnixTimeMilliseconds(NowMs).UtcDateTime.AddMinutes(Save.tzOffsetMin);
        public DayOfWeek LocalDayOfWeek => LocalTime.DayOfWeek;

        // ------------------------------------------------------------------ persistence
        string SavePath(string accountId) => Path.Combine(root, "saves", accountId + ".json");
        string AccountsPath => Path.Combine(root, "accounts.json");

        AccountsDb LoadAccounts()
        {
            try { return File.Exists(AccountsPath) ? JsonUtility.FromJson<AccountsDb>(File.ReadAllText(AccountsPath)) ?? new AccountsDb() : new AccountsDb(); }
            catch (Exception e) { Debug.LogError("accounts.json unreadable: " + e.Message); return new AccountsDb(); }
        }

        void WriteAtomic(string path, string json)
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            // browser builds persist to IndexedDB; flush it after every write
            File.WriteAllText(path, json);
            WebStorage.Flush();
#else
            string tmp = path + ".tmp";
            File.WriteAllText(tmp, json);
            if (File.Exists(path)) File.Replace(tmp, path, null); else File.Move(tmp, path);
#endif
        }

        void SaveAccounts(AccountsDb db) => WriteAtomic(AccountsPath, JsonUtility.ToJson(db, true));

        public Result Persist()
        {
            if (Save == null) return Result.Fail("No game loaded.");
            try
            {
                Save.lastSync = NowMs;
                string json = JsonUtility.ToJson(Save);
                WriteAtomic(SavePath(Save.accountId), json);
                return Result.Ok();
            }
            catch (Exception e)
            {
                Debug.LogError("Save failed: " + e.Message);
                return Result.Fail("Saving failed. Your progress will be retried.");
            }
        }

        /// <summary>Runs an economy action once per txId (SAVE-02) and autosaves it (SAVE-01).</summary>
        public Result Do(string txId, string type, Func<Result> action)
        {
            if (Save == null) return Result.Fail("Not logged in.");
            if (txId != null && processedTx.TryGetValue(txId, out var prior)) return prior;
            Advance();
            int c = Save.coins, p = Save.cp, x = Save.xp;
            var r = action();
            if (r.ok)
            {
                Save.lastActivity = NowMs;
                Save.ledger.Add(new LedgerEntry { txId = txId ?? Guid.NewGuid().ToString("N"), type = type, at = NowMs, dCoins = Save.coins - c, dCp = Save.cp - p, dXp = Save.xp - x, detail = r.message });
                if (Save.ledger.Count > 300) Save.ledger.RemoveRange(0, Save.ledger.Count - 300);
                Persist();
            }
            if (txId != null)
            {
                processedTx[txId] = r; processedOrder.Enqueue(txId);
                while (processedOrder.Count > 200) processedTx.Remove(processedOrder.Dequeue());
            }
            return r;
        }

        // ------------------------------------------------------------------ messages
        public void Notify(string kind, string title, string body, string icon = null, string eventId = null)
        {
            Outbox.Enqueue(new ServerMsg { kind = kind, title = title, body = body, icon = icon, eventId = eventId, location = Save?.currentLocation });
            if (Save != null && kind != "levelup")
            {
                Save.notifLog.Add(new NotifRecord { title = title, body = body, kind = kind, at = NowMs });
                long cutoff = NowMs - Min(24 * 60);
                Save.notifLog.RemoveAll(n => n.at < cutoff);
            }
        }

        // ------------------------------------------------------------------ state helpers
        public LocationState Loc(string id) => Save.locations.First(l => l.id == id);
        public LocationState Here => Loc(Save.currentLocation);
        public LocationDef HereDef => Defs.Loc(Save.currentLocation);
        public int OwnedPlots(LocationState l) => l.plots.Count(p => p.state >= PlotState.Empty);

        public int Count(string id) => Save.items.FirstOrDefault(i => i.id == id)?.qty ?? 0;
        public bool Has(string id) => Count(id) > 0;

        public int StorageCapacity => Defs.BaseStorage(Save.level) + Save.bonusSlots;
        public int UsedSlots => Save.items.Where(i => Defs.UsesSlot(i.id) && i.qty > 0).Sum(i => (i.qty + Defs.StackSize - 1) / Defs.StackSize);

        public int SlotsAfterAdding(string id, int qty)
        {
            if (!Defs.UsesSlot(id)) return UsedSlots;
            int cur = Count(id);
            return UsedSlots - (cur + Defs.StackSize - 1) / Defs.StackSize + (cur + qty + Defs.StackSize - 1) / Defs.StackSize;
        }

        public bool HasSpaceFor(string id, int qty) => SlotsAfterAdding(id, qty) <= StorageCapacity;

        void AddItem(string id, int qty)
        {
            var s = Save.items.FirstOrDefault(i => i.id == id);
            if (s == null) Save.items.Add(s = new ItemStack { id = id });
            s.qty += qty;
            if (s.qty < 0) throw new InvalidOperationException("Negative stock for " + id);   // SAVE-03 guard
        }

        bool TakeItem(string id, int qty)
        {
            var s = Save.items.FirstOrDefault(i => i.id == id);
            if (s == null || s.qty < qty) return false;
            s.qty -= qty;
            if (s.qty == 0) Save.items.Remove(s);
            return true;
        }

        bool Spend(int coins, int cp = 0)
        {
            if (coins < 0 || cp < 0 || Save.coins < coins || Save.cp < cp) return false;
            Save.coins -= coins; Save.cp -= cp;
            return true;
        }

        public bool LocationHasEvent(LocationState l, string type) =>
            l.events.Any(e => e.type == type && e.phase != EventPhase.Resolved);

        public GameEvent ActiveEvent(LocationState l, string type) =>
            l.events.FirstOrDefault(e => e.type == type && e.phase == EventPhase.Active);

        // ------------------------------------------------------------------ progression
        public static int XpToNext(int level) => level >= Defs.MaxLevel ? int.MaxValue : Defs.XpForLevel[level + 1];

        void AddXp(int amount)
        {
            if (amount <= 0) return;
            Save.xp += amount;
            while (Save.level < Defs.MaxLevel && Save.xp >= Defs.XpForLevel[Save.level + 1])
            {
                Save.level++;
                int lv = Save.level;
                Save.coins += Defs.LevelCoinReward(lv);
                if (lv == 4) AddItem("fertilizer", 2);
                var rewards = new List<string>();
                if (Defs.LevelCoinReward(lv) > 0) rewards.Add("+" + Defs.LevelCoinReward(lv) + " coins");
                if (lv == 4) rewards.Add("+2 Fertilizer Packs");
                if (Defs.BaseStorage(lv) > Defs.BaseStorage(lv - 1)) rewards.Add("Storage " + Defs.BaseStorage(lv) + " slots");
                if (lv == 15) rewards.Add("Title: Food Security Champion");
                Outbox.Enqueue(new ServerMsg { kind = "levelup", level = lv, title = "Level " + lv + "!", body = string.Join("\n", rewards) + "\n\nUnlocked: " + Defs.LevelUnlockText(lv) });
            }
        }

        public void TrackQuest(string kind, int amount = 1)
        {
            if (Save.questDay != Today) return;
            foreach (var q in Save.quests.Where(q => q.kind == kind && !q.claimed))
                q.progress = Math.Min(q.target, q.progress + amount);
        }

        public string FormatDuration(float minutes)
        {
            if (minutes < 1) return Mathf.CeilToInt(minutes * 60) + "s";
            if (minutes < 60) return Mathf.FloorToInt(minutes) + "m " + Mathf.FloorToInt(minutes * 60 % 60).ToString("00") + "s";
            if (minutes < 60 * 24) return Mathf.FloorToInt(minutes / 60) + "h " + Mathf.FloorToInt(minutes % 60).ToString("00") + "m";
            return Mathf.FloorToInt(minutes / 1440) + "d " + Mathf.FloorToInt(minutes / 60 % 24) + "h";
        }
    }
}
