using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace FieldsOfHope
{
    public enum Tool { None, Basket, Can, Axe, Shovel }

    /// <summary>Main farm screen: pannable farm, plots, HUD, hotbar and notification stack (screen F).</summary>
    public class FarmScreen
    {
        GameApp App => GameApp.I;
        GameServer S => GameApp.I.Server;

        public RectTransform Root, World;
        public NotificationStack Notifications;
        public Ambience Ambience;   // daylight, window glows, birds, butterflies, smoke, leaves, fireflies
        public MapView Map;         // buildings, trees, props, animals, villagers and walkers of the current location
        RectTransform plotsLayer;
        public Tool Tool { get; private set; }
        public readonly Dictionary<string, RectTransform> Targets = new Dictionary<string, RectTransform>();
        public readonly List<PlotView> Plots = new List<PlotView>();

        const float BgW = 1700, BgH = 950, Zoom = 1.3f;
        float scale;                 // canvas units per background pixel
        Vector2 pan, panVelocity;
        // zoom: the farm is drawn this many times its normal size (pinch, mouse wheel, the +/- buttons or the +/- keys)
        const float MaxZoom = 2.4f, ZoomStep = 1.25f;
        float zoom = 1f, zoomTarget = 1f;
        Vector2 zoomFocus;           // the point on screen (viewport units) that stays put while zooming
        bool pinching;
        float pinchDistance;
        Vector2 pinchMiddle;
        RectTransform viewport;
        RectTransform lowerHud;
        const float HudScale = 0.75f, HotbarScale = 0.85f;
        string builtFor;
        Image bg, weather;
        RectTransform worldMarkers, rainLayer;
        readonly List<(Image img, Tool tool)> toolSlots = new List<(Image, Tool)>();
        readonly List<(Image icon, Text count, Image frame)> produceSlots = new List<(Image, Text, Image)>();
        Text toolHint;

        public void Build(RectTransform layer)
        {
            Root = UI.New("Farm", layer).Fill();
            viewport = UI.New("Viewport", Root).Fill();
            viewport.gameObject.AddComponent<RectMask2D>();
            scale = 1080f * Zoom / BgH;
            World = UI.New("World", viewport).At(0.5f, 0.5f, 0, 0, BgW * scale, BgH * scale);
            // the location's ground (grass, paths, water, fields) is set in RebuildLocation; everything standing on it is MapView
            bg = UI.Img(World, null, null, false, "Ground");
            bg.rectTransform.Fill();
            bg.raycastTarget = true;   // so a swipe that starts on bare ground still pans
            var drag = World.gameObject.AddComponent<WorldDrag>();
            drag.onDrag = d =>
            {
                if (pinching) return;    // two fingers zoom (and pan) the farm themselves
                pan = ClampPan(pan + d); World.anchoredPosition = pan; panVelocity = d / Mathf.Max(Time.unscaledDeltaTime, 0.001f);
            };
            drag.onEnd = () => { if (panVelocity.magnitude < 200f) panVelocity = Vector2.zero; };
            plotsLayer = UI.New("Plots", World).Fill();
            var labelLayer = UI.New("PlotLabels", World).Fill();
            BuildPlots(plotsLayer, labelLayer);
            worldMarkers = UI.New("Markers", World).Fill();

            weather = UI.Rect(Root, new Color(0, 0, 0, 0), "Weather");
            weather.rectTransform.Fill();
            rainLayer = UI.New("Rain", Root).Fill();
            BuildRain();

            // the client found the buttons too big: the HUD is drawn smaller, the hotbar a little less so it stays easy to tap
            lowerHud = UI.Scaled(Root, HotbarScale, "Lower HUD");
            BuildHud();
            BuildHotbar();
            Notifications = new NotificationStack(Root);

            var driver = Root.gameObject.AddComponent<Driver>();
            driver.farm = this;
            Home(true);
            RebuildLocation();
        }

        public float Scale => scale;   // canvas units per painting px
        public Vector2 BgToWorld(float bx, float by) => new Vector2((bx - BgW / 2) * scale, (BgH / 2 - by) * scale);
        public Vector2 WorldToBg(Vector2 w) => new Vector2(w.x / scale + BgW / 2, BgH / 2 - w.y / scale);
        public const float PlotWidth = 176f;   // canvas units across a plot's diamond

        /// <summary>The village's time of day and weather, for everyone's routine.</summary>
        public VillageTime VillageClock
        {
            get
            {
                var now = S.LocalTime;
                var rain = S.ActiveEvent(S.Here, "rain");
                int day = S.Today;
                return new VillageTime
                {
                    hour = now.Hour + now.Minute / 60f + now.Second / 3600f,
                    night = Ambience?.Night ?? 0f,
                    rain = rain != null,
                    day = day,
                    campfireNight = Routine.CampfireNight(day),
                    rainKey = rain != null ? (int)(rain.startAt / 60000 % 1000003) : 0,
                };
            }
        }

        // ------------------------------------------------------------------ plots
        void BuildPlots(RectTransform layer, RectTransform labelLayer)
        {
            const float W = PlotWidth;
            float Hd = W * 128f / 256f, Ht = W * 152f / 256f;
            var origin = BgToWorld(300, 462);
            var order = Enumerable.Range(0, Defs.MaxPlots).OrderBy(i => i % 4 + i / 4).ToList();
            foreach (int i in order)
            {
                int c = i % 4, r = i / 4;
                var pos = origin + new Vector2((c - r - 0.5f) * W / 2f, -(c + r - 2.5f) * Hd / 2f);
                var pv = new PlotView(this, layer, labelLayer, i, pos, W, Ht, Hd);
                Plots.Add(pv);
            }
            Plots.Sort((a, b) => a.index.CompareTo(b.index));
        }

        public void ClickPlot(int index)
        {
            var p = S.PlotAt(index);
            switch (Tool)
            {
                case Tool.Basket:
                    if (p.state == PlotState.Ready) { Harvest(index); return; }
                    break;
                case Tool.Can:
                    if (p.state == PlotState.Growing) { Water(index); return; }
                    break;
                case Tool.Axe:
                    if (p.state == PlotState.Blocked) { ClearLand(index); return; }
                    break;
                case Tool.Shovel:
                    if (p.state >= PlotState.Empty) { App.Act(tx => S.DigTrench(tx, index)); return; }
                    break;
            }
            App.Open(new PlotPanel(index));
        }

        public void Harvest(int index)
        {
            var crop = S.PlotAt(index).crop != null ? Defs.Crop(S.PlotAt(index).crop) : null;
            var r = App.Act(tx => S.Harvest(tx, index), "harvest", false);
            if (r.ok)
                AfterWork(index, () =>
                {
                    Sfx.Coin();
                    Plots[index].Float(r.message, UI.Gold);
                    Plots[index].Burst(PlotView.LeafColors, 12);
                    if (crop != null) Plots[index].FlyToCrate(crop.icon, crop.tint, crop.yield);
                });
        }

        /// <summary>The action is done in the game; its effects play when the farmhand has done the work on the plot.</summary>
        void AfterWork(int index, Action effect)
        {
            if (Map != null) Map.Farmhand.Then(index, effect); else effect();
        }

        public void Water(int index)
        {
            if (App.Act(tx => S.Water(tx, index), "water", false).ok)
                AfterWork(index, () =>
                {
                    Plots[index].Splash("icon_drop");
                    Plots[index].Burst(PlotView.WaterColors, 10, 0.7f);
                });
        }

        public void ClearLand(int index)
        {
            if (S.PlotAt(index).state != PlotState.Blocked) return;
            var pv = Plots[index];
            if (App.Act(tx => S.ClearObstacle(tx, index)).ok)
                AfterWork(index, () => { pv.Float("Cleared!", UI.Cream); pv.Burst(PlotView.DebrisColors, 16, 1.1f); });   // the farmhand's axe does the rest
        }

        // ------------------------------------------------------------------ world markers per location
        public void RebuildLocation()
        {
            builtFor = S.Save.currentLocation;
            var def = S.HereDef;
            var map = MapLayout.Load(S.Save.currentLocation);
            bg.sprite = UI.S(map.ground);
            bg.color = Color.white;
            LivingPainting.Apply(bg, map.mask);    // rivers, ponds, sea and paddies ripple and glint
            Map?.Destroy(); Ambience?.Destroy();
            Map = new MapView(this, map, plotsLayer.GetSiblingIndex() + 1);
            Ambience = new Ambience(this, map);
            UI.Clear(worldMarkers);

            Vector2 At(string name, float x, float y) { var p = map.Marker(name) ?? new Vector2(x, y); return BgToWorld(p.x, p.y); }
            // the store and houses on the map can be tapped to talk to the community (so can the villagers)
            foreach (var place in Map.Talkable)
            {
                var bubble = UI.Img(place, "bubble_ready", null, false, "Alert");
                bubble.rectTransform.At(0.5f, 1f, 0, 10, 54, 54, 0.5f, 0f);
                bubble.Live(() =>
                {
                    bubble.enabled = CanDeliver;
                    bubble.rectTransform.anchoredPosition = new Vector2(0, 10 + Mathf.Sin(Time.unscaledTime * 4) * 6);
                }, 0.03f);
            }

            var gathering = Marker(At("gathering", 935, 190), "icon_people", "Community Gathering", OpenGathering);
            gathering.Live(() => gathering.gameObject.SetActive(S.GatheringOpen && S.Here.gatheringDay != S.GameDay), 1f);

            if (def.waterings >= 2)
            {
                var well = Marker(At("well", 540, 600), "item_tank", "Well", () => App.Act(tx => S.RefillTank(tx)));
                Targets["well"] = well;
                var wt = UI.Label(well, "", 22, UI.Cream, TextAnchor.UpperCenter, true).Outlined();
                wt.rectTransform.At(0.5f, 0f, 0, -64, 260, 30, 0.5f, 1f);
                wt.Live(() =>
                {
                    long wait = S.Here.wellReadyAt - S.NowMs;
                    wt.text = "Tank " + S.Here.tank + "/" + S.TankCapacity + (wait > 0 ? " · refill in " + S.FormatDuration(wait / 60000f) : "");
                });
            }
        }

        bool CanDeliver => S.Here.requests.Any(r => r.status == RequestStatus.Open && S.Count("crop_" + r.crop) >= r.Remaining);

        /// <summary>Opens the conversation with a community member (sell and deliver harvests).</summary>
        public void Talk() => App.Open(new DialoguePanel());

        RectTransform Marker(Vector2 pos, string icon, string label, Action onClick)
        {
            var frame = UI.Img(worldMarkers, "slot_empty", null, true, "Marker " + label);
            frame.rectTransform.At(0.5f, 0.5f, pos.x, pos.y, 96, 96);
            frame.Shadowed(4);
            var i = UI.Img(frame.transform, icon);
            i.rectTransform.Fill(14, 14, 14, 14);
            var t = UI.Label(frame.transform, label, 22, UI.Cream, TextAnchor.UpperCenter, true).Outlined();
            t.rectTransform.At(0.5f, 0f, 0, -4, 300, 30, 0.5f, 1f);
            frame.Clickable(onClick);
            return frame.rectTransform;
        }

        void OpenGathering()
        {
            var crop = S.Save.items.Where(i => i.id.StartsWith("crop_") && i.qty > 0).OrderByDescending(i => i.qty).FirstOrDefault();
            if (crop == null) { App.Message("Community Gathering", "Everyone shares one harvested crop at the shared table. Harvest something first, then come back!"); return; }
            App.Confirm("Community Gathering", "Neighbours are sharing food at the long table.\n\nContribute 1 " + Defs.ItemName(crop.id) + " to join in?\n(+30 XP, +10 CP, +5 food security)",
                "Join", () => App.Act(tx => S.AttendGathering(tx, crop.id)));
        }

        // ------------------------------------------------------------------ HUD (UI-01)
        void BuildHud()
        {
            var hud = UI.Scaled(Root, HudScale, "HUD");

            var map = UI.Img(hud, "hud_map"); map.rectTransform.TL(14, 6, 150, 139);
            map.Clickable(() => App.Open(new MapPanel())); Targets["map"] = map.rectTransform;

            var shop = UI.Img(hud, "hud_shop"); shop.rectTransform.TL(150, 0, 320, 150);
            shop.Clickable(() => App.Open(new ShopPanel())); Targets["shop"] = shop.rectTransform;

            var quests = UI.Img(hud, "hud_quests"); quests.rectTransform.TL(24, 146, 130, 114);
            quests.Clickable(() => App.Open(new QuestsPanel())); Targets["quests"] = quests.rectTransform;
            var qdot = UI.Img(quests.transform, "icon_check", null, true, "Claimable");
            qdot.rectTransform.At(1f, 1f, 6, 6, 40, 40, 1f, 1f);
            qdot.Live(() => qdot.enabled = S.Save.quests.Any(q => q.Done && !q.claimed), 0.5f);

            // level badge -> profile
            var badge = UI.Sliced(hud, "btn", null, 1f, "Level");
            badge.rectTransform.TL(24, 268, 130, 64);
            var lv = UI.Label(badge.transform, "", 24, UI.Cream, TextAnchor.UpperCenter, true).Outlined();
            lv.rectTransform.Fill(4, 4, 4, 22);
            var (xpBg, xpFill) = UI.Bar(badge.transform, new Color(0.55f, 0.85f, 0.35f));
            xpBg.rectTransform.At(0.5f, 0f, 0, 10, 104, 16, 0.5f, 0f);
            badge.Live(() =>
            {
                int l = S.Save.level;
                lv.text = "Lv " + l;
                float from = Defs.XpForLevel[l], to = l >= Defs.MaxLevel ? from + 1 : Defs.XpForLevel[l + 1];
                UI.SetBar(xpFill, l >= Defs.MaxLevel ? 1 : (S.Save.xp - from) / (to - from));
            });
            badge.Clickable(() => App.Open(new ProfilePanel())); Targets["level"] = badge.rectTransform;

            // Community: talk to the villagers to sell and deliver (also by tapping the store, houses or people)
            var community = UI.Sliced(hud, "tab", null, 2f, "Community");
            community.rectTransform.TL(24, 344, 130, 118);
            var ci = UI.Img(community.transform, "icon_people");
            ci.rectTransform.At(0.5f, 1f, 0, -8, 72, 72, 0.5f, 1f);
            var cl = UI.Label(community.transform, "Community", 21, UI.Cream, TextAnchor.LowerCenter, true).Outlined();
            cl.rectTransform.Fill(2, 0, 2, 8);
            community.Clickable(Talk); Targets["npc"] = community.rectTransform;
            var alert = UI.Img(community.transform, "bubble_ready", null, false, "Alert");
            alert.rectTransform.At(1f, 1f, 18, 18, 52, 52, 1f, 1f);
            alert.Live(() =>
            {
                alert.enabled = CanDeliver;
                alert.rectTransform.anchoredPosition = new Vector2(18, 18 + Mathf.Sin(Time.unscaledTime * 4) * 5);
            }, 0.03f);

            var clock = UI.Img(hud, "clock_bar"); clock.rectTransform.At(0.5f, 1f, 0, -20, 440, 112, 0.5f, 1f);
            var ct = UI.Label(clock.transform, "", 34, UI.Cream, TextAnchor.MiddleCenter, true).Outlined(null, 1.5f);
            ct.rectTransform.Fill(130, 18, 70, 22);
            ct.Live(() => ct.text = "Day " + S.GameDay + " · " + S.LocalTime.ToString("h:mm tt", System.Globalization.CultureInfo.InvariantCulture), 0.5f);
            Targets["clock"] = clock.rectTransform;
            // after dark a moon covers the sun painted on the clock bar
            var moon = UI.Img(clock.transform, "icon_moon", null, true, "Moon");
            moon.rectTransform.At(0.5f, 0.5f, -147, 1, 76, 76);
            moon.raycastTarget = false;
            moon.Live(() => moon.enabled = (Ambience?.Night ?? 0f) > 0.5f, 0.5f);

            var coin = UI.Img(hud, "coin_bar"); coin.rectTransform.TR(340, 24, 300, 104);
            var cv = UI.Label(coin.transform, "", 38, UI.Cream, TextAnchor.MiddleRight, true).Outlined(null, 1.5f);
            cv.rectTransform.Fill(96, 16, 92, 20);
            int shown = -1;
            cv.Live(() =>
            {
                if (shown < 0) shown = S.Save.coins;
                bool counting = shown != S.Save.coins;
                shown = (int)Mathf.MoveTowards(shown, S.Save.coins, Mathf.Max(1, Mathf.Abs(S.Save.coins - shown) * 0.25f));
                cv.text = shown.ToString("N0");
                // the coin pill swells while the number rolls
                coin.rectTransform.localScale = Vector3.one * (counting ? 1.07f : Mathf.MoveTowards(coin.rectTransform.localScale.x, 1f, 0.02f));
            }, 0.04f);
            var plus = UI.Rect(coin.transform, new Color(0, 0, 0, 0), "Plus");
            plus.rectTransform.At(1f, 0.5f, -10, 0, 70, 80, 1f, 0.5f);
            plus.Clickable(() => App.Open(new ShopPanel("Supplies")));
            Targets["coins"] = coin.rectTransform;

            var cp = UI.Sliced(hud, "tag_cp", null, 1f, "CP");
            cp.rectTransform.TR(408, 128, 170, 44);
            var cpi = UI.Img(cp.transform, "icon_cp"); cpi.rectTransform.At(0f, 0.5f, 6, 0, 36, 36, 0f, 0.5f);
            var cpt = UI.Label(cp.transform, "", 24, Color.white, TextAnchor.MiddleLeft, true).Outlined(new Color(0.2f, 0.1f, 0.35f), 1.5f);
            cpt.rectTransform.Fill(48, 2, 8, 2);
            cpt.Live(() => cpt.text = S.Save.cp + " CP", 0.3f);

            // a clear gap between Home and Settings so a thumb doesn't hit the wrong one
            var home = UI.Img(hud, "hud_home"); home.rectTransform.TR(184, 22, 138, 142);
            home.Clickable(() => Home(false)); Targets["home"] = home.rectTransform;

            var settings = UI.Img(hud, "hud_settings"); settings.rectTransform.TR(16, 22, 140, 142);
            settings.Clickable(() => App.Open(new SettingsPanel())); Targets["settings"] = settings.rectTransform;

            // zoom in and out (also: pinch, the mouse wheel, the + and - keys)
            foreach (var (sign, step, y) in new[] { ("+", ZoomStep, 176f), ("-", 1f / ZoomStep, 268f) })
            {
                var b = UI.Sliced(hud, "btn", null, 1f, "Zoom " + sign);
                b.rectTransform.TR(44, y, 84, 84);
                var t = UI.Label(b.transform, sign, 52, UI.Cream, TextAnchor.MiddleCenter, true).Outlined(null, 2f);
                t.rectTransform.Fill(0, 0, 0, 6);
                float k = step;
                b.Clickable(() => ZoomBy(k, Vector2.zero));
            }

            // location label and food security line (bottom centre)
            var label = UI.Label(lowerHud, "", 70, Color.white, TextAnchor.MiddleCenter, true).Outlined(new Color(0.15f, 0.12f, 0.1f), 4f);
            label.rectTransform.At(0.5f, 0f, 30, 190, 900, 84, 0.5f, 0f);
            var sub = UI.Label(lowerHud, "", 24, UI.Cream, TextAnchor.MiddleCenter, true).Outlined(new Color(0.15f, 0.1f, 0.05f), 2f);
            sub.rectTransform.At(0.5f, 0f, 30, 152, 1100, 40, 0.5f, 0f);
            label.Live(() =>
            {
                var l = S.Here;
                label.text = S.HereDef.label;
                string s = "Food security: <color=#" + ColorUtility.ToHtmlStringRGB(GameServer.BandColor(l.meter)) + ">" + GameServer.Band(l.meter) + " " + l.meter + "</color> · Pantry " + S.PantryDays(l).ToString("0.0") + " days";
                if (S.HereDef.waterings >= 2) s += " · Water tank " + l.tank + "/" + S.TankCapacity;
                if (S.GatheringOpen && l.gatheringDay != S.GameDay) s += " · Community Gathering today!";
                sub.text = s;
                if (builtFor != S.Save.currentLocation) RebuildLocation();
                UpdateWeather();
            }, 0.5f);
            sub.Clickable(() => App.Open(new CommunityPanel()), false);
        }

        // ------------------------------------------------------------------ hotbar
        void BuildHotbar()
        {
            var bar = UI.New("Hotbar", lowerHud).At(0.5f, 0f, 30, 16, 970, 100, 0.5f, 0f);
            Targets["hotbar"] = bar;
            var h = bar.gameObject.AddComponent<HorizontalLayoutGroup>();
            h.spacing = 7; h.childControlWidth = h.childControlHeight = false; h.childAlignment = TextAnchor.MiddleCenter;
            (string sprite, Tool tool, Action click, string key)[] slots =
            {
                ("slot_basket", Tool.Basket, null, "basket"), ("slot_can", Tool.Can, null, "can"),
                ("slot_seedbag", Tool.None, () => App.Open(new InventoryPanel("Seeds")), "seedbag"),
                ("slot_axe", Tool.Axe, null, "axe"), ("slot_shovel", Tool.Shovel, null, "shovel"),
                ("slot_crate", Tool.None, () => App.Open(new InventoryPanel("Harvested Crops")), "crate"),
            };
            foreach (var s in slots)
            {
                var img = UI.Img(bar, s.sprite, null, true, "Slot " + s.key);
                img.rectTransform.Size(90, 90);
                var tool = s.tool; var click = s.click;
                img.Clickable(() => { if (click != null) click(); else SelectTool(Tool == tool ? Tool.None : tool); });
                Targets[s.key] = img.rectTransform;
                if (tool != Tool.None) toolSlots.Add((img, tool));
            }
            for (int i = 0; i < 4; i++)
            {
                var frame = UI.Img(bar, "slot_empty", null, true, "Produce " + i);
                frame.rectTransform.Size(90, 90);
                var icon = UI.Img(frame.transform, null); icon.rectTransform.Fill(18, 14, 18, 22);
                var count = UI.Label(frame.transform, "", 22, Color.white, TextAnchor.LowerRight, true).Outlined(Color.black, 1.5f);
                count.rectTransform.Fill(4, 4, 12, 8);
                frame.Clickable(() => App.Open(new InventoryPanel("Harvested Crops")));
                produceSlots.Add((icon, count, frame));
            }
            toolHint = UI.Label(lowerHud, "", 24, UI.Cream, TextAnchor.MiddleCenter, true).Outlined(new Color(0.1f, 0.06f, 0.02f), 2f);
            toolHint.rectTransform.At(0.5f, 0f, 30, 118, 900, 34, 0.5f, 0f);
            bar.Live(UpdateHotbar, 0.2f);
        }

        void UpdateHotbar()
        {
            var crops = S.Save.items.Where(i => i.id.StartsWith("crop_") && i.qty > 0).OrderByDescending(i => i.qty).Take(4).ToList();
            for (int i = 0; i < produceSlots.Count; i++)
            {
                var (icon, count, _) = produceSlots[i];
                if (i < crops.Count)
                {
                    var c = Defs.Crop(crops[i].id.Substring(5));
                    icon.sprite = UI.S(c.icon); icon.color = c.tint; icon.enabled = true;
                    count.text = "x" + crops[i].qty;
                }
                else { icon.enabled = false; count.text = ""; }
            }
            foreach (var (img, tool) in toolSlots)
            {
                bool on = tool == Tool;
                img.rectTransform.localScale = Vector3.one * (on ? 1.12f : 1f);
                img.color = on ? new Color(1f, 0.95f, 0.7f) : Color.white;
            }
        }

        public void SelectTool(Tool t)
        {
            Tool = t;
            toolHint.text = t switch
            {
                Tool.Basket => "Harvest Basket: tap a ready plot",
                Tool.Can => "Watering Can: tap a growing plot",
                Tool.Axe => "Axe: tap rocks or stumps to clear land",
                Tool.Shovel => "Shovel: dig drainage trenches before heavy rain",
                _ => "",
            };
            UpdateHotbar();
        }

        // ------------------------------------------------------------------ keyboard pan, Home (flow notes 7 and 8)
        public void Home(bool instant)
        {
            // back to the farm at its normal size
            zoom = zoomTarget = 1f;
            World.localScale = Vector3.one;
            var field = BgToWorld(300, 470);
            pan = ClampPan(-field);
            if (instant) World.anchoredPosition = pan;
        }

        Vector2 ClampPan(Vector2 p)
        {
            var view = App.CanvasRect.rect.size;
            float mx = Mathf.Max(0, (World.rect.width * zoom - view.x) / 2f), my = Mathf.Max(0, (World.rect.height * zoom - view.y) / 2f);
            return new Vector2(Mathf.Clamp(p.x, -mx, mx), Mathf.Clamp(p.y, -my, my));
        }

        /// <summary>Zoomed all the way out the farm still fills the screen.</summary>
        float MinZoom
        {
            get
            {
                var view = App.CanvasRect.rect.size;
                return Mathf.Min(1f, Mathf.Max(view.x / World.rect.width, view.y / World.rect.height));
            }
        }

        public float ZoomLevel => zoom;

        /// <summary>Zooms by <paramref name="factor"/>, keeping the point at <paramref name="focus"/> (viewport units from its centre) in place.</summary>
        public void ZoomBy(float factor, Vector2 focus)
        {
            zoomTarget = Mathf.Clamp(zoomTarget * factor, MinZoom, MaxZoom);
            zoomFocus = focus;
        }

        void SetZoom(float z, Vector2 focus)
        {
            z = Mathf.Clamp(z, MinZoom, MaxZoom);
            if (Mathf.Abs(z - zoom) < 0.0001f) return;
            // the farm point under the focus stays under it: p = pan + w * zoom for every world point w
            var shown = World.anchoredPosition;
            pan = focus - (focus - pan) * (z / zoom);
            shown = focus - (focus - shown) * (z / zoom);
            zoom = z;
            World.localScale = new Vector3(z, z, 1f);
            pan = ClampPan(pan);
            World.anchoredPosition = ClampPan(shown);
        }

        Vector2 ToViewport(Vector2 screen)
        {
            RectTransformUtility.ScreenPointToLocalPointInRectangle(viewport, screen, null, out var p);
            return p;
        }

        /// <summary>Two fingers: pinch to zoom, move them together to pan. The mouse wheel zooms on the pointer.</summary>
        void ZoomInput(bool free)
        {
            var ts = Touchscreen.current;
            int n = 0; Vector2 a = default, b = default;
            if (ts != null)
                foreach (var touch in ts.touches)
                {
                    if (!touch.press.isPressed) continue;
                    if (n == 0) a = touch.position.ReadValue(); else if (n == 1) b = touch.position.ReadValue();
                    n++;
                }
            if (n >= 2 && free)
            {
                float d = Vector2.Distance(a, b);
                var mid = ToViewport((a + b) / 2f);
                if (pinching && pinchDistance > 1f)
                {
                    SetZoom(zoom * d / pinchDistance, mid);
                    zoomTarget = zoom;
                    pan = ClampPan(pan + (mid - pinchMiddle)); World.anchoredPosition = pan;
                }
                pinching = true; pinchDistance = d; pinchMiddle = mid; panVelocity = Vector2.zero;
            }
            else pinching = false;

            var mouse = Mouse.current;
            if (mouse != null && free)
            {
                float scroll = mouse.scroll.ReadValue().y;
                // a wheel notch is 120 on some platforms and about 1 on others; trackpads send many small steps
                float notches = Mathf.Abs(scroll) >= 20f ? scroll / 120f : scroll;
                if (Mathf.Abs(notches) > 0.01f) ZoomBy(Mathf.Pow(ZoomStep, Mathf.Clamp(notches, -2f, 2f)), ToViewport(mouse.position.ReadValue()));
            }
            if (Mathf.Abs(zoomTarget - zoom) > 0.0005f)
                SetZoom(Mathf.Abs(zoomTarget - zoom) < 0.002f ? zoomTarget : Mathf.Lerp(zoom, zoomTarget, 1f - Mathf.Exp(-14f * Time.unscaledDeltaTime)), zoomFocus);
        }

        public void Tick()
        {
            Vector2 dir = Vector2.zero;
            var kb = Keyboard.current;
            bool typing = EventSystem.current != null && EventSystem.current.currentSelectedGameObject != null &&
                          EventSystem.current.currentSelectedGameObject.GetComponent<InputField>() != null;
            if (kb != null && !typing && App.OpenPanel == null && !App.ModalOpen)
            {
                if (kb.wKey.isPressed || kb.upArrowKey.isPressed) dir += Vector2.up;
                if (kb.sKey.isPressed || kb.downArrowKey.isPressed) dir += Vector2.down;
                if (kb.aKey.isPressed || kb.leftArrowKey.isPressed) dir += Vector2.left;
                if (kb.dKey.isPressed || kb.rightArrowKey.isPressed) dir += Vector2.right;
                if (kb.hKey.wasPressedThisFrame) Home(false);
                if (kb.equalsKey.wasPressedThisFrame || kb.numpadPlusKey.wasPressedThisFrame) ZoomBy(ZoomStep, Vector2.zero);
                if (kb.minusKey.wasPressedThisFrame || kb.numpadMinusKey.wasPressedThisFrame) ZoomBy(1f / ZoomStep, Vector2.zero);
                if (kb.digit1Key.wasPressedThisFrame) SelectTool(Tool == Tool.Basket ? Tool.None : Tool.Basket);
                if (kb.digit2Key.wasPressedThisFrame) SelectTool(Tool == Tool.Can ? Tool.None : Tool.Can);
                if (kb.digit4Key.wasPressedThisFrame) SelectTool(Tool == Tool.Axe ? Tool.None : Tool.Axe);
                if (kb.digit5Key.wasPressedThisFrame) SelectTool(Tool == Tool.Shovel ? Tool.None : Tool.Shovel);
            }
            if (kb != null && kb.escapeKey.wasPressedThisFrame)
            {
                if (App.OpenPanel != null) App.OpenPanel.Close();
                else if (Tool != Tool.None) SelectTool(Tool.None);
            }
            ZoomInput(App.OpenPanel == null && !App.ModalOpen);
            // world moves opposite to the camera direction
            if (dir != Vector2.zero) { pan -= dir.normalized * 900f * Time.unscaledDeltaTime; panVelocity = Vector2.zero; }
            else if (!World.GetComponent<WorldDrag>().dragging && panVelocity != Vector2.zero)
            {
                // a released swipe glides to a stop
                pan += panVelocity * Time.unscaledDeltaTime;
                panVelocity = Vector2.MoveTowards(panVelocity * Mathf.Exp(-5f * Time.unscaledDeltaTime), Vector2.zero, 20f);
            }
            pan = ClampPan(pan);   // also keeps the view valid when the window is resized
            World.anchoredPosition = Vector2.Lerp(World.anchoredPosition, pan, Time.unscaledDeltaTime * 10f);
            Map?.Farmhand.Observe();          // before the plots draw: what the player just did becomes the farmhand's job
            foreach (var p in Plots) p.Update();
            Ambience?.Tick();
            Map?.Tick(VillageClock);
            AnimateRain();
        }

        // ------------------------------------------------------------------ weather overlay
        readonly List<RectTransform> drops = new List<RectTransform>();

        void BuildRain()
        {
            var rnd = new System.Random(7);
            for (int i = 0; i < 70; i++)
            {
                var d = UI.Rect(rainLayer, new Color(0.75f, 0.85f, 1f, 0.55f), "Drop");
                d.rectTransform.At(0, 0, rnd.Next(0, 1920), rnd.Next(0, 1080), 3, 34 + rnd.Next(0, 20));
                d.rectTransform.localRotation = Quaternion.Euler(0, 0, -12);
                drops.Add(d.rectTransform);
            }
            rainLayer.gameObject.SetActive(false);
        }

        void UpdateWeather()
        {
            var l = S.Here;
            bool rain = S.ActiveEvent(l, "rain") != null, drought = S.ActiveEvent(l, "drought") != null;
            weather.color = rain ? new Color(0.15f, 0.2f, 0.35f, 0.28f) : drought ? new Color(1f, 0.75f, 0.3f, 0.18f) : new Color(0, 0, 0, 0);
            rainLayer.gameObject.SetActive(rain);
        }

        void AnimateRain()
        {
            if (!rainLayer.gameObject.activeSelf) return;
            float w = App.CanvasRect.rect.width, h = App.CanvasRect.rect.height;
            foreach (var d in drops)
            {
                var p = d.anchoredPosition + new Vector2(260, -1300) * Time.unscaledDeltaTime;
                if (p.y < -40) p = new Vector2(UnityEngine.Random.Range(-200, w), h + 40);
                d.anchoredPosition = p;
            }
        }

        class Driver : MonoBehaviour
        {
            public FarmScreen farm;
            void Update() => farm?.Tick();
        }
    }

    /// <summary>Touch/mouse swipe on the farm pans the camera; a drag that starts on a plot cancels that plot's tap.</summary>
    public class WorldDrag : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        public Action<Vector2> onDrag;
        public Action onEnd;
        public bool dragging;
        public void OnBeginDrag(PointerEventData e) => dragging = true;
        public void OnDrag(PointerEventData e)
        {
            float k = GameApp.I.CanvasRect.GetComponent<Canvas>().scaleFactor;
            onDrag?.Invoke(e.delta / k);
        }
        public void OnEndDrag(PointerEventData e) { dragging = false; onEnd?.Invoke(); }
    }

    /// <summary>One isometric plot tile and everything drawn on it.</summary>
    public class PlotView
    {
        readonly FarmScreen farm;
        public readonly int index;
        public readonly RectTransform root;
        readonly Image tile, cover, statusIcon, bubble;
        public readonly Image content;
        readonly Image barBg, barFill;
        readonly Text label;
        readonly float hd, ht;
        GameServer S => GameApp.I.Server;

        public static readonly Color[] SoilColors = { new Color(0.45f, 0.29f, 0.16f), new Color(0.58f, 0.39f, 0.22f), new Color(0.36f, 0.23f, 0.12f), new Color(0.5f, 0.75f, 0.3f) };
        public static readonly Color[] WaterColors = { new Color(0.55f, 0.8f, 1f), new Color(0.75f, 0.9f, 1f), new Color(0.4f, 0.65f, 0.95f) };
        public static readonly Color[] LeafColors = { new Color(0.45f, 0.75f, 0.3f), new Color(0.6f, 0.85f, 0.35f), new Color(1f, 0.85f, 0.35f) };
        public static readonly Color[] DebrisColors = { new Color(0.6f, 0.58f, 0.55f), new Color(0.45f, 0.32f, 0.2f), new Color(0.75f, 0.72f, 0.68f) };

        // growth "pop" and breeze sway
        Sprite shownSprite;
        bool seen;
        float popAt = -10f, popFrom = 1f, joltAt = -10f;
        readonly float swayPhase;

        public PlotView(FarmScreen farm, RectTransform layer, RectTransform labelLayer, int index, Vector2 pos, float w, float h, float hd)
        {
            this.farm = farm; this.index = index; this.hd = hd; ht = h;
            swayPhase = index * 1.37f;
            root = UI.New("Plot " + (index + 1), layer);
            root.At(0.5f, 0.5f, pos.x, pos.y, w, h, 0.5f, 1f - hd / 2f / h);
            tile = UI.Img(root, "tile_soil", null, false, "Tile");
            tile.rectTransform.Fill();
            tile.raycastTarget = true;
            tile.gameObject.AddComponent<DiamondHit>().diamondHeightFraction = hd / h;
            tile.Clickable(() => farm.ClickPlot(index));

            var center = new Vector2(0, h / 2f - hd / 2f);
            content = UI.Img(root, null, null, true, "Content");
            content.rectTransform.At(0.5f, 0.5f, center.x, center.y - hd * 0.18f, 96, 96, 0.5f, 0f);
            cover = UI.Img(root, "item_rain_cover", new Color(1, 1, 1, 0.9f), true, "Cover");
            cover.rectTransform.At(0.5f, 0.5f, center.x - w * 0.26f, center.y + 4, 44, 44);
            statusIcon = UI.Img(root, "icon_drop", null, true, "Status");
            statusIcon.rectTransform.At(0.5f, 0.5f, center.x + w * 0.26f, center.y + 10, 40, 40);
            bubble = UI.Img(root, "bubble_ready", null, true, "Ready");
            bubble.rectTransform.At(0.5f, 0.5f, center.x, center.y + 110, 64, 64, 0.5f, 0f);
            (barBg, barFill) = UI.Bar(root, new Color(0.55f, 0.85f, 0.35f));
            barBg.rectTransform.At(0.5f, 0.5f, center.x, center.y - hd * 0.42f, 96, 14);
            // labels sit in a layer above every tile so neighbouring plots never cover them
            label = UI.Label(labelLayer, "", 22, UI.Cream, TextAnchor.MiddleCenter, true).Outlined(new Color(0.12f, 0.08f, 0.04f), 2f);
            label.rectTransform.At(0.5f, 0.5f, pos.x, pos.y + 92, 200, 40);
        }

        public void Update()
        {
            var p = farm.Map != null ? farm.Map.Farmhand.Shown(index) : S.PlotAt(index);
            bool watered = p.state == PlotState.Growing && S.IsWatered(p);
            tile.sprite = FieldTile(S.Save.currentLocation, p.state <= PlotState.Cleared ? "tile_grass" : watered ? "tile_soil_wet" : "tile_soil");
            tile.color = p.state == PlotState.Blocked ? new Color(0.8f, 0.85f, 0.75f) : Color.white;
            cover.enabled = p.cover || p.trench;
            cover.sprite = UI.S(p.cover ? "item_rain_cover" : "slot_shovel");
            bubble.enabled = false; statusIcon.enabled = false; barBg.gameObject.SetActive(false); label.text = "";
            var crop = p.crop != null ? Defs.Crop(p.crop) : null;
            content.color = Color.white;
            float size = 96;

            switch (p.state)
            {
                case PlotState.Blocked:
                    content.sprite = ObstacleSprite(p.obstacle);
                    break;
                case PlotState.Cleared:
                    content.sprite = UI.S("sign_sale");
                    int n = S.NextPlotNumber(S.Here);
                    label.text = n <= Defs.MaxPlots ? Defs.PlotPrice(S.Save.currentLocation, n) + "c · Lv " + Defs.PlotLevels[n] : "";
                    size = 80;
                    break;
                case PlotState.Empty:
                    content.sprite = null;
                    break;
                case PlotState.Growing:
                    float t = p.total > 0 ? p.progress / p.total : 0;
                    if (crop.orchard) { content.sprite = UI.S(p.established ? "tree_grown" : "tree_young"); size = 90 + 50 * (p.established ? 1 : t); }
                    else { content.sprite = UI.S(t < 0.34f ? "stage_0" : t < 0.67f ? "stage_1" : "stage_2"); size = 70 + 40 * t; }
                    barBg.gameObject.SetActive(true);
                    UI.SetBar(barFill, t);
                    if (p.pest) { statusIcon.enabled = true; statusIcon.sprite = UI.S("icon_bug"); }
                    else if (!watered && S.HereDef.waterings > 0) { statusIcon.enabled = true; statusIcon.sprite = UI.S("icon_drop"); }
                    statusIcon.rectTransform.localScale = Vector3.one * (1f + Mathf.Sin(Time.unscaledTime * 5) * 0.08f);
                    break;
                case PlotState.Ready:
                    content.sprite = UI.S(crop.orchard ? "tree_fruit" : crop.icon);
                    content.color = crop.orchard ? Color.white : crop.tint;
                    size = crop.orchard ? 140 : 84;
                    bubble.enabled = true;
                    bubble.rectTransform.anchoredPosition = new Vector2(bubble.rectTransform.anchoredPosition.x, ht / 2f - hd / 2f + (crop.orchard ? 150 : 100) + Mathf.Sin(Time.unscaledTime * 4 + index) * 6);
                    if (p.pest) { statusIcon.enabled = true; statusIcon.sprite = UI.S("icon_bug"); }
                    break;
            }
            content.enabled = content.sprite != null;
            content.rectTransform.sizeDelta = new Vector2(size, size);
            Animate(p);
        }

        /// <summary>Each location's field has its own tiles (Tools/make_field_art.py): Baguio's stone terraces, Ilocos's sand, Davao's orchard grass.</summary>
        public static Sprite FieldTile(string loc, string kind) => UI.S(kind + "_" + loc) ?? UI.S(kind);

        public static Sprite ObstacleSprite(string obstacle) => UI.S("obstacle_" + obstacle) ?? UI.S("obstacle_rock");

        void Animate(Plot p)
        {
            float now = Time.unscaledTime;
            if (content.sprite != shownSprite)
            {
                // a new sprite (planted, next growth stage, ready, cleared) springs in; the first frame after building does not
                if (seen && content.sprite != null) { popAt = now; popFrom = shownSprite == null ? 0.2f : 0.8f; }
                shownSprite = content.sprite;
            }
            seen = true;
            float a = (now - popAt) / 0.45f, scale = 1f;
            if (a < 1f)
            {
                // ease-out-back: overshoots a little, then settles
                float x = a - 1f, s = 1.9f;
                scale = Mathf.LerpUnclamped(popFrom, 1f, 1f + (s + 1f) * x * x * x + s * x * x);
            }
            bool alive = p.state == PlotState.Growing || p.state == PlotState.Ready;
            float sway = alive ? Mathf.Sin(now * 1.7f + swayPhase) * (p.state == PlotState.Ready ? 2.5f : 4f) : 0f;
            if (p.state != PlotState.Blocked) content.rectTransform.localRotation = Quaternion.Euler(0, 0, sway);
            else content.rectTransform.localRotation = Quaternion.Euler(0, 0, now - joltAt < 0.3f ? Mathf.Sin((now - joltAt) * 50f) * 8f : 0f);
            float breathe = p.state == PlotState.Ready ? 1f + Mathf.Sin(now * 3f + swayPhase) * 0.03f : 1f;
            content.rectTransform.localScale = new Vector3(scale * breathe, scale * breathe, 1f);
        }

        Vector2 Centre => root.anchoredPosition + new Vector2(0, 14);

        /// <summary>A rock or stump shudders as the axe strikes it.</summary>
        public void Jolt() => joltAt = Time.unscaledTime;

        /// <summary>Little squares that fly out of the plot and fall back down (soil, water, leaves, debris).</summary>
        public void Burst(Color[] colors, int count, float power = 1f)
        {
            var rnd = new System.Random(Environment.TickCount + index);
            for (int i = 0; i < count; i++)
            {
                var c = colors[rnd.Next(colors.Length)];
                float sz = 9 + (float)rnd.NextDouble() * 9;
                var bit = UI.Rect(farm.World, c, "Bit");
                bit.rectTransform.At(0.5f, 0.5f, Centre.x, Centre.y, sz, sz);
                var vel = new Vector2(((float)rnd.NextDouble() * 2 - 1) * 260f, 220f + (float)rnd.NextDouble() * 260f) * power;
                float spin = ((float)rnd.NextDouble() * 2 - 1) * 540f, born = Time.unscaledTime, life = 0.55f + (float)rnd.NextDouble() * 0.25f;
                var pos = Centre;
                bit.Live(() =>
                {
                    float dt = Time.unscaledDeltaTime, age = Time.unscaledTime - born;
                    vel.y -= 1300f * dt;
                    pos += vel * dt;
                    bit.rectTransform.anchoredPosition = pos;
                    bit.rectTransform.localRotation = Quaternion.Euler(0, 0, spin * age);
                    bit.color = new Color(c.r, c.g, c.b, 1f - Mathf.Clamp01((age - life * 0.6f) / (life * 0.4f)));
                    if (age > life) UnityEngine.Object.Destroy(bit.gameObject);
                }, 0f);
            }
        }

        /// <summary>Harvested produce arcs from the plot into the crate slot, which bounces when it lands.</summary>
        public void FlyToCrate(string sprite, Color tint, int count)
        {
            if (!farm.Targets.TryGetValue("crate", out var target)) return;
            var app = GameApp.I;
            for (int i = 0; i < Mathf.Clamp(count, 1, 5); i++)
            {
                var icon = UI.Img(farm.Root, sprite, tint, true, "Flying");
                icon.rectTransform.Size(70, 70);
                Vector3 from = content.rectTransform.position, to = target.position;
                Vector3 lift = (from + to) / 2f + new Vector3(0, Mathf.Abs(to.x - from.x) * 0.35f + 120f * app.CanvasRect.lossyScale.y, 0);
                icon.rectTransform.position = from;
                float born = Time.unscaledTime + i * 0.08f;
                bool last = i == Mathf.Clamp(count, 1, 5) - 1;
                icon.enabled = false;
                icon.Live(() =>
                {
                    float a = (Time.unscaledTime - born) / 0.6f;
                    if (a < 0) return;
                    icon.enabled = true;
                    float e = 1f - (1f - Mathf.Clamp01(a)) * (1f - Mathf.Clamp01(a));   // ease out
                    var m1 = Vector3.Lerp(from, lift, e); var m2 = Vector3.Lerp(lift, to, e);
                    icon.rectTransform.position = Vector3.Lerp(m1, m2, e);
                    icon.rectTransform.localScale = Vector3.one * Mathf.Lerp(1.1f, 0.55f, e);
                    if (a >= 1f)
                    {
                        UnityEngine.Object.Destroy(icon.gameObject);
                        if (last) app.StartCoroutine(Punch(target));
                    }
                }, 0f);
            }
        }

        public static System.Collections.IEnumerator Punch(RectTransform t, float amount = 0.25f)
        {
            float a = 0;
            while (a < 1f && t != null)
            {
                a += Time.unscaledDeltaTime / 0.3f;
                t.localScale = Vector3.one * (1f + amount * Mathf.Sin(Mathf.Clamp01(a) * Mathf.PI));
                yield return null;
            }
            if (t != null) t.localScale = Vector3.one;
        }

        public void Float(string text, Color color)
        {
            var t = UI.Label(farm.World, text, 34, color, TextAnchor.MiddleCenter, true).Outlined(new Color(0.12f, 0.07f, 0.03f), 2.5f);
            var start = root.anchoredPosition + new Vector2(0, 90);
            t.rectTransform.At(0.5f, 0.5f, start.x, start.y, 400, 50);
            float born = Time.unscaledTime;
            t.Live(() =>
            {
                float a = Time.unscaledTime - born;
                t.rectTransform.anchoredPosition = start + new Vector2(0, a * 70);
                t.color = new Color(color.r, color.g, color.b, 1f - Mathf.Clamp01((a - 0.8f) / 0.6f));
                if (a > 1.4f) UnityEngine.Object.Destroy(t.gameObject);
            }, 0.02f);
        }

        public void Splash(string sprite)
        {
            var i = UI.Img(root, sprite);
            i.rectTransform.At(0.5f, 0.5f, 0, ht / 2f - hd / 2f + 60, 48, 48);
            float born = Time.unscaledTime;
            i.Live(() =>
            {
                float a = Time.unscaledTime - born;
                i.rectTransform.anchoredPosition += new Vector2(0, -3);
                i.color = new Color(1, 1, 1, 1 - a / 0.5f);
                if (a > 0.5f) UnityEngine.Object.Destroy(i.gameObject);
            }, 0.02f);
        }
    }
}
