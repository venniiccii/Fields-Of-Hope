using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace FieldsOfHope
{
    public static class Kit
    {
        /// <summary>A row of tab buttons; returns the row so the caller can place it.</summary>
        public static RectTransform Tabs(Transform parent, string[] names, string current, Action<string> onSelect, float width = 190)
        {
            var row = UI.HRow(parent, 58, 8, "Tabs");
            row.childAlignment = TextAnchor.MiddleCenter;
            foreach (var n in names)
            {
                var name = n;
                var b = UI.TextButton(row.transform, n, () => onSelect(name), n == current ? "tab_on" : "tab", 22);
                b.Layout(width, 54);
            }
            return (RectTransform)row.transform;
        }

        public static Image Row(Transform parent, float height, string sprite = "row")
        {
            var r = UI.Sliced(parent, sprite, null, 1f, "Row");
            r.Layout(-1, height);
            return r;
        }

        public static Image Icon(Transform parent, string sprite, float x, float size, Color? tint = null)
        {
            var i = UI.Img(parent, sprite, tint);
            i.rectTransform.At(0, 0.5f, x, 0, size, size, 0, 0.5f);
            return i;
        }

        public static Text Text(Transform parent, string s, int size, float left, float top, float right, float bottom, Color? color = null, TextAnchor anchor = TextAnchor.UpperLeft, bool bold = false)
        {
            var t = UI.Label(parent, s, size, color ?? UI.Ink, anchor, bold);
            t.rectTransform.Fill(left, top, right, bottom);
            return t;
        }

        public static Button Button(Transform parent, string label, Action onClick, float right, float w, float h = 52, string style = "btn_green", int size = 22, bool sound = true)
        {
            var b = UI.TextButton(parent, label, onClick, style, size, null, sound);
            ((RectTransform)b.transform).At(1, 0.5f, -right, 0, w, h, 1, 0.5f);
            return b;
        }

        public static string Coins(int c) => c.ToString("N0") + "c";
    }

    // ====================================================================== plot detail and planting menu
    public class PlotPanel : Panel
    {
        readonly int index;
        RectTransform content;
        bool useFertilizer;
        public PlotPanel(int index) { this.index = index; }
        public override string Key => "plot";

        public override void Build(RectTransform layer) => content = Frame(layer, "Plot " + (index + 1), 980, 760);

        public override void Refresh()
        {
            UI.Clear(content);
            var p = S.PlotAt(index);
            switch (p.state)
            {
                case PlotState.Blocked: BuildBlocked(p); break;
                case PlotState.Cleared: BuildForSale(); break;
                case PlotState.Empty: BuildPlanting(); break;
                default: BuildCrop(p); break;
            }
        }

        void BuildBlocked(Plot p)
        {
            var icon = UI.Img(content, null);
            icon.sprite = PlotView.ObstacleSprite(p.obstacle);
            icon.rectTransform.At(0.5f, 1f, 0, -20, 180, 180, 0.5f, 1f);
            Kit.Text(content, Defs.ObstacleNote(p.obstacle) + "\n\nUse the Axe to clear it. Cleared land can then be bought as a new plot (" +
                S.OwnedPlots(S.Here) + "/" + Defs.MaxPlots + " plots owned).", 28, 20, 220, 20, 100, null, TextAnchor.UpperCenter);
            var b = UI.TextButton(content, "Clear with Axe", () => { Close(); App.Farm.ClearLand(index); }, "btn_green", 28);
            ((RectTransform)b.transform).At(0.5f, 0f, 0, 10, 340, 70, 0.5f, 0f);
        }

        void BuildForSale()
        {
            int n = S.NextPlotNumber(S.Here);
            var sign = UI.Img(content, "sign_sale"); sign.rectTransform.At(0.5f, 1f, 0, -10, 160, 160, 0.5f, 1f);
            if (n > Defs.MaxPlots) { Kit.Text(content, "This farm has reached its 12-plot limit.", 28, 20, 200, 20, 100, null, TextAnchor.UpperCenter); return; }
            int price = Defs.PlotPrice(S.Save.currentLocation, n), lv = Defs.PlotLevels[n];
            string why = S.Save.level < lv ? "Reach Level " + lv + " first." : S.Save.coins < price ? "Need " + (price - S.Save.coins) + " more coins." : "";
            Kit.Text(content, "Cleared land, ready to become <b>plot " + n + "</b>.\n\nPrice: " + Kit.Coins(price) + "   ·   Level needed: " + lv + "\nYou own " + S.OwnedPlots(S.Here) + "/" + Defs.MaxPlots +
                " plots here.\n\nMore plots raise supply, but community requests grow with your farm too.\n<color=#C84030>" + why + "</color>", 26, 20, 190, 20, 100, null, TextAnchor.UpperCenter);
            var b = UI.TextButton(content, "Buy for " + Kit.Coins(price), () => App.Act(tx => S.BuyPlot(tx, index)), "btn_green", 28);
            ((RectTransform)b.transform).At(0.5f, 0f, 0, 10, 360, 70, 0.5f, 0f);
            b.interactable = why == "";
        }

        void BuildPlanting()
        {
            int fert = S.Count("fertilizer");
            var top = UI.New("Top", content).At(0, 1, 0, 0, 0, 60, 0, 1);
            top.anchorMax = new Vector2(1, 1);
            Kit.Text(top, "What would you like to plant?", 28, 0, 6, 360, 0, null, TextAnchor.UpperLeft, true);
            var ft = UI.TextButton(top, (useFertilizer ? "[x] " : "[ ] ") + "Fertilizer (" + fert + ")", () => { useFertilizer = !useFertilizer; Refresh(); }, useFertilizer ? "btn_green" : "btn", 22);
            ((RectTransform)ft.transform).At(1, 1, 0, 0, 330, 54, 1, 1);
            ft.interactable = fert > 0;
            if (fert == 0) useFertilizer = false;

            var sr = UI.Scroll(content, out var list);
            ((RectTransform)sr.transform).Fill(0, 70, 0, 0);
            var crops = Defs.Crops.OrderBy(c => c.location != S.Save.currentLocation).ThenBy(c => c.unlockLevel).ThenBy(c => c.seedPrice);
            bool tutorialLock = !S.Save.tutorialDone && App.Tutorial != null && App.Tutorial.WantsLettuceOnly;
            foreach (var c in crops)
            {
                string reason = S.PlantBlockReason(c);
                if (reason == null && tutorialLock && c.id != "lettuce") reason = "Plant Lettuce for the tutorial.";
                if (c.location != S.Save.currentLocation && !S.Loc(c.location).unlocked) continue;
                var row = Kit.Row(list, 104);
                Kit.Icon(row.transform, c.icon, 14, 80, c.tint);
                Kit.Text(row.transform, c.name + "  <size=20><color=#7a5a3a>owned: " + S.Count(c.SeedId) + " seeds</color></size>", 26, 110, 12, 240, 50, null, TextAnchor.UpperLeft, true);
                string info = (c.orchard ? "Establish " + c.growMin + " min, then " + c.harvests + " harvests" : "Grows in " + (c.id == "lettuce" && !S.Save.tutorialDone ? "2" : c.growMin.ToString()) + " min") +
                              " · Yield " + c.yield + " · " + c.price + "c each";
                Kit.Text(row.transform, reason ?? info, 20, 110, 52, 240, 8, reason != null ? UI.Red : UI.Muted);
                var cid = c.id;
                if (reason == null)
                    Kit.Button(row.transform, "Plant", () =>
                    {
                        // planting has its own sound instead of the button click + generic chime
                        var r = App.Act(tx => S.Plant(tx, index, cid, useFertilizer), "plant", false, Sfx.Plant);
                        if (r.ok) { Close(); App.Farm?.Plots[index].Burst(PlotView.SoilColors, 14); }
                    }, 14, 200, sound: false);
                else if (S.Count(c.SeedId) == 0 && c.location == S.Save.currentLocation && c.unlockLevel <= S.Save.level)
                    Kit.Button(row.transform, "Buy seeds", () => App.Open(new ShopPanel(c.hybrid ? "Featured" : "Seeds")), 14, 200, 52, "btn");
            }
        }

        void BuildCrop(Plot p)
        {
            var c = Defs.Crop(p.crop);
            var icon = UI.Img(content, c.icon, c.tint);
            icon.rectTransform.At(0, 1, 10, -6, 130, 130, 0, 1);
            Kit.Text(content, c.name + (c.orchard ? "  <size=22>(orchard tree)</size>" : ""), 34, 160, 6, 10, 0, null, TextAnchor.UpperLeft, true);
            var (barBg, barFill) = UI.Bar(content, new Color(0.55f, 0.85f, 0.35f));
            barBg.rectTransform.At(0, 1, 160, -58, 560, 26, 0, 1);
            var timer = UI.Label(content, "", 24, UI.Ink, TextAnchor.MiddleLeft, true);
            timer.rectTransform.At(0, 1, 740, -50, 200, 40, 0, 1);
            barBg.Live(() =>
            {
                var q = S.PlotAt(index);
                if (q.crop == null) { timer.text = ""; return; }
                UI.SetBar(barFill, q.total > 0 ? q.progress / q.total : 1);
                if (q.state == PlotState.Ready) { timer.text = "Ready!"; return; }
                float rate = S.IsWatered(q) ? 1f : Defs.UnwateredRate;
                if (q.pest) rate *= 0.7f;
                if (S.ActiveEvent(S.Here, "drought") != null && !S.IsWatered(q)) rate = q.mulch ? 0.5f : 0f;
                timer.text = rate <= 0 ? "Stalled!" : S.FormatDuration((q.total - q.progress) / rate);
            });

            var lines = new List<string>();
            int need = S.HereDef.waterings;
            if (p.state == PlotState.Growing)
            {
                if (S.ActiveEvent(S.Here, "rain") != null) lines.Add("Water: the rain is watering this plot");
                else if (need == 0) lines.Add("Water: humid soil, watering rarely needed");
                else lines.Add("Water: " + (S.IsWatered(p) ? "watered" : "<color=#C84030>needs water (grows at half speed)</color>") +
                               (need >= 2 && !p.mulch ? "  (" + p.waterings + "/2 this cycle)" : ""));
            }
            int fat = S.FatiguePenaltyPct(p);
            lines.Add("Soil: " + (fat > 0 ? "<color=#C84030>fatigued, -" + fat + "% yield</color> (rotate crops or fertilize)" : p.repeatCount >= 2 ? "same crop twice: rotate next time" : "healthy"));
            lines.Add("Fertilizer: " + (p.fertilized ? "applied (+20% yield)" : "none") + (p.mulch ? " · Mulched" : ""));
            if (p.pest) lines.Add("<color=#C84030>Pests! Growing 30% slower and -25% yield until treated.</color>");
            if (S.LocationHasEvent(S.Here, "rain")) lines.Add("Heavy rain: " + (p.trench ? "protected by a trench" : p.cover ? "protected by a Rain Cover" : "<color=#C84030>unprotected</color>"));
            if (p.yieldMod < 0.999f) lines.Add("Weather damage: -" + Mathf.RoundToInt((1 - p.yieldMod) * 100) + "% yield");
            if (c.orchard) lines.Add("Harvests left on this tree: " + p.harvestsLeft + (p.established ? "" : " (establishing)"));
            lines.Add("Expected harvest: " + S.ExpectedYield(p) + " " + c.name);
            lines.Add("<i>" + c.realNote + "</i>");
            Kit.Text(content, string.Join("\n", lines), 24, 10, 150, 10, 90);

            var row = UI.HRow(content, 64, 10);
            row.childAlignment = TextAnchor.MiddleCenter;
            ((RectTransform)row.transform).At(0.5f, 0f, 0, 6, 880, 64, 0.5f, 0f);
            void Btn(string label, Action a, string style = "btn")
            {
                var b = UI.TextButton(row.transform, label, a, style, 22);
                b.Layout(Mathf.Max(150, 30 + label.Length * 13), 60);
            }
            if (p.state == PlotState.Ready) Btn("Harvest", () => { Close(); App.Farm.Harvest(index); }, "btn_green");
            if (p.state == PlotState.Growing && need > 0 && !S.IsWatered(p) || (p.state == PlotState.Growing && need >= 2 && p.waterings < (p.mulch ? 1 : 2) && p.progress >= p.total / 2f))
                Btn("Water", () => { if (App.Act(tx => S.Water(tx, index), "water").ok) App.Farm?.Plots[index].Burst(PlotView.WaterColors, 10, 0.7f); }, "btn_green");
            if (p.state == PlotState.Growing && !p.fertilized) Btn("Fertilize (" + S.Count("fertilizer") + ")", () => App.Act(tx => S.Fertilize(tx, index), "fertilize"));
            if (p.pest) Btn("Pest Spray (" + S.Count("pest_spray") + ")", () => App.Act(tx => S.UseOnPlot(tx, index, "pest_spray")), "btn_green");
            if (S.LocationHasEvent(S.Here, "rain") && !p.trench && !p.cover)
            {
                Btn("Dig trench", () => App.Act(tx => S.DigTrench(tx, index)), "btn_green");
                Btn("Rain Cover (" + S.Count("rain_cover") + ")", () => App.Act(tx => S.UseOnPlot(tx, index, "rain_cover")));
            }
            if (p.state == PlotState.Growing && !p.mulch && need > 0) Btn("Mulch (" + S.Count("mulch") + ")", () => App.Act(tx => S.UseOnPlot(tx, index, "mulch")));
        }
    }

    // ====================================================================== community shop (SHOP-01..03)
    public class ShopPanel : Panel
    {
        string tab;
        int page;
        RectTransform content;
        const int PerPage = 8;
        public ShopPanel(string tab = "Featured") { this.tab = tab; }
        public override string Key => "shop";

        public override void Build(RectTransform layer) => content = Frame(layer, "Community Shop", 1180, 950, -40);

        IEnumerable<ShopItem> ItemsFor(string t)
        {
            var here = S.Save.currentLocation;
            if (t == "Featured")
            {
                var seed = Defs.Crops.Where(c => c.location == here && c.unlockLevel <= S.Save.level && !c.hybrid).OrderBy(c => c.seedPrice).FirstOrDefault();
                var list = Defs.Items.Where(i => i.cp > 0).ToList();
                if (seed != null) list.Insert(0, Defs.Item(seed.SeedId));
                list.Insert(1, Defs.Item("fertilizer"));
                return list;
            }
            if (t == "Seeds")
                return Defs.Items.Where(i => i.kind == ItemKind.Seed && !Defs.Crop(i.crop).hybrid)
                    .OrderBy(i => i.needsLocation != here).ThenBy(i => Defs.Locations.FindIndex(l => l.id == i.needsLocation)).ThenBy(i => i.level);
            return Defs.Items.Where(i => i.tab == t);
        }

        public override void Refresh()
        {
            UI.Clear(content);
            Kit.Tabs(content, Defs.ShopTabs, tab, t => { tab = t; page = 0; Refresh(); }, 186).At(0.5f, 1f, 0, 0, 1000, 58, 0.5f, 1f);

            var items = ItemsFor(tab).ToList();
            int pages = Mathf.Max(1, Mathf.CeilToInt(items.Count / (float)PerPage));
            page = Mathf.Clamp(page, 0, pages - 1);

            var grid = UI.New("Grid", content).Fill(0, 70, 0, 70);
            var g = grid.gameObject.AddComponent<GridLayoutGroup>();
            g.cellSize = new Vector2(248, 350); g.spacing = new Vector2(16, 12);
            g.childAlignment = TextAnchor.UpperCenter; g.constraint = GridLayoutGroup.Constraint.FixedColumnCount; g.constraintCount = 4;
            foreach (var it in items.Skip(page * PerPage).Take(PerPage)) Card(grid, it);

            var bottom = UI.New("Bottom", content).At(0.5f, 0f, 0, 0, 1060, 60, 0.5f, 0f);
            var prev = UI.TextButton(bottom, "<", () => { page--; Refresh(); }, "btn", 28);
            ((RectTransform)prev.transform).At(0.5f, 0.5f, -110, 0, 64, 54);
            prev.interactable = page > 0;
            var pl = UI.Label(bottom, (page + 1) + "/" + pages, 28, UI.Ink, TextAnchor.MiddleCenter, true);
            pl.rectTransform.At(0.5f, 0.5f, 0, 0, 120, 54);
            var next = UI.TextButton(bottom, ">", () => { page++; Refresh(); }, "btn", 28);
            ((RectTransform)next.transform).At(0.5f, 0.5f, 110, 0, 64, 54);
            next.interactable = page < pages - 1;
            var wallet = UI.Label(bottom, "", 24, UI.Ink, TextAnchor.MiddleLeft, true);
            wallet.rectTransform.At(0, 0.5f, 0, 0, 380, 54, 0, 0.5f);
            wallet.Live(() => wallet.text = "Coins " + S.Save.coins.ToString("N0") + "   <color=#8A5CD6>CP " + S.Save.cp + "</color>");
            var inv = UI.TextButton(bottom, "Inventory", () => App.Open(new InventoryPanel()), "btn", 24);
            ((RectTransform)inv.transform).At(1, 0.5f, 0, 0, 200, 54, 1, 0.5f);
        }

        void Card(RectTransform grid, ShopItem it)
        {
            var card = UI.Sliced(grid, "card", null, 1f, it.name);
            var name = Kit.Text(card.transform, it.name, 21, 10, 8, 10, 0, null, TextAnchor.UpperCenter, true);
            name.rectTransform.Fill(8, 8, 8, 284);
            var icon = UI.Img(card.transform, it.icon, it.crop != null ? Defs.Crop(it.crop).tint : (Color?)null);
            icon.rectTransform.At(0.5f, 1f, 0, -58, 80, 80, 0.5f, 1f);

            var price = UI.HRow(card.transform, 30, 4, "Price");
            price.childAlignment = TextAnchor.MiddleCenter;
            ((RectTransform)price.transform).At(0.5f, 1f, 0, -142, 230, 30, 0.5f, 1f);
            var ci = UI.Img(price.transform, "icon_coin"); ci.Layout(28, 28);
            var pt = UI.Label(price.transform, it.coins.ToString("N0"), 24, UI.Ink, TextAnchor.MiddleLeft, true); pt.Layout(90, 30);
            if (it.cp > 0)
            {
                var cp = UI.Img(price.transform, "icon_cp"); cp.Layout(26, 26);
                var cpt = UI.Label(price.transform, it.cp.ToString(), 24, UI.Purple, TextAnchor.MiddleLeft, true); cpt.Layout(40, 30);
            }

            var tag = UI.Sliced(card.transform, "tag_cp", null, 1f, "Tag");
            tag.rectTransform.At(0.5f, 1f, 0, -176, 220, 26, 0.5f, 1f);
            string tagText;
            string info;
            if (it.crop != null)
            {
                var c = Defs.Crop(it.crop);
                int cpPerHarvest = c.yield * c.harvests / 2;
                tagText = it.cp > 0 ? "Costs " + it.cp + " Community Points" : "Community Points +" + cpPerHarvest;
                info = Defs.Loc(c.location).climate + "\n" + (c.orchard ? c.growMin + "m + " + c.harvests + " harvests" : c.growMin + " min") + " · Yield " + c.yield + "\nProfit " + (c.Profit >= 0 ? "+" : "") + c.Profit + "c / seed";
            }
            else
            {
                tagText = it.cp > 0 ? "Costs " + it.cp + " Community Points" : "Community Supply";
                info = it.desc;
            }
            var tt = UI.Label(tag.transform, tagText, 15, Color.white, TextAnchor.MiddleCenter, true);
            tt.rectTransform.Fill(4, 0, 4, 0);
            Kit.Text(card.transform, info, 16, 12, 208, 12, 84, UI.Muted, TextAnchor.UpperCenter);

            string block1 = S.BuyBlockReason(it, 1);
            bool stackable = it.kind == ItemKind.Seed || it.kind == ItemKind.Supply;
            int owned = S.OwnedCount(it);
            if (block1 != null && (block1.StartsWith("Reach") || block1.StartsWith("Unlocks") || block1 == "Already owned"))
            {
                Kit.Text(card.transform, (block1 == "Already owned" ? "" : "<b>LOCKED</b>\n") + block1, 18, 10, 270, 10, 8, block1 == "Already owned" ? UI.Green : UI.Red, TextAnchor.MiddleCenter);
                if (block1 != "Already owned") { card.color = new Color(0.82f, 0.8f, 0.78f); icon.color = new Color(0.5f, 0.5f, 0.5f, 0.7f); }
                return;
            }
            var ownedT = Kit.Text(card.transform, owned > 0 ? "x" + owned : "", 18, 0, 64, 14, 0, UI.Muted, TextAnchor.UpperRight, true);
            var row = UI.HRow(card.transform, 50, 6, "Buy");
            row.childAlignment = TextAnchor.MiddleCenter;
            ((RectTransform)row.transform).At(0.5f, 0f, 0, 10, 230, 50, 0.5f, 0f);
            var id = it.id;
            var b1 = UI.TextButton(row.transform, stackable ? "Buy 1" : "Buy", () => { if (App.Act(tx => S.Buy(tx, id, 1), "buy").ok) Sfx.Coin(); }, "btn_green", 20);
            b1.Layout(stackable ? 104 : 200, 48);
            b1.interactable = block1 == null;
            if (stackable)
            {
                var block5 = S.BuyBlockReason(it, 5);
                var b5 = UI.TextButton(row.transform, "Buy 5", () => { if (App.Act(tx => S.Buy(tx, id, 5), "buy").ok) Sfx.Coin(); }, "btn_green", 20);
                b5.Layout(104, 48);
                b5.interactable = block5 == null;
            }
            if (block1 != null)
            {
                var why = Kit.Text(card.transform, block1, 16, 8, 0, 8, 62, UI.Red, TextAnchor.LowerCenter, true);
                why.horizontalOverflow = HorizontalWrapMode.Overflow;
            }
        }
    }

    // ====================================================================== inventory and storage (INV-01..04)
    public class InventoryPanel : Panel
    {
        static readonly string[] Tabs = { "Seeds", "Harvested Crops", "Tools", "Other Resources" };
        string tab;
        RectTransform content;
        public InventoryPanel(string tab = "Seeds") { this.tab = tab; }
        public override string Key => "inventory";

        public override void Build(RectTransform layer) => content = Frame(layer, "Inventory", 1080, 860, -30);

        public override void Refresh()
        {
            UI.Clear(content);
            Kit.Tabs(content, Tabs, tab, t => { tab = t; Refresh(); }, 228).At(0.5f, 1f, 0, 0, 980, 58, 0.5f, 1f);

            var store = UI.New("Storage", content).At(0, 1, 0, -68, 0, 44, 0, 1);
            store.anchorMax = new Vector2(1, 1);
            int used = S.UsedSlots, cap = S.StorageCapacity;
            Kit.Text(store, "Storage: " + used + "/" + cap + " slots  <size=18>(20 of one item per slot; tools use no slots)</size>", 22, 0, 6, 330, 0, null, TextAnchor.UpperLeft, true);
            var (bg, fill) = UI.Bar(store, used >= cap ? UI.Red : new Color(0.9f, 0.65f, 0.25f));
            bg.rectTransform.At(1, 0.5f, -150, 0, 160, 20, 1, 0.5f);
            UI.SetBar(fill, used / (float)cap);
            var shop = UI.TextButton(store, "Shop", () => App.Open(new ShopPanel()), "btn", 22);
            ((RectTransform)shop.transform).At(1, 0.5f, 0, 0, 130, 46, 1, 0.5f);

            float top = 120;
            if (used >= cap * 0.9f)
            {
                var banner = UI.Sliced(content, "row", new Color(1f, 0.85f, 0.8f), 1f, "Full");
                banner.rectTransform.At(0, 1, 0, -118, 0, 56, 0, 1);
                banner.rectTransform.anchorMax = new Vector2(1, 1);
                banner.rectTransform.sizeDelta = new Vector2(0, 56);
                Kit.Text(banner.transform, used >= cap ? "Storage full! Sell, deliver or upgrade." : "Storage almost full.", 22, 16, 14, 260, 6, UI.Red, TextAnchor.UpperLeft, true);
                Kit.Button(banner.transform, "Upgrade storage", () => App.Open(new ShopPanel("Upgrades")), 10, 240, 44, "btn", 20);
                top = 186;
            }

            var sr = UI.Scroll(content, out var list);
            ((RectTransform)sr.transform).Fill(0, top, 0, 0);
            int rows = 0;
            if (tab == "Seeds")
                foreach (var s in S.Save.items.Where(i => i.id.StartsWith("seed_")).OrderBy(i => i.id))
                {
                    var c = Defs.Crop(s.id.Substring(5));
                    var row = Kit.Row(list, 92); rows++;
                    Kit.Icon(row.transform, c.hybrid ? "item_rare_seed" : c.icon, 14, 70, c.tint);
                    Kit.Text(row.transform, Defs.Item(s.id).name + "  x" + s.qty, 26, 100, 12, 300, 40, null, TextAnchor.UpperLeft, true);
                    string where = c.location == S.Save.currentLocation ? "Plant on an empty plot here. Seeds are used up when planted." : "Grows in " + Defs.Loc(c.location).name;
                    Kit.Text(row.transform, where, 20, 100, 50, 300, 6, UI.Muted);
                }
            else if (tab == "Harvested Crops")
                foreach (var s in S.Save.items.Where(i => i.id.StartsWith("crop_")).OrderByDescending(i => i.qty))
                {
                    var c = Defs.Crop(s.id.Substring(5));
                    int mp = S.MarketPrice(c.id);
                    var row = Kit.Row(list, 92); rows++;
                    Kit.Icon(row.transform, c.icon, 14, 70, c.tint);
                    Kit.Text(row.transform, c.name + "  x" + s.qty, 26, 100, 12, 420, 40, null, TextAnchor.UpperLeft, true);
                    Kit.Text(row.transform, "Community pays " + c.price + "c each (+XP, +CP). Market pays " + mp + "c.", 19, 100, 50, 420, 6, UI.Muted);
                    var id = s.id; int qty = s.qty;
                    Kit.Button(row.transform, "Sell all (" + mp * qty + "c)", () => App.Act(tx => S.SellMarket(tx, id, qty)), 14, 200, 50, "btn", 20);
                    Kit.Button(row.transform, "Sell 1", () => App.Act(tx => S.SellMarket(tx, id, 1)), 224, 110, 50, "btn", 20);
                    Kit.Button(row.transform, "Deliver", () => App.Open(new CommunityPanel()), 344, 110, 50, "btn_green", 20);
                }
            else if (tab == "Tools")
            {
                void ToolRow(string icon, string name, string desc)
                {
                    var row = Kit.Row(list, 92); rows++;
                    Kit.Icon(row.transform, icon, 10, 78);
                    Kit.Text(row.transform, name, 26, 100, 12, 20, 40, null, TextAnchor.UpperLeft, true);
                    Kit.Text(row.transform, desc, 20, 100, 50, 20, 6, UI.Muted);
                }
                ToolRow("slot_basket", "Harvest Basket", "Select it, then tap a ready plot. (key 1)");
                ToolRow("slot_can", "Watering Can", "Dry plots grow at half speed. (key 2)");
                ToolRow("slot_axe", "Axe", "Clears rocks and stumps so new plots can be bought. (key 4)");
                ToolRow("slot_shovel", "Shovel", "Digs drainage trenches when heavy rain is coming. (key 5)");
                if (S.Has("tool_spade")) ToolRow("item_spade", "Gilded Spade", "One trench protects every plot.");
                if (S.Save.smallCrates + S.Save.largeCrates > 0) ToolRow("slot_crate", "Storage crates", S.Save.smallCrates + " small, " + S.Save.largeCrates + " large: +" + S.Save.bonusSlots + " slots");
                if (S.Here.scarecrow) ToolRow("item_scarecrow", "Scarecrow", "Pest outbreaks are 25% less likely on this farm.");
                if (S.Save.tankUpgrade) ToolRow("item_tank", "Water Tank Upgrade", "Ilocos tank holds " + Defs.TankUpgraded + " waterings.");
            }
            else
                foreach (var s in S.Save.items.Where(i => !i.id.StartsWith("seed_") && !i.id.StartsWith("crop_") && !i.id.StartsWith("tool_")))
                {
                    var row = Kit.Row(list, 92); rows++;
                    Kit.Icon(row.transform, Defs.ItemIcon(s.id), 14, 70);
                    Kit.Text(row.transform, Defs.ItemName(s.id) + "  x" + s.qty, 26, 100, 12, 20, 40, null, TextAnchor.UpperLeft, true);
                    Kit.Text(row.transform, Defs.Item(s.id)?.desc ?? "", 20, 100, 50, 20, 6, UI.Muted);
                }
            if (rows == 0)
            {
                var empty = UI.Label(list, tab == "Harvested Crops" ? "No harvested crops yet. Harvest ready plots with the basket." : "Nothing here yet. Visit the Community Shop.", 24, UI.Muted);
                empty.Layout(-1, 120);
            }
        }
    }
}
