using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace FieldsOfHope
{
    public static class Backdrop
    {
        /// <summary>Full-screen image that covers the canvas without distortion.</summary>
        public static Image Cover(RectTransform parent, string sprite, Color? tint = null)
        {
            var holder = UI.New("Backdrop", parent).Fill();
            holder.gameObject.AddComponent<RectMask2D>();
            var img = UI.Img(holder, sprite, tint, false);
            var fit = img.gameObject.AddComponent<AspectRatioFitter>();
            fit.aspectMode = AspectRatioFitter.AspectMode.EnvelopeParent;
            fit.aspectRatio = img.sprite.rect.width / img.sprite.rect.height;
            LivingPainting.Apply(img, "mask_" + sprite.Replace("_bg", ""));   // title_bg -> mask_title; no mask, no motion
            return img;
        }
    }

    public class TitleScreen
    {
        public void Build(RectTransform layer)
        {
            var root = UI.New("Title", layer).Fill();
            Backdrop.Cover(root, "title_bg");

            var logo = UI.Img(root, "logo");
            logo.rectTransform.TL(705, 150, 1143, 690);
            var baseY = logo.rectTransform.anchoredPosition.y;
            logo.Live(() => logo.rectTransform.anchoredPosition = new Vector2(logo.rectTransform.anchoredPosition.x, baseY + Mathf.Sin(Time.unscaledTime * 1.6f) * 8f), 0.02f);

            var start = UI.Img(root, "btn_start");
            start.rectTransform.TL(97, 285, 556, 298);
            start.Clickable(() => GameApp.I.PressStart());

            var quit = UI.Img(root, "btn_quit");
            quit.rectTransform.TL(108, 540, 533, 277);
            quit.Clickable(() => GameApp.I.Confirm("Exit", "Exit the game?", "Confirm", () => GameApp.I.Quit()));

            var credit = UI.Label(root, "An educational farming game set in Baguio City, Ilocos Norte and Davao City", 22, UI.Cream, TextAnchor.LowerRight);
            credit.rectTransform.BR(24, 16, 1000, 40);
            credit.Outlined();
        }
    }

    /// <summary>
    /// Name-only sign in (the client's request): type a farmer name to start a new farm, or the same name to continue.
    /// Farms already on this device are one tap away.
    /// </summary>
    public class AuthScreen
    {
        readonly string notice, prefill;
        const int ListedFarms = 4;

        public AuthScreen(string notice, string prefillUser) { this.notice = notice; prefill = prefillUser; }

        public void Build(RectTransform layer)
        {
            var root = UI.New("Auth", layer).Fill();
            Backdrop.Cover(root, "title_bg", new Color(0.75f, 0.75f, 0.75f));
            var logo = UI.Img(root, "logo");
            logo.rectTransform.At(0.5f, 1f, -560, -30, 640, 380, 0.5f, 1f);

            var farms = GameApp.I.Server.DeviceFarms().Take(ListedFarms).ToList();
            float h = 450 + (farms.Count > 0 ? 70 + farms.Count * 78 : 0);
            var panel = UI.Sliced(root, "panel", null, 1f, "AuthPanel");
            panel.rectTransform.At(0.5f, 0.5f, 300, -10, 860, h);
            panel.raycastTarget = true;
            panel.Shadowed(6);
            var ribbon = UI.Sliced(panel.transform, "ribbon");
            ribbon.rectTransform.At(0.5f, 1f, 0, 34, 560, 70, 0.5f, 1f);
            UI.Label(ribbon.transform, "WHO'S FARMING?", 32, UI.Cream, TextAnchor.MiddleCenter, true).Outlined().rectTransform.Fill(30, 4, 30, 8);

            var body = UI.New("Body", panel.transform).Fill(70, 70, 70, 36);
            Stack(body);
            var noticeText = UI.Label(body, notice ?? "", 24, UI.Green, TextAnchor.MiddleCenter, true);
            noticeText.Layout(720, string.IsNullOrEmpty(notice) ? 4 : 44);

            var u = Field(body, "Farmer name", "e.g. Juan_Farmer", out var ue);
            if (!string.IsNullOrEmpty(prefill)) u.text = prefill;
            var hint = UI.Label(body, "A new name starts a new farm. Type the same name again to continue your progress.", 22, UI.Muted, TextAnchor.UpperCenter, true);
            hint.Layout(720, 64);

            void Play(string name)
            {
                var r = GameApp.I.Server.PlayAs(name, out var token);
                if (r.ok) { GameApp.I.LoginSucceeded(token); return; }
                Sfx.Error(); ue.text = r.message;
            }
            var go = UI.TextButton(body, "Play", () => Play(u.text), "btn_green", 34);
            go.Layout(360, 78);
            u.onValueChanged.AddListener(_ => ue.text = "");
            u.onSubmit.AddListener(_ => Play(u.text));

            if (farms.Count > 0)
            {
                var head = UI.Label(body, "Farms on this device", 24, UI.Ink, TextAnchor.LowerCenter, true);
                head.Layout(720, 56);
                foreach (var f in farms)
                {
                    var name = f;
                    var b = UI.TextButton(body, "Continue as " + name, () => Play(name), "btn", 26);
                    b.Layout(520, 68);
                }
            }

            var back = UI.TextButton(root, "< Title", () => GameApp.I.ShowTitle(), "btn", 26);
            ((RectTransform)back.transform).BL(30, 30, 200, 64);
            // on phones focusing a field pops the keyboard up over the form before the player taps anything
            if (!Application.isMobilePlatform && farms.Count == 0) u.ActivateInputField();
        }

        static InputField Field(Transform parent, string label, string placeholder, out Text error)
        {
            var group = UI.New(label, parent);
            var l = UI.Label(group, label, 26, UI.Ink, TextAnchor.LowerLeft, true);
            l.rectTransform.At(0, 1, 0, 0, 700, 34, 0, 1);
            var bg = UI.Sliced(group, "field", null, 1f, "Field");
            bg.rectTransform.At(0, 1, 0, -38, 720, 64, 0, 1);
            bg.raycastTarget = true;
            var text = UI.Label(bg.transform, "", 28, UI.Ink, TextAnchor.MiddleLeft);
            text.rectTransform.Fill(18, 4, 18, 4);
            text.supportRichText = false;
            text.horizontalOverflow = HorizontalWrapMode.Overflow;
            var ph = UI.Label(bg.transform, placeholder, 26, new Color(0.45f, 0.36f, 0.26f, 0.6f), TextAnchor.MiddleLeft);
            ph.rectTransform.Fill(18, 4, 18, 4);
            ph.fontStyle = FontStyle.Italic;
            var input = bg.gameObject.AddComponent<InputField>();
            input.targetGraphic = bg;
            input.textComponent = text;
            input.placeholder = ph;
            input.lineType = InputField.LineType.SingleLine;
            input.characterLimit = 16;
            input.contentType = InputField.ContentType.Standard;
            input.selectionColor = new Color(0.95f, 0.75f, 0.35f, 0.6f);
            input.caretColor = UI.Ink;
            error = UI.Label(group, "", 22, UI.Red, TextAnchor.UpperLeft, true);
            error.rectTransform.At(0, 1, 4, -106, 720, 30, 0, 1);
            group.Layout(720, 142);
            return input;
        }

        static VerticalLayoutGroup Stack(RectTransform body)
        {
            var v = (body.gameObject.TryGetComponent<VerticalLayoutGroup>(out var existing) ? existing : body.gameObject.AddComponent<VerticalLayoutGroup>());
            v.spacing = 4; v.childAlignment = TextAnchor.UpperCenter;
            v.childControlHeight = true; v.childControlWidth = true; v.childForceExpandHeight = false; v.childForceExpandWidth = false;
            return v;
        }

    }
}
