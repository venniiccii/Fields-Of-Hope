using System.Collections.Generic;
using UnityEngine;

namespace FieldsOfHope
{
    /// <summary>
    /// The village's daily rhythm. Each person heads home at dusk, goes to sleep and wakes at their own time. Every second
    /// or third evening there is a campfire from 8 to 9 pm, and some of the village goes. When it rains most people go
    /// indoors: a few watch from a doorway, some farmers keep working and children play in the puddles. Everything is a
    /// pure function of the person's name, the local day and the rain, so the village behaves the same after a reload,
    /// and it is easy to test (Tests/EditMode/RoutineTests).
    /// </summary>
    public static class Routine
    {
        /// <summary>Where someone wants to be: out at their place in the village, home for the night, at the campfire,
        /// in a doorway out of the rain, playing in the rain, or sheltering indoors in the nearest house.</summary>
        public enum Want { Out, Home, Camp, Shelter, Play, Indoors }

        public const float FireLit = 19.67f;     // 7:40 pm: the fire is lit as people arrive
        public const float FireDown = 20.95f;    // it burns down after the last song...
        public const float FireOut = 21.3f;      // ...and is out by 9:18 pm

        /// <summary>A stable number in [0, 1) for this person, day and purpose.</summary>
        public static float Hash(string who, int day, int salt)
        {
            unchecked
            {
                uint h = 2166136261u;
                if (who != null) foreach (char c in who) h = (h ^ c) * 16777619u;
                h = (h ^ (uint)day) * 16777619u; h ^= h >> 15;
                h = (h ^ (uint)salt) * 2246822519u; h ^= h >> 13;
                h *= 3266489917u; h ^= h >> 16;
                return (h & 0xFFFFFF) / 16777216f;
            }
        }

        // ---------------------------------------------------------------- campfire evenings
        static int cachedDay = int.MinValue;
        static bool cachedNight;

        /// <summary>Campfire evenings come every second or third day, decided by the calendar (local day numbers).</summary>
        public static bool CampfireNight(int day)
        {
            if (day == cachedDay) return cachedNight;
            bool night = false;
            if (day >= 0)
            {
                int d = 0;
                while (d < day) d += Hash("campfire", d, 1) < 0.5f ? 2 : 3;
                night = d == day;
            }
            cachedDay = day; cachedNight = night;
            return night;
        }

        /// <summary>How brightly the campfire burns (0 = out, 1 = roaring) at this time of day.</summary>
        public static float Fire(float hour, bool campfireNight, bool rain)
        {
            if (!campfireNight || rain || hour < FireLit || hour >= FireOut) return 0f;
            if (hour < FireLit + 0.12f) return (hour - FireLit) / 0.12f;
            if (hour < FireDown) return 1f;
            return Mathf.Lerp(1f, 0.15f, (hour - FireDown) / (FireOut - FireDown));     // down to embers
        }

        public static bool GoesToCampfire(string who, int day, bool kid) => Hash(who, day, 11) < (kid ? 0.5f : 0.36f);
        public static float CampArrive(string who, int day) => 19.75f + 0.28f * Hash(who, day, 12);   // 7:45 to 8:02 pm
        public static float CampLeave(string who, int day) => 20.9f + 0.16f * Hash(who, day, 13);     // 8:54 to 9:04 pm

        // ---------------------------------------------------------------- a day in someone's life (hours, local time)
        /// <summary>Home at dusk: most between 5:54 and 7:06 pm; night owls stay out until 7:06 to 7:48 pm.</summary>
        public static float HomeAt(string who, int day, bool owl) => owl ? 19.1f + 0.7f * Hash(who, day, 2) : 17.9f + 1.2f * Hash(who, day, 2);

        /// <summary>Lights out: between 8:48 and 10:12 pm, or soon after the campfire for those who went.</summary>
        public static float SleepAt(string who, int day, bool kid)
        {
            float at = kid ? 20.3f + 0.6f * Hash(who, day, 3) : 20.8f + 1.4f * Hash(who, day, 3);
            return GoesToCampfire(who, day, kid) && CampfireNight(day) ? Mathf.Max(at, CampLeave(who, day) + 0.2f + 0.3f * Hash(who, day, 4)) : at;
        }

        public static float WakeAt(string who, int day) => 5f + 1.3f * Hash(who, day, 5);           // 5:00 to 6:18 am

        /// <summary>Out of the house in the morning: farmers soon after waking, everyone else after breakfast.</summary>
        public static float OutAt(string who, int day, bool worker) =>
            WakeAt(who, day) + (worker ? 0.25f + 0.4f * Hash(who, day, 6) : 0.5f + 1.2f * Hash(who, day, 6));

        public static bool Asleep(string who, int day, float hour, bool kid) => hour >= SleepAt(who, day, kid) || hour < WakeAt(who, day);

        /// <summary>Where this person wants to be right now.</summary>
        public static Want Wanted(string who, VillageTime t, bool owl, bool worker, bool kid)
        {
            float h = t.hour;
            if (t.campfireNight && !t.rain && GoesToCampfire(who, t.day, kid) && h >= CampArrive(who, t.day) && h < CampLeave(who, t.day))
                return Want.Camp;
            if (h < OutAt(who, t.day, worker) || h >= HomeAt(who, t.day, owl)) return Want.Home;
            if (t.rain)
            {
                // each shower anew: most go in, a few watch from a doorway, some farmers carry on, children play in it
                float r = Hash(who, t.rainKey, 21);
                if (kid && r < 0.5f) return Want.Play;
                if (worker && r < 0.25f) return Want.Out;
                if (r < 0.2f) return Want.Shelter;
                return Want.Indoors;
            }
            return Want.Out;
        }
    }

    /// <summary>The ring of places round the campfire where people stand, facing the fire. Nobody stands right in front
    /// of it, so the flames stay in view.</summary>
    public class Campfire
    {
        public readonly Vector2 Center;
        readonly List<Vector2> seats = new List<Vector2>();
        readonly List<object> taken = new List<object>();
        readonly System.Random rnd = new System.Random(5);

        public Campfire(MapSpot spot)
        {
            Center = spot.V;
            // degrees with y down (90 = in front of the fire); an inner ring and, behind it, an outer one
            foreach (var a in new[] { 165f, 200f, 235f, 270f, 305f, 340f, 15f }) Add(a, 50f, 24f);
            foreach (var a in new[] { 190f, 222f, 255f, 287f, 318f, 350f }) Add(a, 82f, 38f);
        }

        void Add(float deg, float rx, float ry)
        {
            float r = deg * Mathf.Deg2Rad;
            seats.Add(Center + new Vector2(Mathf.Cos(r) * rx, Mathf.Sin(r) * ry));
            taken.Add(null);
        }

        public int Count => seats.Count;
        public Vector2 Seat(int i) => seats[i];
        public bool HasRoom => taken.Contains(null);

        /// <summary>A free place for <paramref name="who"/> (the inner ring first), or -1 when the circle is full.</summary>
        public int Claim(object who)
        {
            int had = taken.IndexOf(who);
            if (had >= 0) return had;
            var free = new List<int>();
            for (int i = 0; i < 7; i++) if (taken[i] == null) free.Add(i);
            if (free.Count == 0) for (int i = 7; i < taken.Count; i++) if (taken[i] == null) free.Add(i);
            if (free.Count == 0) return -1;
            int pick = free[rnd.Next(free.Count)];
            taken[pick] = who;
            return pick;
        }

        public void Release(object who) { int i = taken.IndexOf(who); if (i >= 0) taken[i] = null; }
    }
}
