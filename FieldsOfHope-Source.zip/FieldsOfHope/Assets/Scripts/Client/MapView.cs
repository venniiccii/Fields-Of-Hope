using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace FieldsOfHope
{
    /// <summary>
    /// Everything that stands on a location's farm map: buildings, trees, props, animals (Animals), villagers, walkers and the
    /// farmhand, all in one depth-sorted layer so they overlap correctly, with their speech bubbles in a layer above.
    /// Trees sway, the water wheel and wind-turbine rotors turn. Built from the location's <see cref="MapLayout"/>;
    /// rebuilt when the player travels.
    /// </summary>
    public class MapView
    {
        readonly FarmScreen farm;
        public readonly RectTransform Layer;
        readonly Villagers villagers;
        readonly Walkers walkers;
        readonly Emotes emotes;
        readonly Animals animals;
        public readonly Farmhand Farmhand;
        public readonly Campfire Campfire;      // null where the map has no campfire
        /// <summary>Who is in each house right now: awake (lights on) and asleep (zzz). Updated every frame.</summary>
        public readonly Dictionary<MapSpot, (int awake, int asleep)> Indoors = new Dictionary<MapSpot, (int awake, int asleep)>();
        readonly List<(RectTransform rt, float amount, float phase)> swayers = new List<(RectTransform, float, float)>();
        readonly List<(RectTransform rt, float speed)> spinners = new List<(RectTransform, float)>();
        /// <summary>The store and houses: tapping one opens the conversation with the community.</summary>
        public readonly List<RectTransform> Talkable = new List<RectTransform>();
        static readonly HashSet<string> TalkPlaces = new HashSet<string> { "store", "farmhouse", "kubo" };
        static readonly Dictionary<string, Sprite> sprites = new Dictionary<string, Sprite>();

        public MapView(FarmScreen farm, MapLayout map, int siblingIndex)
        {
            this.farm = farm;
            Layer = UI.New("Map Objects", farm.World).Fill();
            Layer.SetSiblingIndex(siblingIndex);
            Layer.gameObject.AddComponent<DepthSorter>();
            var rnd = new System.Random(map.ground?.GetHashCode() ?? 0);
            if (map.objects != null)
                foreach (var o in map.objects) Build(o, rnd);
            emotes = new Emotes(farm, siblingIndex + 1);
            var paths = new VillagePaths(map);
            var fireSpot = paths.Spots.Find(s => s.kind == "campfire");
            if (fireSpot != null) Campfire = new Campfire(fireSpot);
            villagers = new Villagers(farm, Layer, map.villagers, emotes, paths, Campfire);
            animals = new Animals(farm, Layer, map.animals, emotes);
            Farmhand = new Farmhand(farm, Layer, map, paths, emotes);
            // the farmhand is the walking farmer, so that villager no longer strolls about as well
            walkers = new Walkers(farm, Layer, map.walkers, paths, villagers, emotes, Campfire, who => Farmhand.Active && who == "farmer");
        }

        static Sprite S(string name)
        {
            if (!sprites.TryGetValue(name, out var s)) sprites[name] = s = Resources.Load<Sprite>("Map/" + name);
            return s;
        }

        void Build(MapObject o, System.Random rnd)
        {
            var sprite = S(o.s);
            if (sprite == null) return;
            float k = farm.Scale;
            var size = new Vector2(o.w * k, o.h * k);
            RectTransform holder;
            Image img;
            if (o.spin != 0)
            {
                // turning parts are centred on (x, y): the holder leans by tilt, its child squashes, the grandchild spins,
                // so the circle turns as an ellipse lying in the plane of the wall it is mounted on
                holder = UI.New(o.s, Layer).At(0.5f, 0.5f, 0, 0, size.x, size.y, 0.5f, 0.5f);
                holder.localRotation = Quaternion.Euler(0, 0, o.tilt);
                var squash = UI.New("Squash", holder).Fill();
                squash.localScale = new Vector3(o.squash * (o.flip ? -1 : 1), 1, 1);
                img = UI.Img(squash, null, Color.white, false, "Turning");
                img.rectTransform.Fill();
                spinners.Add((img.rectTransform, o.spin));
            }
            else
            {
                img = UI.Img(Layer, null, Color.white, false, o.s);
                holder = img.rectTransform;
                holder.At(0.5f, 0.5f, 0, 0, size.x, size.y, 0.5f, 0f);   // pivot on the foot
                holder.localScale = new Vector3((o.flip ? -1 : 1) * o.squash, 1, 1);
                if (o.sway > 0) swayers.Add((holder, o.sway, (float)rnd.NextDouble() * 6.28f));
            }
            img.sprite = sprite;
            img.raycastTarget = false;
            if (TalkPlaces.Contains(o.s))
            {
                img.Clickable(farm.Talk);   // a swipe that starts here still pans the farm
                Talkable.Add(holder);
            }
            holder.anchoredPosition = farm.BgToWorld(o.x, o.y);
            holder.gameObject.AddComponent<DepthKey>().y = o.depth;
        }

        public void Tick(VillageTime time)
        {
            float t = Time.unscaledTime, dt = Time.unscaledDeltaTime;
            foreach (var (rt, amount, phase) in swayers)
                rt.localRotation = Quaternion.Euler(0, 0, amount * (1.6f * Mathf.Sin(t * 1.3f + phase) + 0.6f * Mathf.Sin(t * 2.7f + phase * 2f)));
            foreach (var (rt, speed) in spinners)
                rt.localRotation = Quaternion.Euler(0, 0, rt.localEulerAngles.z - speed * dt);
            villagers.Tick(time);
            walkers.Tick(time);
            Farmhand.Tick(time);
            animals.Tick(time);
            emotes.Tick();
            Indoors.Clear();
            villagers.CountIndoors(Indoors, time);
            walkers.CountIndoors(Indoors, time);
            Farmhand.CountIndoors(Indoors, time);
        }

        public void Destroy() { Object.Destroy(Layer.gameObject); emotes.Destroy(); }
    }
}
