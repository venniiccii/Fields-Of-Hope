using System.Collections.Generic;
using UnityEngine;

namespace FieldsOfHope
{
    /// <summary>
    /// The village's walkable network, built from the paths drawn on the location's ground (map px). Paths that meet or
    /// nearly meet are joined, any separate pieces are linked across the grass at their closest points, and every spot
    /// (store, board, bench, door...) hangs off its nearest path point. Routes are shortest paths over that graph.
    /// </summary>
    public class VillagePaths
    {
        const float Step = 40f, Join = 36f;

        readonly List<Vector2> nodes = new List<Vector2>();
        readonly List<List<int>> links = new List<List<int>>();
        int pathNodes;
        public readonly List<MapSpot> Spots = new List<MapSpot>();
        readonly Dictionary<MapSpot, int> spotNode = new Dictionary<MapSpot, int>();

        public bool Empty => pathNodes == 0;

        public VillagePaths(MapLayout map)
        {
            var lineOf = new List<int>();
            var lines = new List<MapPoint[]>();
            if (map.paths != null) foreach (var p in map.paths) if (p.pts != null && p.pts.Length > 1) lines.Add(p.pts);
            // older layouts without paths: the walkers' own routes are the paths
            if (lines.Count == 0 && map.walkers != null) foreach (var w in map.walkers) if (w.route != null && w.route.Length > 1) lines.Add(w.route);

            for (int li = 0; li < lines.Count; li++)
            {
                int prev = -1;
                var pts = lines[li];
                for (int i = 0; i + 1 < pts.Length; i++)
                {
                    Vector2 a = pts[i].V, b = pts[i + 1].V;
                    int n = Mathf.Max(1, Mathf.CeilToInt(Vector2.Distance(a, b) / Step));
                    for (int k = prev < 0 ? 0 : 1; k <= n; k++)
                    {
                        int id = Add(Vector2.Lerp(a, b, k / (float)n));
                        lineOf.Add(li);
                        if (prev >= 0) Link(prev, id);
                        prev = id;
                    }
                }
            }
            pathNodes = nodes.Count;
            for (int i = 0; i < pathNodes; i++)
                for (int j = i + 1; j < pathNodes; j++)
                    if (lineOf[i] != lineOf[j] && Vector2.Distance(nodes[i], nodes[j]) < Join) Link(i, j);
            Connect();

            if (map.spots != null)
                foreach (var s in map.spots)
                {
                    if (s == null || string.IsNullOrEmpty(s.kind)) continue;
                    int id = Add(s.V);
                    if (pathNodes > 0) Link(id, Nearest(s.V));
                    spotNode[s] = id;
                    Spots.Add(s);
                }
        }

        int Add(Vector2 p) { nodes.Add(p); links.Add(new List<int>()); return nodes.Count - 1; }
        void Link(int a, int b) { if (a == b || links[a].Contains(b)) return; links[a].Add(b); links[b].Add(a); }

        /// <summary>Separate pieces of path are joined at their two closest points, across the grass.</summary>
        void Connect()
        {
            if (pathNodes == 0) return;
            while (true)
            {
                var seen = new bool[pathNodes];
                var stack = new Stack<int>(); stack.Push(0); seen[0] = true;
                while (stack.Count > 0) foreach (var n in links[stack.Pop()]) if (n < pathNodes && !seen[n]) { seen[n] = true; stack.Push(n); }
                int bi = -1, bj = -1; float best = float.MaxValue;
                for (int i = 0; i < pathNodes; i++)
                {
                    if (!seen[i]) continue;
                    for (int j = 0; j < pathNodes; j++)
                    {
                        if (seen[j]) continue;
                        float d = Vector2.Distance(nodes[i], nodes[j]);
                        if (d < best) { best = d; bi = i; bj = j; }
                    }
                }
                if (bj < 0) return;
                Link(bi, bj);
            }
        }

        /// <summary>The closest point on the paths themselves (not a spot).</summary>
        public int Nearest(Vector2 p)
        {
            int best = 0; float d = float.MaxValue;
            for (int i = 0; i < pathNodes; i++) { float e = (nodes[i] - p).sqrMagnitude; if (e < d) { d = e; best = i; } }
            return best;
        }

        public Vector2 RandomPathPoint(System.Random rnd) => pathNodes > 0 ? nodes[rnd.Next(pathNodes)] : Vector2.zero;

        /// <summary>Waypoints from <paramref name="from"/> to the spot (or any map point), along the paths.</summary>
        public List<Vector2> Route(Vector2 from, MapSpot to) => Route(from, spotNode.TryGetValue(to, out var n) ? n : Nearest(to.V), to.V);

        public List<Vector2> Route(Vector2 from, Vector2 to) => Route(from, Nearest(to), to);

        List<Vector2> Route(Vector2 from, int goal, Vector2 end)
        {
            var route = new List<Vector2>();
            if (pathNodes == 0) { route.Add(end); return route; }
            int start = Nearest(from);
            // Dijkstra over a few hundred nodes at most
            var dist = new float[nodes.Count]; var prev = new int[nodes.Count]; var done = new bool[nodes.Count];
            for (int i = 0; i < dist.Length; i++) { dist[i] = float.MaxValue; prev[i] = -1; }
            dist[start] = 0;
            while (true)
            {
                int u = -1; float best = float.MaxValue;
                for (int i = 0; i < dist.Length; i++) if (!done[i] && dist[i] < best) { best = dist[i]; u = i; }
                if (u < 0 || u == goal) break;
                done[u] = true;
                foreach (var v in links[u])
                {
                    float d = dist[u] + Vector2.Distance(nodes[u], nodes[v]);
                    if (d < dist[v]) { dist[v] = d; prev[v] = u; }
                }
            }
            for (int n = goal; n >= 0; n = prev[n]) route.Insert(0, nodes[n]);
            if (route.Count == 0 || prev[goal] < 0 && goal != start) { route.Clear(); route.Add(nodes[start]); }
            // skip the first path point if it lies behind us, so nobody steps back before setting off
            if (route.Count > 1 && Vector2.Dot(route[0] - from, route[1] - from) < 0) route.RemoveAt(0);
            if (route.Count == 0 || route[route.Count - 1] != end) route.Add(end);
            return route;
        }
    }
}
