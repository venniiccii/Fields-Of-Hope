using UnityEngine;

namespace FieldsOfHope
{
    /// <summary>
    /// Background music: loops the track at Resources/Audio/music_farm (any format Unity imports, e.g. .ogg or .mp3).
    /// With no track in the project the game is simply silent and the Settings row is hidden.
    /// The On/Off choice is kept per device, so it also applies on the title screen before anyone logs in.
    /// </summary>
    public static class Music
    {
        const string PrefKey = "foh_music";
        const string Track = "Audio/music_farm";
        const float Volume = 0.45f;

        static AudioSource source;

        public static bool Available => source != null && source.clip != null;

        public static bool Enabled
        {
            get => PlayerPrefs.GetInt(PrefKey, 1) == 1;
            set
            {
                PlayerPrefs.SetInt(PrefKey, value ? 1 : 0);
                PlayerPrefs.Save();
                Apply();
            }
        }

        public static void Init(MonoBehaviour host)
        {
            var clip = Resources.Load<AudioClip>(Track);
            if (clip == null) return;
            source = host.gameObject.AddComponent<AudioSource>();
            source.clip = clip;
            source.loop = true;
            source.playOnAwake = false;
            source.volume = Volume;
            Apply();
        }

        static void Apply()
        {
            if (!Available) return;
            if (Enabled && !source.isPlaying) source.Play();
            else if (!Enabled && source.isPlaying) source.Pause();
        }
    }
}
