using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace FieldsOfHope
{
    /// <summary>
    /// Life on the farm map, all in world space so it pans with the farm:
    /// daylight that follows the in-game clock (dawn, dusk, moonlit night), fireflies after dark, chimney smoke, flocks of
    /// birds, butterflies over the flower bushes and leaves drifting down from the trees. At night every house has a lamp
    /// by its door; its windows glow while someone inside is awake and go dim when they are all asleep, and zzz rise from
    /// the houses where people sleep. On campfire evenings the fire burns, glows on the people round it and throws sparks.
    /// Sprites are drawn in code; nothing here touches game state.
    /// </summary>
    public class Ambience
    {
        readonly FarmScreen farm;
        readonly RectTransform life, lights;
        readonly Image daylight;
        readonly List<Image> otherWindows = new List<Image>();   // the store's: lit in the evening only
        readonly List<House> houses = new List<House>();
        Image fireGlow, fireCore, flame;
        Vector2 firePos;
        float nextSpark, nextFireSmoke, nextFlame;
        int flameFrame;
        readonly List<Mover> movers = new List<Mover>();
        readonly System.Random rnd = new System.Random();
        float nextSmoke, nextBirds = 3f, nextLeaf, night;

        static Sprite dot, birdUp, birdDown, flyOpen, flyShut, zBig, zSmall, lanternSprite;
        static Sprite[] flames;

        /// <summary>A house with a door people live behind: its windows, door lamp, the light on its doorstep, where zzz rise.</summary>
        class House
        {
            public MapSpot door;
            public readonly List<Image> windows = new List<Image>();
            public Image lamp, lampCore, pool, lantern;
            public Vector2 zzzAt;
            public float lit, nextZ;
        }

        // places on the map, from the location's layout (map px)
        readonly Vector2[] chimneys, treeTops;
        public float Night => night;

        static Vector2[] Points(MapPoint[] p)
        {
            if (p == null) return new Vector2[0];
            var v = new Vector2[p.Length];
            for (int i = 0; i < p.Length; i++) v[i] = p[i].V;
            return v;
        }

        class Mover
        {
            public RectTransform rt; public Image img;
            public Vector2 pos, vel, origin;
            public float born, life, phase, spin, size;
            public Action<Mover, float> step;
        }

        public Ambience(FarmScreen farm, MapLayout map)
        {
            this.farm = farm;
            chimneys = Points(map.chimneys);
            treeTops = Points(map.treeTops);
            MakeSprites();
            // below the plot labels and map markers so those stay readable at night
            // speech bubbles stay readable at night too: the night goes over the map but under them
            int at = (farm.World.Find("Emotes") ?? farm.World.Find("PlotLabels")).GetSiblingIndex();
            daylight = UI.Rect(farm.World, Color.clear, "Daylight");
            daylight.rectTransform.Fill();
            daylight.raycastTarget = false;
            lights = UI.New("Lights", farm.World).Fill();
            life = UI.New("Life", farm.World).Fill();
            daylight.transform.SetSiblingIndex(at);
            lights.SetSiblingIndex(at + 1);
            life.SetSiblingIndex(at + 2);
            BuildHouses(map);
            BuildCampfire(map);
            foreach (var f in Points(map.flowers)) Butterfly(f);
            foreach (var f in Points(map.fireflies)) for (int i = 0; i < 3; i++) Firefly(f);
        }

        /// <summary>Removes everything this ambience added (used when the player travels to another location).</summary>
        public void Destroy()
        {
            UnityEngine.Object.Destroy(daylight.gameObject);
            UnityEngine.Object.Destroy(lights.gameObject);
            UnityEngine.Object.Destroy(life.gameObject);
        }

        // ------------------------------------------------------------------ per frame
        public void Tick()
        {
            float now = Time.unscaledTime, dt = Mathf.Min(Time.unscaledDeltaTime, 0.1f);
            UpdateDaylight();
            UpdateHouses(now, dt);
            UpdateCampfire(now);

            if (now >= nextSmoke) { nextSmoke = now + 0.55f; foreach (var c in chimneys) Smoke(c); }
            if (now >= nextBirds) { nextBirds = now + 7f + (float)rnd.NextDouble() * 9f; if (night < 0.4f) Flock(); }
            if (now >= nextLeaf && treeTops.Length > 0) { nextLeaf = now + 0.7f + (float)rnd.NextDouble() * 1.2f; Leaf(); }

            for (int i = movers.Count - 1; i >= 0; i--)
            {
                var m = movers[i];
                if (m.rt == null) { movers.RemoveAt(i); continue; }
                float age = now - m.born;
                if (m.life > 0 && age > m.life) { UnityEngine.Object.Destroy(m.rt.gameObject); movers.RemoveAt(i); continue; }
                m.step(m, dt);
            }
        }

        void UpdateDaylight()
        {
            var t = GameApp.I.Server.LocalTime;
            float h = t.Hour + t.Minute / 60f;
            // (hour, colour) keyframes: deep blue night, pink dawn, clear day, golden dusk
            var dark = new Color(0.02f, 0.04f, 0.17f, 0.6f);
            var dawn = new Color(1f, 0.55f, 0.45f, 0.16f);
            var day = new Color(1f, 1f, 1f, 0f);
            var dusk = new Color(0.85f, 0.42f, 0.2f, 0.26f);
            (float h, Color c)[] keys = { (0, dark), (4.5f, dark), (6, dawn), (7.5f, day), (16.5f, day), (18, dusk), (19.5f, dark), (24, dark) };
            Color col = dark;
            for (int i = 0; i < keys.Length - 1; i++)
                if (h >= keys[i].h && h <= keys[i + 1].h) { col = Color.Lerp(keys[i].c, keys[i + 1].c, Mathf.InverseLerp(keys[i].h, keys[i + 1].h, h)); break; }
            daylight.color = col;
            // how dark it is (0 day .. 1 night) drives window glows and fireflies: lamps go on at dusk, off after dawn
            night = h < 12f ? 1f - Mathf.InverseLerp(4.5f, 6.5f, h) : Mathf.InverseLerp(17.5f, 19.5f, h);
            bool evening = h >= 17f && h < 21f;
            foreach (var g in otherWindows)
                g.color = new Color(1f, 0.78f, 0.38f, (evening ? night : 0f) * (0.55f + 0.08f * Mathf.Sin(Time.unscaledTime * 3f + g.rectTransform.anchoredPosition.x)));
        }

        // ------------------------------------------------------------------ houses at night
        void BuildHouses(MapLayout map)
        {
            var windows = new List<Vector2>(Points(map.windows));
            var lamps = new List<Vector2>(Points(map.lamps));
            if (map.spots != null)
                foreach (var door in map.spots)
                {
                    if (door == null || door.kind != "door" || door.entry == null || door.entry.Length == 0) continue;
                    var house = new House { door = door, nextZ = Time.unscaledTime + R(0f, 2f) };
                    var o = HouseOf(map, door);
                    // the windows on this house, and the zzz rising from the first of them (or from under the roof)
                    if (o != null)
                    {
                        foreach (var w in windows.ToArray())
                            if (Mathf.Abs(w.x - o.x) <= o.w / 2f && w.y <= o.y && w.y >= o.y - o.h) { house.windows.Add(Glow(w, 48)); windows.Remove(w); }
                        house.zzzAt = house.windows.Count > 0 ? farm.WorldToBg(house.windows[0].rectTransform.anchoredPosition) + new Vector2(6, -12)
                                                              : new Vector2(o.x, o.y - o.h * 0.55f);
                    }
                    else house.zzzAt = door.V + new Vector2(0, -70);
                    // the lantern on the wall beside the door (Tools/map_builder.py places it beside the doorway, never in it);
                    // its light falls on the doorstep
                    Vector2 lamp = default; bool found = false;
                    if (o != null)
                        foreach (var l in lamps)
                            if (Mathf.Abs(l.x - o.x) <= o.w / 2f && l.y <= o.y && l.y >= o.y - o.h) { lamp = l; found = true; break; }
                    if (!found) { var inside = door.entry[door.entry.Length - 1].V; lamp = new Vector2(inside.x + 14f, inside.y - 34f); }
                    house.lamp = Glow(lamp, 60);
                    house.lampCore = Glow(lamp, 12);
                    house.lantern = UI.Img(lights, null, Color.white, true, "Lantern");
                    house.lantern.sprite = lanternSprite;
                    house.lantern.raycastTarget = false;
                    house.lantern.rectTransform.At(0.5f, 0.5f, 0, 0, 8f * farm.Scale, 11f * farm.Scale);
                    house.lantern.rectTransform.anchoredPosition = farm.BgToWorld(lamp.x, lamp.y - 1f);
                    house.pool = Glow(door.V, 90);
                    house.pool.rectTransform.sizeDelta = new Vector2(90, 34) * farm.Scale;
                    houses.Add(house);
                }
            foreach (var w in windows) otherWindows.Add(Glow(w, 48));
        }

        /// <summary>The house a door belongs to: door spots are named after their house and its count ("farmhouse_0").</summary>
        static MapObject HouseOf(MapLayout map, MapSpot door)
        {
            int cut = door.name?.LastIndexOf('_') ?? -1;
            if (cut < 0 || map.objects == null || !int.TryParse(door.name.Substring(cut + 1), out int k)) return null;
            string kind = door.name.Substring(0, cut);
            foreach (var o in map.objects) if (o.s == kind && k-- == 0) return o;
            return null;
        }

        Image Glow(Vector2 at, float size)
        {
            var g = Sprite(lights, dot, new Color(1f, 0.78f, 0.38f, 0f), size * farm.Scale);
            g.rectTransform.anchoredPosition = farm.BgToWorld(at.x, at.y);
            return g;
        }

        void UpdateHouses(float now, float dt)
        {
            var indoors = farm.Map?.Indoors;
            float flicker = 0.92f + 0.08f * Mathf.Sin(now * 7f) * Mathf.Sin(now * 2.3f);
            foreach (var house in houses)
            {
                (int awake, int asleep) n = default;
                indoors?.TryGetValue(house.door, out n);
                // lights on while anyone inside is up, a faint glow once they are all asleep, dark in an empty house
                float target = n.awake > 0 ? 1f : n.asleep > 0 ? 0.12f : 0f;
                house.lit = Mathf.MoveTowards(house.lit, target, dt * 1.5f);
                foreach (var w in house.windows)
                    w.color = new Color(1f, 0.78f, 0.38f, night * house.lit * (0.62f + 0.08f * Mathf.Sin(now * 3f + w.rectTransform.anchoredPosition.x)));
                house.pool.color = new Color(1f, 0.74f, 0.36f, night * house.lit * 0.26f);
                // the door lamp burns from dusk to dawn
                float lamp = Mathf.InverseLerp(0.25f, 0.7f, night);
                house.lamp.color = new Color(1f, 0.7f, 0.32f, lamp * 0.55f * flicker);
                house.lampCore.color = new Color(1f, 0.93f, 0.7f, lamp * 0.8f);
                // by day an unlit lantern (shaded like the wall), at night a bright one
                float dim = Mathf.Lerp(0.62f, 1f, lamp);
                house.lantern.color = new Color(dim, dim * Mathf.Lerp(0.95f, 1f, lamp), dim * Mathf.Lerp(0.9f, 0.95f, lamp));
                if (n.asleep > 0 && night > 0.3f && now >= house.nextZ)
                {
                    house.nextZ = now + R(1.5f, 2.6f) / Mathf.Min(2f, 1f + 0.25f * (n.asleep - 1));
                    Zzz(house.zzzAt);
                }
            }
        }

        /// <summary>A Z drifting up from a sleeping house, swaying, growing and fading.</summary>
        void Zzz(Vector2 from)
        {
            bool big = rnd.NextDouble() < 0.5;
            var img = Sprite(life, big ? zBig : zSmall, new Color(1, 1, 1, 0), (big ? 21f : 15f) * farm.Scale);
            float sway = R(0f, 6.28f);
            Add(img, farm.BgToWorld(from.x + R(-6, 6), from.y), 3.2f, (s, dt) =>
            {
                float a = (Time.unscaledTime - s.born) / s.life;
                s.pos += new Vector2(6f + 10f * Mathf.Sin(a * 5f + sway), 19f) * farm.Scale * dt;
                s.rt.anchoredPosition = s.pos;
                s.rt.localScale = Vector3.one * Mathf.Lerp(0.6f, 1.25f, a);
                s.img.color = new Color(1, 1, 1, 0.95f * Mathf.Clamp01(Mathf.Min(a / 0.15f, (1f - a) / 0.35f)));
            });
        }

        // ------------------------------------------------------------------ the campfire
        void BuildCampfire(MapLayout map)
        {
            if (map.spots == null) return;
            foreach (var spot in map.spots)
                if (spot != null && spot.kind == "campfire") { firePos = spot.V; break; }
            if (firePos == Vector2.zero) return;
            // the warm light round the fire, a hot core, and the flames (drawn above the night, so they burn bright)
            fireGlow = Sprite(lights, dot, new Color(1f, 0.55f, 0.2f, 0f), 1f);
            fireGlow.rectTransform.sizeDelta = new Vector2(330, 190) * farm.Scale;
            fireGlow.rectTransform.anchoredPosition = farm.BgToWorld(firePos.x, firePos.y - 6);
            fireCore = Sprite(lights, dot, new Color(1f, 0.8f, 0.45f, 0f), 1f);
            fireCore.rectTransform.sizeDelta = new Vector2(110, 70) * farm.Scale;
            fireCore.rectTransform.anchoredPosition = farm.BgToWorld(firePos.x, firePos.y - 10);
            flame = UI.Img(lights, null, Color.white, true, "Flame");
            flame.raycastTarget = false;
            flame.sprite = flames[0];
            flame.rectTransform.At(0.5f, 0.5f, 0, 0, 24 * farm.Scale, 32 * farm.Scale, 0.5f, 0f);
            flame.rectTransform.anchoredPosition = farm.BgToWorld(firePos.x, firePos.y + 2);
        }

        void UpdateCampfire(float now)
        {
            if (flame == null) return;
            var t = farm.VillageClock;
            float fire = t.Fire;
            float flick = 0.85f + 0.15f * Mathf.PerlinNoise(now * 3.1f, 0.3f) + 0.06f * Mathf.Sin(now * 17f);
            float dark = Mathf.Max(0.45f, night);
            fireGlow.color = new Color(1f, 0.55f, 0.2f, fire * 0.42f * flick * dark);
            fireCore.color = new Color(1f, 0.82f, 0.45f, fire * 0.55f * flick);
            flame.enabled = fire > 0.01f;
            if (!flame.enabled)
            {
                // the last wisps of smoke after the fire goes out
                if (t.campfireNight && !t.rain && t.hour >= Routine.FireOut && t.hour < Routine.FireOut + 0.3f && now >= nextFireSmoke)
                { nextFireSmoke = now + 0.9f; Smoke(firePos + new Vector2(0, -10)); }
                return;
            }
            if (now >= nextFlame) { nextFlame = now + R(0.08f, 0.14f); flameFrame = (flameFrame + 1 + rnd.Next(2)) % flames.Length; flame.sprite = flames[flameFrame]; }
            float k = Mathf.Lerp(0.35f, 1f, fire);
            flame.rectTransform.localScale = new Vector3(k * (0.95f + 0.08f * Mathf.Sin(now * 11f)), k * flick, 1f);
            flame.color = Color.Lerp(new Color(1f, 0.45f, 0.3f), Color.white, fire);       // dying down: deep red embers
            if (fire > 0.5f && now >= nextSpark) { nextSpark = now + R(0.12f, 0.35f); Spark(); }
            if (fire < 0.6f && now >= nextFireSmoke) { nextFireSmoke = now + 0.8f; Smoke(firePos + new Vector2(0, -16)); }
        }

        void Spark()
        {
            var img = Sprite(life, dot, new Color(1f, 0.7f, 0.25f, 1f), R(4f, 7f) * farm.Scale);
            float drift = R(-14f, 14f), rise = R(38f, 64f), wob = R(0f, 6.28f);
            Add(img, farm.BgToWorld(firePos.x + R(-6, 6), firePos.y - R(8, 16)), R(0.9f, 1.6f), (s, dt) =>
            {
                float a = (Time.unscaledTime - s.born) / s.life;
                s.pos += new Vector2(drift + 10f * Mathf.Sin(a * 9f + wob), rise) * farm.Scale * dt;
                s.rt.anchoredPosition = s.pos;
                s.img.color = new Color(1f, Mathf.Lerp(0.85f, 0.35f, a), 0.25f, 1f - a);
            });
        }

        // ------------------------------------------------------------------ actors
        Image Sprite(RectTransform parent, Sprite s, Color c, float size)
        {
            var img = UI.Img(parent, null, c, true, "Life");
            img.sprite = s;
            img.rectTransform.At(0.5f, 0.5f, 0, 0, size, size);
            img.raycastTarget = false;
            return img;
        }

        Mover Add(Image img, Vector2 pos, float life, Action<Mover, float> step)
        {
            var m = new Mover { rt = img.rectTransform, img = img, pos = pos, origin = pos, born = Time.unscaledTime, life = life,
                                phase = (float)rnd.NextDouble() * 6.28f, step = step };
            img.rectTransform.anchoredPosition = pos;
            movers.Add(m);
            return m;
        }

        float R(float a, float b) => a + (float)rnd.NextDouble() * (b - a);

        void Smoke(Vector2 chimney)
        {
            var img = Sprite(life, dot, new Color(0.92f, 0.92f, 0.95f, 0f), 34);
            var m = Add(img, farm.BgToWorld(chimney.x, chimney.y), 3.6f, (s, dt) =>
            {
                float a = (Time.unscaledTime - s.born) / s.life;
                s.pos += new Vector2(14f + 8f * Mathf.Sin(a * 6f + s.phase), 34f) * dt;
                s.rt.anchoredPosition = s.pos;
                s.rt.localScale = Vector3.one * Mathf.Lerp(0.5f, 2.2f, a);
                s.img.color = new Color(0.92f, 0.92f, 0.95f, 0.42f * Mathf.Sin(Mathf.Clamp01(a) * Mathf.PI) * (1f - a * 0.4f));
            });
        }

        void Flock()
        {
            var size = farm.World.rect.size;
            bool rightward = rnd.Next(2) == 0;
            float y = R(-0.1f, 0.42f) * size.y, x0 = (rightward ? -0.5f : 0.5f) * size.x - (rightward ? 60 : -60);
            int n = rnd.Next(2, 5);
            for (int i = 0; i < n; i++)
            {
                var img = Sprite(life, birdUp, new Color(0.16f, 0.17f, 0.22f, 0.95f), 36);
                img.rectTransform.sizeDelta = new Vector2(44, 20);
                if (!rightward) img.rectTransform.localScale = new Vector3(-1, 1, 1);
                float speed = R(150f, 190f);
                var start = new Vector2(x0 - (rightward ? 1 : -1) * i * R(40, 70), y + (i % 2 == 0 ? 1 : -1) * i * R(14, 26));
                Add(img, start, size.x / speed + 3f, (s, dt) =>
                {
                    s.pos += new Vector2(rightward ? speed : -speed, 0) * dt;
                    float t = Time.unscaledTime * 9f + s.phase;
                    s.rt.anchoredPosition = s.pos + new Vector2(0, Mathf.Sin(t * 0.18f) * 10f);
                    s.img.sprite = Mathf.Sin(t) > 0 ? birdUp : birdDown;
                });
            }
        }

        void Butterfly(Vector2 flowers)
        {
            var colors = new[] { new Color(1f, 1f, 0.95f), new Color(1f, 0.85f, 0.3f), new Color(1f, 0.6f, 0.25f), new Color(0.6f, 0.8f, 1f) };
            var img = Sprite(life, flyOpen, colors[rnd.Next(colors.Length)], 22);
            float rx = R(30, 55), ry = R(18, 30), sp = R(0.5f, 0.9f);
            Add(img, farm.BgToWorld(flowers.x, flowers.y) + new Vector2(0, 30), 0f, (s, dt) =>
            {
                float t = Time.unscaledTime * sp + s.phase;
                s.rt.anchoredPosition = s.origin + new Vector2(Mathf.Sin(t) * rx, Mathf.Sin(t * 1.7f) * ry + Mathf.Abs(Mathf.Sin(t * 9f)) * 6f);
                s.img.sprite = Mathf.Sin(Time.unscaledTime * 22f + s.phase) > 0 ? flyOpen : flyShut;
                s.rt.localScale = new Vector3(Mathf.Cos(t) > 0 ? 1 : -1, 1, 1);
                s.img.enabled = night < 0.6f;   // butterflies rest at night
            });
        }

        void Leaf()
        {
            var top = treeTops[rnd.Next(treeTops.Length)];
            var colors = new[] { new Color(0.45f, 0.7f, 0.25f), new Color(0.75f, 0.75f, 0.25f), new Color(0.9f, 0.6f, 0.2f) };
            var img = UI.Rect(life, colors[rnd.Next(colors.Length)], "Leaf");
            img.raycastTarget = false;
            img.rectTransform.At(0.5f, 0.5f, 0, 0, 10, 6);
            float drift = R(-25, 25);
            Add(img, farm.BgToWorld(top.x + R(-30, 30), top.y + R(0, 30)), 4.5f, (s, dt) =>
            {
                float a = Time.unscaledTime - s.born;
                s.pos += new Vector2(drift + Mathf.Sin(a * 2.2f + s.phase) * 40f, -38f) * dt;
                s.rt.anchoredPosition = s.pos;
                s.rt.localRotation = Quaternion.Euler(0, 0, Mathf.Sin(a * 3f + s.phase) * 60f);
                var c = s.img.color; c.a = Mathf.Clamp01(Mathf.Min(a / 0.4f, (s.life - a) / 0.8f)); s.img.color = c;
            });
        }

        void Firefly(Vector2 spot)
        {
            var img = Sprite(lights, dot, new Color(1f, 0.95f, 0.45f, 0f), 18);
            float rx = R(30, 80), ry = R(20, 50), sp = R(0.25f, 0.5f);
            Add(img, farm.BgToWorld(spot.x + R(-30, 30), spot.y + R(-20, 20)), 0f, (s, dt) =>
            {
                float t = Time.unscaledTime * sp + s.phase;
                s.rt.anchoredPosition = s.origin + new Vector2(Mathf.Sin(t) * rx + Mathf.Sin(t * 2.3f) * 10f, Mathf.Cos(t * 1.3f) * ry);
                float blink = Mathf.Max(0, Mathf.Sin(Time.unscaledTime * 1.6f + s.phase * 3f));
                s.img.color = new Color(1f, 0.95f, 0.45f, night * blink);
            });
        }

        // ------------------------------------------------------------------ sprites drawn in code
        static void MakeSprites()
        {
            if (dot != null) return;
            const int n = 32;
            var tex = new Texture2D(n, n, TextureFormat.RGBA32, false) { wrapMode = TextureWrapMode.Clamp, filterMode = FilterMode.Bilinear };
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(n / 2f, n / 2f)) / (n / 2f);
                    tex.SetPixel(x, y, new Color(1, 1, 1, Mathf.Pow(Mathf.Clamp01(1f - d), 1.8f)));
                }
            tex.Apply();
            dot = UnityEngine.Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100);
            birdUp = Pixels("X.........X", ".X.......X.", "..XX...XX..", "....XXX....");
            birdDown = Pixels("....XXX....", "..XX...XX..", ".X.......X.", "...........");
            flyOpen = Pixels("XX.XX", "XXXXX", ".XXX.", "XX.XX");
            flyShut = Pixels(".X.X.", ".XXX.", "..X..", ".X.X.");
            zBig = Glyph("XXXXXX", "....XX", "...XX.", "..XX..", ".XX...", "XXXXXX");
            lanternSprite = Paint(new Dictionary<char, Color>
                {
                    { 'k', new Color(0.21f, 0.14f, 0.09f) }, { 'm', new Color(0.42f, 0.3f, 0.18f) },
                    { 'y', new Color(1f, 0.78f, 0.35f) }, { 'Y', new Color(1f, 0.95f, 0.72f) },
                },
                "..kk..", ".kmmk.", "kkkkkk", "kyyyyk", "kyYYyk", "kyYYyk", "kyyyyk", "kkkkkk", ".kmmk.");
            zSmall = Glyph("XXXX", "..XX", ".XX.", "XXXX");
            flames = new Sprite[4];
            for (int f = 0; f < flames.Length; f++) flames[f] = Flame(f);
        }

        /// <summary>A tiny pixel-art sprite in several colours, from text rows ('.' = clear).</summary>
        static Sprite Paint(Dictionary<char, Color> colours, params string[] rows)
        {
            int h = rows.Length, w = rows[0].Length;
            var tex = new Texture2D(w, h, TextureFormat.RGBA32, false) { filterMode = FilterMode.Point, wrapMode = TextureWrapMode.Clamp };
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    tex.SetPixel(x, h - 1 - y, colours.TryGetValue(rows[y][x], out var c) ? c : Color.clear);
            tex.Apply();
            return UnityEngine.Sprite.Create(tex, new Rect(0, 0, w, h), new Vector2(0.5f, 0.5f), 100);
        }

        /// <summary>A pale letter with a dark outline (the zzz over sleeping houses).</summary>
        static Sprite Glyph(params string[] rows)
        {
            int h = rows.Length, w = rows[0].Length, W = w + 2, H = h + 2;
            bool On(int x, int y) => x >= 1 && y >= 1 && x <= w && y <= h && rows[y - 1][x - 1] == 'X';
            var tex = new Texture2D(W, H, TextureFormat.RGBA32, false) { filterMode = FilterMode.Point, wrapMode = TextureWrapMode.Clamp };
            var fill = new Color(0.92f, 0.95f, 1f); var edge = new Color(0.12f, 0.14f, 0.3f);
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++)
                {
                    bool near = false;
                    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) near |= On(x + dx, y + dy);
                    tex.SetPixel(x, H - 1 - y, On(x, y) ? fill : near ? edge : Color.clear);
                }
            tex.Apply();
            return UnityEngine.Sprite.Create(tex, new Rect(0, 0, W, H), new Vector2(0.5f, 0.5f), 100);
        }

        /// <summary>One frame of a pixel-art flame: a swaying tongue, white-hot at the heart, yellow, orange, red at the edges.</summary>
        static Sprite Flame(int f)
        {
            const int W = 11, H = 15;
            var tex = new Texture2D(W, H, TextureFormat.RGBA32, false) { filterMode = FilterMode.Point, wrapMode = TextureWrapMode.Clamp };
            float phase = f * Mathf.PI / 2f;
            var red = new Color(0.85f, 0.22f, 0.08f); var orange = new Color(1f, 0.52f, 0.1f); var yellow = new Color(1f, 0.84f, 0.28f); var hot = new Color(1f, 0.97f, 0.78f);
            for (int y = 0; y < H; y++)
            {
                float v = y / (H - 1f);                                       // 0 at the base, 1 at the tip
                float half = 5.2f * Mathf.Pow(1f - v, 0.8f) * (0.8f + 0.2f * Mathf.Sin(v * 3f + phase));
                float sway = Mathf.Sin(v * 4f + phase) * 1.4f * v;
                float top = 0.86f + 0.12f * Mathf.Sin(phase * 1.5f + 0.5f);
                for (int x = 0; x < W; x++)
                {
                    float d = Mathf.Abs(x - (W - 1) / 2f - sway) / Mathf.Max(0.3f, half);
                    var c = Color.clear;
                    if (d <= 1f && v <= top)
                    {
                        float heat = (1f - d) * (1f - v * 0.85f);
                        c = heat > 0.6f ? hot : heat > 0.38f ? yellow : heat > 0.17f ? orange : red;
                    }
                    tex.SetPixel(x, y, c);
                }
            }
            tex.Apply();
            return UnityEngine.Sprite.Create(tex, new Rect(0, 0, W, H), new Vector2(0.5f, 0f), 100);
        }

        /// <summary>A tiny white pixel-art sprite from text rows ('X' = filled); tinted by the Image colour.</summary>
        static Sprite Pixels(params string[] rows)
        {
            int h = rows.Length, w = rows[0].Length;
            var tex = new Texture2D(w, h, TextureFormat.RGBA32, false) { filterMode = FilterMode.Point, wrapMode = TextureWrapMode.Clamp };
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    tex.SetPixel(x, h - 1 - y, rows[y][x] == 'X' ? Color.white : Color.clear);
            tex.Apply();
            return UnityEngine.Sprite.Create(tex, new Rect(0, 0, w, h), new Vector2(0.5f, 0.5f), 100);
        }
    }
}
