using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Want = FieldsOfHope.Routine.Want;

namespace FieldsOfHope
{
    /// <summary>What time it is in the village, for everyone's routine.</summary>
    public struct VillageTime
    {
        public float hour;        // local game time, 0-24
        public float night;       // 0 = day, 1 = full night (Ambience)
        public bool rain;
        public int day;           // local day number, for each person's routine that day (Routine)
        public bool campfireNight;
        public int rainKey;       // which shower this is: each one, different people brave it
        public bool Lunch => hour >= 11.5f && hour < 13f;
        public bool Dark => night > 0.55f;
        public bool LateNight => hour >= 22f || hour < 5f;
        public float Fire => Routine.Fire(hour, campfireNight, rain);
    }

    /// <summary>
    /// The farm's villagers as animated characters, placed by each location's map layout. Each has one action strip
    /// (Resources/Art/act_{name}.png, square frames made by Tools/slice_work.py; frame 0 is their resting pose) for their
    /// place in the village, and walk cycles (walk_{name}_se/_ne.png) to get about. By day field workers go from plant
    /// to plant in their patch, and people standing or sitting together hold a conversation. At dusk everyone walks home
    /// and goes in through the door, and they come out again in the morning (Routine). On campfire evenings some
    /// gather round the fire. In the rain most go indoors and a few stay out. Nobody fades: they walk everywhere.
    /// </summary>
    public class Villagers
    {
        const float Figure = 0.7f;            // share of each frame the body fills (Tools/slice_work.py)
        const float Feet = 4f / 160f;         // feet sit this far above the bottom of a frame
        const float GroupRadius = 120f;       // map px: people this close talk together
        const float Amble = 15f;              // map px per second between plants

        // children (they stay up less late, and love the rain)
        public static readonly HashSet<string> Kids = new HashSet<string> { "crate_kid", "barn_boy", "barn_back", "feast_tray", "boy" };
        // standing height (map px) of the people who sit in their scene; everyone else walks as tall as they stand
        static readonly Dictionary<string, float> Standing = new Dictionary<string, float>
        {
            { "feast_grey", 62 }, { "feast_top", 58 }, { "feast_brown", 60 }, { "feast_red", 64 }, { "bench_sitter", 60 }, { "feast_back", 64 },
        };
        static readonly HashSet<string> Elderly = new HashSet<string> { "feast_grey", "feast_top", "path_lady", "barn_basket", "barn_lola", "road_lady" };

        public enum Pace { Work, Chat }
        enum Mode { Work, Break, Speak, Listen, Idle, Walk, Inside, Camp, Shelter, Play }

        class Villager
        {
            public string name;
            public Image img, hit;
            public Sprite[] frames;
            public Pace pace;
            public Vector2 pos;                   // their place in the village (feet, map px)
            public float head, baseX = 1f;
            public int frame;
            public float next, until, emoteAt = -1f;
            public string emote;
            public Mode mode;
            public Group group;
            public bool lookingAway, wasRain;
            public bool owl, kid;
            // everyone with walk cycles
            public Body body;
            public float poseScale, speed;
            public float? seatDepth;              // draw order while in their place (a guest at the table)
            public List<Vector2> patch;           // field workers: the plants they tend
            public int spot;
            public readonly List<Vector2> route = new List<Vector2>();
            public System.Action arrive;
            public MapSpot door, home;            // the house they are in (or going into), and their own
            public Want? at = Want.Out;           // where they are (null while on the way)
            public Want goal = Want.Out;          // where they are going
            public bool doorway;                  // stepping through a door: they finish that first
            public bool placed;                   // put where the time of day wants them, on the first tick
            public int seat = -1;                 // at the campfire
            public bool Worker => patch != null;
        }

        class Group
        {
            public readonly List<Villager> members = new List<Villager>();
            public Villager speaker;
            public float pauseUntil, until;
            public bool started;
        }

        readonly List<Villager> villagers = new List<Villager>();
        readonly List<Group> groups = new List<Group>();
        readonly Emotes emotes;
        readonly VillagePaths paths;
        readonly Campfire fire;
        readonly System.Random rnd = new System.Random();
        float Rand(float a, float b) => a + (float)rnd.NextDouble() * (b - a);

        /// <param name="layer">the map's depth-sorted layer, so villagers stand behind what is in front of them</param>
        /// <param name="cast">who stands where, from the location's map layout (Tools/map_builder.py)</param>
        public Villagers(FarmScreen farm, RectTransform layer, MapVillager[] cast, Emotes emotes, VillagePaths paths, Campfire fire)
        {
            this.emotes = emotes; this.paths = paths; this.fire = fire;
            if (cast == null) return;
            float now = Time.unscaledTime;
            foreach (var c in cast)
            {
                var frames = Frames("act_" + c.name);
                if (frames == null) continue;   // art not in this build: nothing breaks
                var v = new Villager
                {
                    name = c.name, frames = frames, pace = c.pace == "Work" ? Pace.Work : Pace.Chat, pos = new Vector2(c.x, c.y),
                    head = c.height + 2f, frame = rnd.Next(frames.Length), next = now + Rand(0f, 1f),
                    mode = c.pace == "Work" ? Mode.Work : Mode.Idle, baseX = c.flip ? -1f : 1f,
                    owl = c.nightOwl, kid = Kids.Contains(c.name), speed = Kids.Contains(c.name) ? 26f : Elderly.Contains(c.name) ? 16f : 21f,
                };
                float size = c.height / Figure * farm.Scale;
                // the walk frames' size against the work frames: field workers' from the layout, the others' from how tall they stand
                float walkScale = c.walk != null && c.walk.Length >= 2 ? c.walkScale : (Standing.TryGetValue(c.name, out var stand) ? stand : c.height) / c.height;
                var body = new Body(farm, layer, c.name, c.height / Body.Height * walkScale);
                if (body.Ok)
                {
                    v.body = body; v.img = body.img;
                    v.poseScale = 0.84f / (Figure * walkScale);        // work frame size against a walk frame
                    v.seatDepth = c.depth > 0 ? c.depth : (float?)null;
                    if (c.walk != null && c.walk.Length >= 2)
                    {
                        v.patch = new List<Vector2>();
                        foreach (var p in c.walk) v.patch.Add(p.V);
                        v.spot = 0;
                        body.at = v.patch[0];
                    }
                    else { body.at = v.pos; body.behind = v.seatDepth; }
                    v.home = NearestDoor(v.patch != null ? v.patch[0] : v.pos);
                    Pose(v);
                }
                else
                {
                    Object.Destroy(body.img.gameObject);
                    var img = UI.Img(layer, null, Color.white, true, "Villager " + c.name);
                    img.raycastTarget = false;
                    img.rectTransform.At(0.5f, 0.5f, 0, 0, size, size, 0.5f, Feet);
                    img.rectTransform.anchoredPosition = farm.BgToWorld(c.x, c.y);
                    img.rectTransform.localScale = new Vector3(v.baseX, 1, 1);
                    img.gameObject.AddComponent<DepthKey>().y = c.depth > 0 ? c.depth : c.y;
                    img.sprite = frames[v.frame];
                    v.img = img;
                }
                // tapping a villager starts a conversation; the hit area is the figure, not its whole frame
                var hit = UI.Rect(v.img.transform, new Color(0, 0, 0, 0), "Tap");
                hit.rectTransform.anchorMin = hit.rectTransform.anchorMax = new Vector2(0.5f, Feet);
                hit.rectTransform.pivot = new Vector2(0.5f, 0f);
                hit.rectTransform.sizeDelta = new Vector2(size * 0.42f, size * Figure);
                hit.rectTransform.anchoredPosition = Vector2.zero;
                hit.Clickable(farm.Talk);
                v.hit = hit;
                v.until = now + (v.pace == Pace.Work ? Rand(2f, 12f) : Rand(1f, 8f));   // everyone out of step from the start
                villagers.Add(v);
            }
            FormGroups();
        }

        /// <summary>People who chat and stand close together share one conversation.</summary>
        void FormGroups()
        {
            var talkers = villagers.FindAll(v => v.pace == Pace.Chat);
            foreach (var v in talkers)
            {
                if (v.group != null) continue;
                var g = new Group();
                var open = new Stack<Villager>(); open.Push(v); v.group = g;
                while (open.Count > 0)
                {
                    var a = open.Pop(); g.members.Add(a);
                    foreach (var b in talkers)
                        if (b.group == null && Vector2.Distance(a.pos, b.pos) < GroupRadius) { b.group = g; open.Push(b); }
                }
                if (g.members.Count > 1)
                {
                    g.speaker = g.members[rnd.Next(g.members.Count)];
                    g.pauseUntil = Time.unscaledTime + Rand(0f, 2f);
                    g.until = g.pauseUntil + Rand(2.5f, 5f);
                    groups.Add(g);
                }
                else v.group = null;
            }
        }

        static Sprite[] Frames(string name)
        {
            var strip = UI.S(name);
            if (strip == null) return null;
            var tex = strip.texture;
            int h = tex.height, n = Mathf.Max(1, tex.width / h);
            var frames = new Sprite[n];
            for (int i = 0; i < n; i++)
                frames[i] = Sprite.Create(tex, new Rect(i * h, 0, h, h), new Vector2(0.5f, Feet), 100);
            return frames;
        }

        MapSpot NearestDoor(Vector2 at)
        {
            MapSpot door = null; float d = float.MaxValue;
            foreach (var s in paths.Spots)
                if (s.kind == "door" && s.entry != null && s.entry.Length > 0) { float e = Vector2.Distance(s.V, at); if (e < d) { d = e; door = s; } }
            return door;
        }

        /// <summary>In their place, in their own pose (not walking, not away).</summary>
        static bool Present(Villager v) => v.at == Want.Out && v.mode != Mode.Walk;

        float HeadOf(Villager v) => v.body == null || Present(v) ? v.head : v.body.head;

        /// <summary>A passer-by within <paramref name="radius"/> map px says hello; the nearest villager answers a moment later.</summary>
        public bool Greet(Vector2 at, float radius, out Vector2 where)
        {
            where = at;
            Villager best = null; float d = radius;
            foreach (var v in villagers)
            {
                if (!Present(v)) continue;
                float e = Vector2.Distance(Where(v), at);
                if (e < d && v.emoteAt < 0 && !emotes.Showing(v.img)) { d = e; best = v; }
            }
            if (best == null) return false;
            best.emote = rnd.NextDouble() < 0.5 ? "wave" : rnd.NextDouble() < 0.5 ? "note" : "heart";
            best.emoteAt = Time.unscaledTime + 0.7f;
            if (best.mode == Mode.Work) { best.mode = Mode.Break; best.until = Time.unscaledTime + 2.5f; ShowFrame(best, 0); }
            where = Where(best);
            return true;
        }

        static Vector2 Where(Villager v) => v.body != null ? v.body.at : v.pos;

        /// <summary>Who is in which house, and whether they are asleep (for the lights and the zzz).</summary>
        public void CountIndoors(Dictionary<MapSpot, (int awake, int asleep)> houses, VillageTime t)
        {
            foreach (var v in villagers)
            {
                if (v.body == null || !v.body.Hidden || v.door == null) continue;
                houses.TryGetValue(v.door, out var n);
                if (v.at == Want.Home && Routine.Asleep(v.name, t.day, t.hour, v.kid)) n.asleep++; else n.awake++;
                houses[v.door] = n;
            }
        }

        public void Tick(VillageTime t)
        {
            float now = Time.unscaledTime, dt = Mathf.Min(Time.unscaledDeltaTime, 0.1f);
            foreach (var v in villagers)
            {
                if (v.emoteAt >= 0 && now >= v.emoteAt) { emotes.Show(v.img, HeadOf(v), v.emote); v.emoteAt = -1f; }
                if (v.body != null) TickBody(v, t, now, dt);
                else if (v.pace == Pace.Work) TickWorker(v, t, now);
            }
            // conversations among the people who are in their places
            foreach (var g in groups)
            {
                var here = g.members.FindAll(Present);
                if (here.Count >= 2) TickGroup(g, here, t, now);
                else foreach (var m in here) TickLoner(m, t, now);
            }
            foreach (var v in villagers)
            {
                if (v.pace == Pace.Chat && v.group == null && Present(v)) TickLoner(v, t, now);
                if (Present(v) || v.body == null) Animate(v, now);
            }
        }

        void Say(Villager v, string kind, float delay = 0f) { v.emote = kind; v.emoteAt = Time.unscaledTime + delay; }

        void Face(Villager v, bool away)
        {
            v.lookingAway = away;
            if (v.body != null) { Pose(v); return; }
            v.img.rectTransform.localScale = new Vector3(v.baseX * (away ? -1 : 1), 1, 1);
        }

        void ShowFrame(Villager v, int frame)
        {
            v.frame = frame;
            if (v.body != null) Pose(v); else v.img.sprite = v.frames[frame];
        }

        /// <summary>A villager in their place, showing their current action frame.</summary>
        void Pose(Villager v) => v.body.Pose(v.frames[v.frame], v.poseScale, Feet, (v.baseX > 0) != v.lookingAway);

        // ---------------------------------------------------------------- the day: where everyone is going
        /// <summary>Where they want to be, if they can get there (a place by the fire, a door to go in by).</summary>
        Want Desired(Villager v, VillageTime t)
        {
            var w = Routine.Wanted(v.name, t, v.owl, v.Worker, v.kid);
            if (w == Want.Camp && (fire == null || (v.seat < 0 && !fire.HasRoom))) w = Want.Home;
            if ((w == Want.Home || w == Want.Indoors || w == Want.Shelter) && v.home == null) w = Want.Out;   // no houses here
            return w;
        }

        void TickBody(Villager v, VillageTime t, float now, float dt)
        {
            var want = Desired(v, t);
            if (!v.placed) { v.placed = true; Place(v, want, now); return; }
            if (v.mode == Mode.Walk)
            {
                // on the way somewhere: carry on, unless they now want to be somewhere else (never turned round in a doorway)
                if (want != v.goal && !v.doorway) { Head(v, want, t); return; }
                if (v.route.Count == 0) { var a = v.arrive; v.arrive = null; a?.Invoke(); return; }
                if (v.body.WalkTo(v.route[0], v.at == Want.Out ? Amble : v.speed, dt)) v.route.RemoveAt(0);
                return;
            }
            if (want != v.at) { Head(v, want, t); return; }
            switch (want)
            {
                case Want.Out: if (v.Worker) TickPatch(v, t, now); break;
                case Want.Camp:
                    if (now >= v.until)
                    {
                        // round the fire: stories, songs and laughter, now looking at a neighbour, now back at the flames
                        v.until = now + Rand(3f, 7f);
                        Say(v, new[] { "talk", "talk", "laugh", "laugh", "note", "heart" }[rnd.Next(6)], Rand(0f, 0.6f));
                        v.body.Stand(rnd.NextDouble() < 0.3 ? new Vector2(-(fire.Center.x - v.body.at.x), fire.Center.y - v.body.at.y) : fire.Center - v.body.at);
                    }
                    break;
                case Want.Shelter:
                    if (now >= v.until) { v.until = now + Rand(6f, 12f); if (rnd.NextDouble() < 0.5) Say(v, rnd.NextDouble() < 0.5 ? "question" : "talk"); }
                    break;
                case Want.Play:
                    if (now >= v.until) Splash(v);
                    break;
            }
        }

        /// <summary>Puts someone straight where the time of day wants them (when the farm is first shown).</summary>
        void Place(Villager v, Want want, float now)
        {
            v.goal = want;
            switch (want)
            {
                case Want.Home:
                case Want.Indoors:
                    var door = want == Want.Home ? v.home : NearestDoor(Where(v)) ?? v.home;
                    v.door = door;
                    v.body.at = door.entry[door.entry.Length - 1].V; v.body.behind = door.depth;
                    v.body.Stand(new Vector2(1, -1));
                    v.body.Hidden = true; v.hit.raycastTarget = false;
                    v.at = want; v.mode = Mode.Inside;
                    break;
                case Want.Camp:
                    v.seat = fire.Claim(v);
                    v.body.at = fire.Seat(v.seat); v.body.behind = null;
                    v.body.Stand(fire.Center - v.body.at);
                    v.at = want; v.mode = Mode.Camp; v.until = now + Rand(0.5f, 5f);
                    break;
                case Want.Shelter:
                    v.body.at = ShelterPoint(v); v.body.behind = null; v.body.Stand(new Vector2(1, 1));
                    v.at = want; v.mode = Mode.Shelter; v.until = now + Rand(1f, 8f);
                    break;
                case Want.Play:
                    v.body.behind = null; v.body.Stand(new Vector2(1, 1));
                    v.at = want; v.mode = Mode.Play; v.until = now + Rand(0.5f, 2f);
                    break;
            }
        }

        /// <summary>Sets off for where they now want to be: out of the house first if they are in one.</summary>
        void Head(Villager v, Want want, VillageTime t)
        {
            if (v.seat >= 0 && want != Want.Camp) { fire.Release(v); v.seat = -1; }
            v.goal = want;
            if (v.mode == Mode.Inside)
            {
                // already in the right house (sheltering at home when the rain gives way to the night): stay in
                var door = want == Want.Home ? v.home : want == Want.Indoors ? NearestDoor(v.door.V) : null;
                if (door == v.door) { v.at = want; return; }
                LeaveHouse(v, () => Go(v, want, t));
                return;
            }
            Go(v, want, t);
        }

        void Go(Villager v, Want want, VillageTime t)
        {
            v.at = null; v.body.behind = null; v.lookingAway = false;
            var from = v.body.at;
            switch (want)
            {
                case Want.Out:
                    WalkTo(v, paths.Route(from, v.Worker ? v.patch[v.spot] : v.pos), () => BackInPlace(v));
                    break;
                case Want.Home:
                case Want.Indoors:
                    var door = want == Want.Home ? v.home : NearestDoor(from) ?? v.home;
                    if (t.rain && rnd.NextDouble() < 0.6) Say(v, "excl", 0.2f);
                    WalkTo(v, paths.Route(from, door), () => GoIn(v, door, want));
                    break;
                case Want.Camp:
                    v.seat = fire.Claim(v);
                    if (rnd.NextDouble() < 0.4) Say(v, "note", Rand(0.3f, 1.5f));
                    WalkTo(v, paths.Route(from, fire.Seat(v.seat)), () =>
                    {
                        v.at = Want.Camp; v.mode = Mode.Camp; v.until = Time.unscaledTime + Rand(0.5f, 3f);
                        v.body.Stand(fire.Center - v.body.at);
                    });
                    break;
                case Want.Shelter:
                    if (rnd.NextDouble() < 0.6) Say(v, "excl", 0.2f);
                    WalkTo(v, paths.Route(from, ShelterPoint(v)), () =>
                    {
                        v.at = Want.Shelter; v.mode = Mode.Shelter; v.until = Time.unscaledTime + Rand(2f, 6f);
                        v.body.Stand(new Vector2(1, 1));     // looking out at the rain
                    });
                    break;
                case Want.Play:
                    Splash(v);
                    break;
            }
        }

        /// <summary>Back in their place: the field worker at a plant, everyone else in their own spot and pose.</summary>
        void BackInPlace(Villager v)
        {
            v.at = Want.Out;
            v.body.behind = v.Worker ? null : v.seatDepth;
            v.lookingAway = false; v.frame = 0;
            v.mode = v.Worker ? Mode.Work : Mode.Idle;
            v.until = Time.unscaledTime + (v.Worker ? Rand(6f, 12f) : Rand(1f, 4f));
            Pose(v);
        }

        /// <summary>A doorstep of the nearest house, out of the rain; neighbours spread out along it.</summary>
        Vector2 ShelterPoint(Villager v)
        {
            var door = NearestDoor(v.Worker ? v.patch[0] : v.pos) ?? v.home;
            float k = Routine.Hash(v.name, 0, 31);
            return door.V + new Vector2((k - 0.5f) * 30f, 4f + k * 8f);
        }

        /// <summary>A child in the rain: off to another puddle near their place, laughing.</summary>
        void Splash(Villager v)
        {
            var home = v.Worker ? v.patch[0] : v.pos;
            var to = home + new Vector2(Rand(-60f, 60f), Rand(-30f, 30f));
            if (rnd.NextDouble() < 0.4) Say(v, rnd.NextDouble() < 0.6 ? "laugh" : "note", 0.2f);
            v.at = null;
            WalkTo(v, new List<Vector2> { to }, () => { v.at = Want.Play; v.mode = Mode.Play; v.until = Time.unscaledTime + Rand(0.6f, 2.2f); v.body.Stand(); });
        }

        void WalkTo(Villager v, List<Vector2> route, System.Action then)
        {
            v.route.Clear(); v.route.AddRange(route);
            v.arrive = then; v.mode = Mode.Walk;
        }

        /// <summary>Up to the door and through it, drawn behind the house, which hides them.</summary>
        void GoIn(Villager v, MapSpot door, Want want)
        {
            v.door = door; v.doorway = true;
            WalkTo(v, new List<Vector2> { door.entry[0].V }, () =>
            {
                v.body.behind = door.depth;
                var inside = new List<Vector2>();
                for (int i = 1; i < door.entry.Length; i++) inside.Add(door.entry[i].V);
                WalkTo(v, inside, () =>
                {
                    v.body.Hidden = true; v.hit.raycastTarget = false; v.doorway = false;
                    v.at = want; v.mode = Mode.Inside;
                });
            });
        }

        void LeaveHouse(Villager v, System.Action then)
        {
            var door = v.door;
            v.at = null; v.doorway = true;
            v.body.Hidden = false; v.hit.raycastTarget = true;
            var steps = new List<Vector2>();
            for (int i = door.entry.Length - 2; i >= 0; i--) steps.Add(door.entry[i].V);
            WalkTo(v, steps, () => { v.body.behind = null; v.doorway = false; v.door = null; then(); });
        }

        // ---------------------------------------------------------------- field workers in their patch
        void TickPatch(Villager v, VillageTime t, float now)
        {
            if (now < v.until) return;
            if (v.mode == Mode.Work && rnd.NextDouble() < 0.4) { TakeBreak(v, t, now); return; }
            if (v.mode == Mode.Work || v.mode == Mode.Break) { NextPlant(v); return; }
            v.mode = Mode.Work; v.until = now + Rand(6f, 12f); Face(v, false);
        }

        /// <summary>On to another plant in the patch.</summary>
        void NextPlant(Villager v)
        {
            int next;
            do next = rnd.Next(v.patch.Count); while (next == v.spot && v.patch.Count > 1);
            v.spot = next;
            WalkTo(v, new List<Vector2> { v.patch[next] }, () =>
            {
                v.mode = Mode.Work; v.until = Time.unscaledTime + Rand(6f, 12f);
                v.lookingAway = false; v.frame = 0; Pose(v);
            });
        }

        // ---------------------------------------------------------------- without walk art: they stay in their place
        void TickWorker(Villager v, VillageTime t, float now)
        {
            if (t.Dark) { if (v.mode != Mode.Idle) { v.mode = Mode.Idle; Face(v, false); } return; }   // done for the day: resting
            if (t.rain)
            {
                if (!v.wasRain) { v.wasRain = true; v.mode = Mode.Break; Face(v, false); if (rnd.NextDouble() < 0.6) Say(v, "excl", Rand(0f, 1.2f)); }
                v.until = now + 1f;
                return;
            }
            v.wasRain = false;
            if (v.mode == Mode.Idle) { v.mode = Mode.Break; v.until = now + Rand(1f, 4f); }
            if (now < v.until) return;
            if (v.mode == Mode.Work) TakeBreak(v, t, now);
            else { v.mode = Mode.Work; v.until = now + Rand(7f, 16f); Face(v, false); }
        }

        /// <summary>A breather: wipe the brow, hum, look around; at lunchtime a proper meal break.</summary>
        void TakeBreak(Villager v, VillageTime t, float now)
        {
            v.mode = Mode.Break;
            if (t.Lunch)
            {
                v.until = now + Rand(10f, 20f);
                if (rnd.NextDouble() < 0.7) Say(v, "food", Rand(0.3f, 2f));
                return;
            }
            v.until = now + Rand(2f, 5.5f);
            double r = rnd.NextDouble();
            if (r < 0.35) Say(v, "sweat", 0.3f); else if (r < 0.48) Say(v, "note", 0.3f);
            if (rnd.NextDouble() < 0.3) Face(v, true);
        }

        // ---------------------------------------------------------------- people on their own, and conversations
        void TickLoner(Villager v, VillageTime t, float now)
        {
            if (now < v.until) return;
            if (v.mode == Mode.Speak) { v.mode = Mode.Idle; v.until = now + Rand(5f, 12f) * (t.LateNight ? 2f : 1f); }
            else
            {
                v.mode = Mode.Speak; v.until = now + Rand(1.8f, 3.2f);
                if (rnd.NextDouble() < 0.55) Say(v, t.LateNight ? "zzz" : rnd.NextDouble() < 0.5 ? "note" : "heart", 0.2f);
            }
        }

        void TickGroup(Group g, List<Villager> here, VillageTime t, float now)
        {
            if (g.speaker != null && !here.Contains(g.speaker)) g.speaker = here[rnd.Next(here.Count)];
            if (now < g.pauseUntil) { foreach (var m in here) m.mode = Mode.Listen; return; }
            if (!g.started)
            {
                g.started = true;
                if (g.speaker == null)
                {
                    // everyone at once: the whole group bursts out laughing
                    foreach (var m in here) { m.mode = Mode.Speak; Say(m, "laugh", Rand(0f, 0.5f)); }
                }
                else
                {
                    foreach (var m in here) m.mode = m == g.speaker ? Mode.Speak : Mode.Listen;
                    Say(g.speaker, Emotes.Chatter[rnd.Next(Emotes.Chatter.Length)], 0.1f);
                }
            }
            if (now < g.until) return;

            // the turn is over: maybe someone reacts, then a short silence and the next person speaks
            var previous = g.speaker;
            double r = rnd.NextDouble();
            if (previous != null && r < 0.4)
            {
                var listener = here[rnd.Next(here.Count)];
                if (listener != previous) Say(listener, new[] { "laugh", "heart", "excl", "question" }[rnd.Next(4)], 0.2f);
            }
            float slow = t.LateNight ? 2.2f : 1f;
            g.pauseUntil = now + Rand(0.5f, 1.6f) * slow;
            g.started = false;
            if (previous != null && r > 0.9) { g.speaker = null; g.until = g.pauseUntil + 1.6f; return; }
            Villager next;
            do next = here[rnd.Next(here.Count)]; while (next == previous && here.Count > 1);
            g.speaker = next;
            g.until = g.pauseUntil + Rand(2.5f, 5f);
        }

        void Animate(Villager v, float now)
        {
            float step;
            switch (v.mode)
            {
                case Mode.Work: step = 0.24f; break;
                case Mode.Speak: step = 0.3f + (float)rnd.NextDouble() * 0.15f; break;
                case Mode.Listen: step = 0.8f + (float)rnd.NextDouble() * 0.9f; break;   // listeners move a little, slowly
                default:
                    if (v.frame != 0) ShowFrame(v, 0);     // resting pose
                    return;
            }
            if (now < v.next) return;
            ShowFrame(v, (v.frame + 1) % v.frames.Length);
            v.next = now + step;
        }
    }
}
