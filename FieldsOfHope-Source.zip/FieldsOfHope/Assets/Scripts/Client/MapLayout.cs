using System;
using System.Collections.Generic;
using UnityEngine;

namespace FieldsOfHope
{
    /// <summary>
    /// One location's farm map, written by Tools/map_builder.py to Resources/Map/layout_{location}.json.
    /// All positions are map px (the 1700 x 952 frame of FarmScreen.BgToWorld); y grows downwards and objects stand on their (x, y) foot.
    /// </summary>
    [Serializable] public class MapPoint { public float x, y; public Vector2 V => new Vector2(x, y); }

    [Serializable] public class MapObject
    {
        public string s;                       // sprite in Resources/Map
        public float x, y, w, h;               // foot position and drawn size
        public bool flip;
        public float sway;                     // trees and plants rock in the breeze (0 = still)
        public float spin;                     // water wheel / turbine rotor: degrees per second, centred on (x, y)
        public float squash = 1f;              // horizontal squash, so a face-on wheel reads as seen at an angle
        public float tilt;                     // degrees the squashed wheel leans, so it lies flat against a slanted wall
        public float depth;                    // draw order: larger = nearer the viewer
    }

    [Serializable] public class MapVillager
    {
        public string name; public float x, y, height; public string pace; public bool nightOwl;
        public float depth;                    // draw order when it differs from the feet (0 = by the feet)
        public bool flip;                      // faces left
        public MapPoint[] walk;                // field workers who walk: the spots in their patch they work at
        public float walkScale = 1f;           // their walk frames' size against their work frames (matched by head size)
    }
    [Serializable] public class MapWalker { public string who; public float height = 1f; public MapPoint[] route; }
    [Serializable] public class MapMarker { public string name; public float x, y; }
    [Serializable] public class MapPath { public MapPoint[] pts; }

    /// <summary>A place villagers walk to and stay a while: store, board, bench, well, view, or a house door.</summary>
    [Serializable] public class MapSpot
    {
        public string kind, name;
        public float x, y;                     // where the visitor stands (for a door: the doorstep)
        public MapPoint[] entry;               // doors: the steps from the door into the house, drawn behind it
        public float depth;                    // doors: just behind the house, so the house hides whoever goes in
        public Vector2 V => new Vector2(x, y);
    }

    /// <summary>A farm animal: where it was placed (its home, where it sleeps), its drawn size, and the places it wanders
    /// between (dry land clear of buildings and the field, or water for ducks and swans).</summary>
    [Serializable] public class MapAnimal
    {
        public string kind;
        public float x, y, w, h;
        public bool flip, swim;
        public MapPoint[] roam;
    }

    /// <summary>The farm's own farmhand: the house he lives in (a door spot) and the way from its door to the field.</summary>
    [Serializable] public class MapFarmhand { public string home; public MapPoint[] approach; }

    [Serializable] public class MapLayout
    {
        public string ground, mask;
        public MapObject[] objects;
        public MapVillager[] villagers;
        public MapWalker[] walkers;
        public MapMarker[] markers;
        public MapPoint[] chimneys, windows, flowers, treeTops, fireflies, lamps;
        public MapAnimal[] animals;
        public MapPoint home;
        public MapPath[] paths;                // the paths drawn on the ground, for walkers to follow
        public MapSpot[] spots;
        public MapFarmhand farmhand;

        static readonly Dictionary<string, MapLayout> cache = new Dictionary<string, MapLayout>();

        public static MapLayout Load(string location)
        {
            if (cache.TryGetValue(location, out var m)) return m;
            var text = Resources.Load<TextAsset>("Map/layout_" + location);
            m = text != null ? JsonUtility.FromJson<MapLayout>(text.text) : new MapLayout();
            cache[location] = m;
            return m;
        }

        public Vector2? Marker(string name)
        {
            if (markers != null)
                foreach (var k in markers) if (k.name == name) return new Vector2(k.x, k.y);
            return null;
        }
    }

    /// <summary>Marks a child of a <see cref="DepthSorter"/> layer with the map y it stands on.</summary>
    public class DepthKey : MonoBehaviour { public float y; }

    /// <summary>
    /// Keeps its children in painter's order (farther first) by their <see cref="DepthKey"/>, so villagers walk behind
    /// trees and houses and in front of what stands behind them. Only reorders when the order actually changes.
    /// </summary>
    public class DepthSorter : MonoBehaviour
    {
        readonly List<DepthKey> keys = new List<DepthKey>();

        void LateUpdate()
        {
            keys.Clear();
            for (int i = 0; i < transform.childCount; i++)
            {
                var k = transform.GetChild(i).GetComponent<DepthKey>();
                if (k != null) keys.Add(k);
            }
            bool sorted = true;
            for (int i = 1; i < keys.Count; i++) if (keys[i - 1].y > keys[i].y) { sorted = false; break; }
            if (sorted) return;
            keys.Sort((a, b) => a.y.CompareTo(b.y));
            for (int i = 0; i < keys.Count; i++) keys[i].transform.SetSiblingIndex(i);
        }
    }
}
