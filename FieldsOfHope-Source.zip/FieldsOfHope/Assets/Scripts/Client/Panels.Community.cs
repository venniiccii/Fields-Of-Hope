using System;
using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace FieldsOfHope
{
    // ====================================================================== daily quests and farming suggestions (PROG-04/05)
    public class QuestsPanel : Panel
    {
        RectTransform content;
        public override string Key => "quests";
        public override void Build(RectTransform layer) => content = Frame(layer, "Quest Objectives", 1000, 900, -30);

        public override void Refresh()
        {
            UI.Clear(content);
            var sr = UI.Scroll(content, out var list, 8);
            ((RectTransform)sr.transform).Fill();
            var hdr = UI.Label(list, "Check progress to earn rewards!", 26, UI.Ink, TextAnchor.MiddleCenter, true);
            hdr.Layout(-1, 40);
            foreach (var q in S.Save.quests)
            {
                var row = Kit.Row(list, 100);
                Kit.Icon(row.transform, q.icon, 12, 76);
                Kit.Text(row.transform, q.title + " (" + q.progress + "/" + q.target + ")", 25, 104, 10, 230, 50, null, TextAnchor.UpperLeft, true);
                var (bg, fill) = UI.Bar(row.transform);
                bg.rectTransform.At(0, 0, 104, 22, 470, 24, 0, 0);
                UI.SetBar(fill, q.progress / (float)q.target);
                var pr = UI.Label(bg.transform, q.progress + "/" + q.target, 18, UI.Cream, TextAnchor.MiddleCenter, true).Outlined(null, 1);
                pr.rectTransform.Fill();
                var reward = Kit.Text(row.transform, q.coins + "c · " + q.xp + " XP · " + q.cp + " CP", 18, 590, 50, 100, 10, UI.Muted, TextAnchor.MiddleLeft);
                reward.horizontalOverflow = HorizontalWrapMode.Overflow;
                var id = q.id;
                if (q.claimed) Kit.Icon(row.transform, "icon_check", 820, 60).rectTransform.At(1, 0.5f, -30, 0, 60, 60, 1, 0.5f);
                else if (q.Done) Kit.Button(row.transform, "Claim", () => { if (App.Act(tx => S.ClaimQuest(tx, id)).ok) Sfx.Coin(); }, 14, 150);
                else { var box = UI.Img(row.transform, "slot_empty"); box.rectTransform.At(1, 0.5f, -40, 0, 54, 54, 1, 0.5f); }
            }
            int full = S.Save.questFullDays.Count(d => d > S.Today - 7);
            var wk = UI.Label(list, "Weekly bonus: finish every quest on 5 of 7 days for +200 coins (" + full + "/5). Quests reset at midnight.", 20, UI.Muted);
            wk.Layout(-1, 36);

            Section(list, "Farming Suggestions");
            Heading(list, "WHAT TO PLANT", "slot_seedbag");
            foreach (var s in S.PlantSuggestions()) Suggest(list, "Plant: " + s.title, s.reason, s.icon, () => App.Open(new ShopPanel(Defs.Crop(s.id).hybrid ? "Featured" : "Seeds")));
            Heading(list, "WHAT TO USE", "item_fertilizer");
            foreach (var s in S.UseSuggestions())
                Suggest(list, "Use: " + s.title, s.reason, s.icon, () =>
                {
                    if (s.id == "tool_can") { Close(); App.Farm.SelectTool(Tool.Can); }
                    else App.Open(new ShopPanel("Supplies"));
                });
        }

        static void Section(Transform list, string title)
        {
            var holder = UI.New(title, list); holder.Layout(-1, 80);
            var r = UI.Sliced(holder, "ribbon"); r.rectTransform.At(0.5f, 0.5f, 0, 0, 560, 70);
            var t = UI.Label(r.transform, title.ToUpperInvariant(), 30, UI.Cream, TextAnchor.MiddleCenter, true).Outlined();
            t.rectTransform.Fill(20, 4, 20, 8);
        }

        static void Heading(Transform list, string title, string icon)
        {
            var row = UI.HRow(list, 56, 14);
            row.childAlignment = TextAnchor.MiddleCenter;
            UI.Img(row.transform, icon).Layout(48, 48);
            UI.Label(row.transform, title, 30, UI.Ink, TextAnchor.MiddleCenter, true).Layout(300, 50);
            UI.Img(row.transform, icon).Layout(48, 48);
        }

        static void Suggest(Transform list, string title, string reason, string icon, Action onClick)
        {
            var row = Kit.Row(list, 84);
            Kit.Icon(row.transform, icon, 14, 60);
            Kit.Text(row.transform, title + "\n<size=20>Reason: " + reason + "</size>", 24, 92, 10, 20, 6, null, TextAnchor.UpperLeft, true);
            row.Clickable(onClick);
        }
    }

    // ====================================================================== community needs and delivery (COMM-02..04)
    public class CommunityPanel : Panel
    {
        RectTransform content;
        bool readyOnly;
        public override string Key => "community";
        public override void Build(RectTransform layer) => content = Frame(layer, "Community Needs", 1120, 900, -30);

        public override void Refresh()
        {
            UI.Clear(content);
            var l = S.Here;
            var head = UI.New("Head", content).At(0, 1, 0, 0, 0, 120, 0, 1);
            head.anchorMax = new Vector2(1, 1);
            Kit.Text(head, S.HereDef.name + " food security", 26, 0, 0, 0, 80, null, TextAnchor.UpperLeft, true);
            var (bg, fill) = UI.Bar(head, GameServer.BandColor(l.meter));
            bg.rectTransform.At(0, 1, 0, -38, 520, 30, 0, 1);
            UI.SetBar(fill, l.meter / 100f);
            Kit.Text(head, "<b>" + GameServer.Band(l.meter) + "</b> " + l.meter + "/100", 26, 540, 34, 0, 50, GameServer.BandColor(l.meter) * 0.8f);
            Kit.Text(head, "Pantry " + S.PantryDays(l).ToString("0.0") + " days · Stable streak " + l.stableDays + " days · Requests completed " + l.requestsCompleted, 21, 0, 78, 0, 0, UI.Muted);
            var filter = UI.TextButton(head, readyOnly ? "[x] Ready now" : "[ ] Ready now", () => { readyOnly = !readyOnly; Refresh(); }, readyOnly ? "btn_green" : "btn", 20);
            ((RectTransform)filter.transform).At(1, 1, 0, 0, 200, 48, 1, 1);

            var sr = UI.Scroll(content, out var list);
            ((RectTransform)sr.transform).Fill(0, 130, 0, 66);
            var reqs = l.requests.OrderBy(r => r.status).ThenBy(r => r.deadline).ToList();
            if (readyOnly) reqs = reqs.Where(r => r.status == RequestStatus.Open && S.Count("crop_" + r.crop) >= r.Remaining).ToList();
            foreach (var r in reqs) RequestRow(list, r);
            if (reqs.Count == 0) UI.Label(list, readyOnly ? "Nothing ready to deliver yet." : "No requests today. New ones arrive at midnight.", 24, UI.Muted).Layout(-1, 100);

            var bottom = UI.New("Bottom", content).At(0.5f, 0f, 0, 0, 1020, 56, 0.5f, 0f);
            Kit.Text(bottom, "Deliveries pay 100% plus XP and CP. The market pays 70% and no XP.", 20, 0, 14, 260, 0, UI.Muted);
            var market = UI.TextButton(bottom, "Sell surplus", () => App.Open(new InventoryPanel("Harvested Crops")), "btn", 22);
            ((RectTransform)market.transform).At(1, 0.5f, 0, 0, 230, 52, 1, 0.5f);
        }

        void RequestRow(Transform list, Request r)
        {
            var c = Defs.Crop(r.crop);
            int stock = S.Count(c.CropItemId);
            var row = Kit.Row(list, 112);
            if (r.status != RequestStatus.Open) row.color = new Color(0.85f, 0.85f, 0.8f);
            Kit.Icon(row.transform, c.icon, 14, 80, c.tint);
            string tags = (r.essential ? " <color=#C84030>[Essential]</color>" : "") + (r.surge ? " <color=#C84030>[Surge +25%]</color>" : "") +
                          (r.large ? " [Large]" : "") + (r.crossRegion ? " [From " + Defs.Loc(c.location).name + "]" : "");
            Kit.Text(row.transform, c.name + " x" + r.qty + "<size=20>" + tags + "</size>", 26, 108, 10, 300, 60, null, TextAnchor.UpperLeft, true);
            Kit.Text(row.transform, "Delivered " + r.delivered + "/" + r.qty + " · You have " + stock + " · Reward " + r.coins + "c, " + S.RequestXp(r, r.qty) + " XP, " + r.cp + " CP", 19, 108, 48, 300, 30, UI.Muted);
            var due = Kit.Text(row.transform, "", 19, 108, 76, 300, 4, UI.Ink);
            if (r.status == RequestStatus.Open)
                due.Live(() =>
                {
                    float m = (r.deadline - S.NowMs) / 60000f;
                    due.text = "Due in " + S.FormatDuration(Mathf.Max(0, m));
                    due.color = m < 120 ? UI.Red : UI.Ink;
                }, 1f);
            else due.text = r.status == RequestStatus.Completed ? "<color=#468C32><b>Completed</b></color>" : "<color=#C84030><b>Missed</b></color>";
            if (r.status != RequestStatus.Open) return;
            var id = r.id;
            if (stock >= r.Remaining)
                Kit.Button(row.transform, "Deliver " + r.Remaining, () => { if (App.Act(tx => S.Deliver(tx, id, false), "deliver").ok) Sfx.Coin(); }, 14, 250, 56);
            else
            {
                var need = Kit.Button(row.transform, "Need " + (r.Remaining - stock) + " more", null, 14, 250, 48, "btn", 20);
                need.interactable = false;
                ((RectTransform)need.transform).anchoredPosition += new Vector2(0, 26);
                if (stock > 0 && !r.partialUsed)
                {
                    var part = Kit.Button(row.transform, "Deliver " + stock + " (partial)", () => App.Confirm("Partial delivery",
                        "Deliver " + stock + " of " + r.Remaining + " " + c.name + " now?\nPayment is pro-rated with no XP. You can only do this once per request.",
                        "Deliver", () => App.Act(tx => S.Deliver(tx, id, true), "deliver")), 14, 250, 44, "btn_green", 19);
                    ((RectTransform)part.transform).anchoredPosition += new Vector2(0, -26);
                }
            }
        }
    }

    // ====================================================================== NPC dialogue (COMM-06)
    public class DialoguePanel : Panel
    {
        readonly string text;
        readonly (string label, string icon, Action act)[] options;
        public override string Key => "dialogue";

        public DialoguePanel() : this("Hi there! We're looking for fresh produce for the community. Would you like to sell your harvest?",
            ("Yes, I'd like to sell my harvest.", "icon_basket_reply", () => GameApp.I.Open(new CommunityPanel())),
            ("Let me check my inventory first.", "icon_crate_reply", () => GameApp.I.Open(new InventoryPanel("Harvested Crops"))),
            ("Not right now.", "icon_speech", null)) { }

        public DialoguePanel(string text, params (string, string, Action)[] options) { this.text = text; this.options = options; }

        public override void Build(RectTransform layer)
        {
            var dim = UI.Rect(layer, new Color(0, 0, 0, 0.35f), "Dialogue");
            dim.rectTransform.Fill(); dim.raycastTarget = true;
            Root = dim.rectTransform;
            var portrait = UI.Img(Root, "npc_portrait");
            portrait.rectTransform.TL(196, 150, 400, 414);
            portrait.Outlined(new Color(0.3f, 0.18f, 0.08f), 4);
            float born = Time.unscaledTime;
            portrait.Live(() => portrait.rectTransform.localScale = Vector3.one * (1f + Mathf.Sin((Time.unscaledTime - born) * 2f) * 0.01f), 0.03f);

            // the same rounded parchment and nameplate as every other window
            var box = UI.Sliced(Root, "panel", null, 1f, "Box");
            box.rectTransform.TL(150, 590, 980, 450);
            box.Shadowed(6);
            var plate = UI.Sliced(box.transform, "nameplate", null, 1f, "Speaker");
            plate.rectTransform.At(0f, 1f, 50, 34, 400, 72, 0f, 1f);
            var who = UI.Label(plate.transform, "Community Member", 34, UI.Cream, TextAnchor.MiddleCenter, true).Outlined();
            who.rectTransform.Fill(16, 4, 16, 8);
            var t = UI.Label(box.transform, "", 38, new Color(0.18f, 0.12f, 0.06f), TextAnchor.UpperLeft);
            t.rectTransform.Fill(66, 80, 60, 50);
            // typewriter reveal
            t.Live(() => t.text = text.Substring(0, Mathf.Min(text.Length, (int)((Time.unscaledTime - born) * 60))), 0.02f);
            box.raycastTarget = true;
            box.Clickable(() => born -= 100, false);

            var frame = UI.Sliced(Root, "panel", new Color(0.95f, 0.85f, 0.7f), 1f, "Replies");
            frame.rectTransform.TL(1130, 470, 680, 130 + options.Length * 140);
            for (int i = 0; i < options.Length; i++)
            {
                var (label, icon, act) = options[i];
                var b = UI.Sliced(frame.transform, i == 0 ? "reply_hi" : "reply", null, 1f, "Reply " + i);
                b.rectTransform.At(0.5f, 1f, 0, -50 - i * 140, 580, 124, 0.5f, 1f);
                var ic = UI.Img(b.transform, icon); ic.rectTransform.At(0, 0.5f, 26, 0, 96, 96, 0, 0.5f);
                var lt = UI.Label(b.transform, label, 32, new Color(0.18f, 0.12f, 0.06f), TextAnchor.MiddleLeft);
                lt.rectTransform.Fill(140, 8, 20, 8);
                if (i == 0)
                {
                    var arrow = UI.Label(b.transform, ">", 44, UI.Ink, TextAnchor.MiddleCenter, true);
                    arrow.rectTransform.At(0, 0.5f, -48, 0, 40, 60, 0, 0.5f);
                    arrow.Live(() => arrow.rectTransform.anchoredPosition = new Vector2(-48 + Mathf.Sin(Time.unscaledTime * 6) * 5, 0), 0.03f);
                }
                var a = act;
                b.Clickable(() => { Close(); a?.Invoke(); });
            }
        }
    }

    // ====================================================================== map and travel (MAP-01..03, LOC-02)
    public class MapPanel : Panel
    {
        RectTransform card, islands;
        string selected;
        public override string Key => "map";
        static readonly (string id, float x, float y)[] Pins = { ("baguio", 0.446f, 0.212f), ("ilocos", 0.257f, 0.618f), ("davao", 0.773f, 0.439f) };

        public override void Build(RectTransform layer)
        {
            var dim = UI.Rect(layer, new Color(0.96f, 0.98f, 0.9f, 0.55f), "Map");
            dim.rectTransform.Fill(); dim.raycastTarget = true;
            Root = dim.rectTransform;
            var img = UI.Img(Root, "map_islands");
            islands = img.rectTransform;
            islands.At(0.5f, 0.5f, -180, -20, 1240, 929);
            float born = Time.unscaledTime;
            img.Live(() => islands.anchoredPosition = new Vector2(-180, -20 + Mathf.Sin((Time.unscaledTime - born) * 1.2f) * 6), 0.03f);

            foreach (var (id, x, y) in Pins)
            {
                var pin = UI.Rect(islands, new Color(0, 0, 0, 0), "Pin " + id);
                pin.rectTransform.At(x, 1 - y, 0, 0, 170, 170);
                var pid = id;
                pin.Clickable(() => Select(pid));
                var badge = UI.Img(pin.transform, null);
                badge.rectTransform.At(0.5f, 0.5f, 52, 34, 54, 54);
                var name = UI.Label(pin.transform, "", 22, Color.white, TextAnchor.UpperCenter, true).Outlined(new Color(0.15f, 0.1f, 0.05f), 2);
                name.rectTransform.At(0.5f, 0f, 0, 0, 260, 30, 0.5f, 1f);
                badge.Live(() =>
                {
                    var l = S.Loc(pid);
                    bool here = S.Save.currentLocation == pid;
                    bool open = S.CanVisit(pid);
                    badge.sprite = UI.S(here ? "bubble_ready" : open ? null : S.IsEligible(pid) ? "icon_coin" : "icon_lock");
                    badge.enabled = badge.sprite != null;
                    name.text = here ? "You are here" : l.unlocked ? "Tap to travel" : open ? "Preview: tap to visit" : S.IsEligible(pid) ? "Ready to open" : "Locked";
                    badge.rectTransform.anchoredPosition = new Vector2(52, 34 + (here ? Mathf.Sin(Time.unscaledTime * 4) * 5 : 0));
                }, 0.05f);
            }

            var close = UI.TextButton(Root, "Close Map", Close, "btn", 28);
            ((RectTransform)close.transform).At(0.5f, 0f, -180, 40, 260, 70, 0.5f, 0f);
            card = UI.New("Card", Root).At(1, 0.5f, -30, -10, 600, 820, 1, 0.5f);
            Select(S.Save.currentLocation);
        }

        void Select(string id)
        {
            selected = id;
            UI.Clear(card);
            var def = Defs.Loc(id); var l = S.Loc(id);
            var panel = UI.Sliced(card, "panel"); panel.rectTransform.Fill(); panel.raycastTarget = true;
            var ribbon = UI.Sliced(panel.transform, "ribbon"); ribbon.rectTransform.At(0.5f, 1f, 0, 30, 480, 66, 0.5f, 1f);
            UI.Label(ribbon.transform, def.name.ToUpperInvariant(), 28, UI.Cream, TextAnchor.MiddleCenter, true).Outlined().rectTransform.Fill(20, 4, 20, 8);
            var body = UI.New("Body", panel.transform).Fill(44, 60, 40, 30);
            var sr = UI.Scroll(body, out var list, 6, 2);
            ((RectTransform)sr.transform).Fill(0, 0, 0, 90);
            void Line(string s, int size = 22, Color? c = null) => UI.Label(list, s, size, c ?? UI.Ink, TextAnchor.UpperLeft).Layout(-1, -1);

            Line("<b>Climate:</b> " + def.climate);
            var crops = UI.HRow(list, 60, 4);
            foreach (var c in Defs.Crops.Where(c => c.location == id && !c.hybrid)) UI.Img(crops.transform, c.icon).Layout(52, 52);
            Line("<b>Crops:</b> " + string.Join(", ", Defs.Crops.Where(c => c.location == id && !c.hybrid).Select(c => c.name)), 20);
            Line("<b>Farming:</b> " + def.considerations, 20);
            Line("<b>Challenges:</b> " + def.challenges, 20);
            Line("<i>" + def.realNote + "</i>", 18, UI.Muted);

            var action = UI.New("Action", body).At(0.5f, 0f, 0, 0, 500, 80, 0.5f, 0f);
            if (S.Save.currentLocation == id)
            {
                Line("\n<b>You are here.</b> Food security: " + GameServer.Band(l.meter) + " (" + l.meter + ")", 22);
                UI.Label(action, "Current location", 26, UI.Green, TextAnchor.MiddleCenter, true).rectTransform.Fill();
            }
            else if (S.CanVisit(id))
            {
                if (!l.unlocked) Line("\n<b>Evaluation preview:</b> open for inspection. In the full game this location unlocks with progress.", 20, UI.Purple);
                Line("\nFood security:" + GameServer.Band(l.meter) + " (" + l.meter + "). Coins, XP, CP and your inventory travel with you.", 22);
                var b = UI.TextButton(action, "Travel", () => App.StartCoroutine(TravelRoutine(id)), "btn_green", 30);
                ((RectTransform)b.transform).Fill();
            }
            else
            {
                Line("\n<b>Unlock checklist</b>", 24);
                foreach (var r in S.UnlockRequirements(id))
                    Line((r.met ? "<color=#468C32>[x]</color> " : "<color=#C84030>[ ]</color> ") + r.label + "  <color=#7a5a3a>(" + r.progress + ")</color>", 20);
                Line("Settlement fee: " + def.fee.ToString("N0") + " coins", 22);
                bool eligible = S.IsEligible(id);
                var b = UI.TextButton(action, eligible ? "Pay " + def.fee.ToString("N0") + " coins" : "Locked", () =>
                    App.Confirm("Open " + def.name, "Pay the one-time " + def.fee.ToString("N0") + " coin settlement fee to open " + def.name + "?", "Pay",
                        () => { if (App.Act(tx => S.PayUnlock(tx, id)).ok) { Sfx.Fanfare(); Select(id); } }), "btn_green", 28);
                ((RectTransform)b.transform).Fill();
                b.interactable = eligible && S.Save.coins >= def.fee;
            }
        }

        IEnumerator TravelRoutine(string id)
        {
            var fade = UI.Rect(App.PopupLayer, new Color(0.1f, 0.08f, 0.05f, 0f), "Travel");
            fade.rectTransform.Fill(); fade.raycastTarget = true;
            var t = UI.Label(fade.transform, "Traveling to " + Defs.Loc(id).name + "...", 48, UI.Cream, TextAnchor.MiddleCenter, true);
            t.rectTransform.Fill();
            for (float a = 0; a < 1; a += Time.unscaledDeltaTime * 3) { fade.color = new Color(0.1f, 0.08f, 0.05f, a); yield return null; }
            var r = App.Act(tx => S.Travel(tx, id), "travel", false);
            if (r.ok)
            {
                Close();
                App.Farm.RebuildLocation();
                App.Farm.Home(true);
            }
            yield return new WaitForSecondsRealtime(0.5f);
            for (float a = 1; a > 0; a -= Time.unscaledDeltaTime * 3) { fade.color = new Color(0.1f, 0.08f, 0.05f, a); t.color = new Color(1, 0.95f, 0.8f, a); yield return null; }
            UnityEngine.Object.Destroy(fade.gameObject);
            if (r.ok) ArrivalIntro(id);
        }

        void ArrivalIntro(string id)
        {
            var l = S.Loc(id);
            var def = Defs.Loc(id);
            if (l.introShown || def.arrivalIntro == null) { App.Toast("Welcome to " + def.name + "!"); return; }
            l.introShown = true;
            S.Persist();
            App.Open(new DialoguePanel(def.arrivalIntro, ("Let's get farming!", "icon_basket_reply", null)));
        }
    }

    // ====================================================================== settings and logout (UI-02)
    public class SettingsPanel : Panel
    {
        RectTransform content;
        int tzDraft;
        public override string Key => "settings";
        public override void Build(RectTransform layer)
        {
            content = Frame(layer, "Settings", 900, 900, -30);
            tzDraft = S.Save.tzOffsetMin;
            S.Persist();   // J.2: sync when Settings opens
        }

        public override void Refresh()
        {
            UI.Clear(content);
            var sr = UI.Scroll(content, out var list, 10);
            ((RectTransform)sr.transform).Fill();
            if (Music.Available) Row(list, "Music", Music.Enabled ? "On" : "Off", () => { Music.Enabled = !Music.Enabled; Refresh(); });
            Row(list, "Sound effects", S.Save.sound ? "On" : "Off", () => { S.Save.sound = !S.Save.sound; Sfx.Enabled = S.Save.sound; S.Persist(); Refresh(); });
            Row(list, "Notifications", S.Save.notifications ? "All" : "Warnings only", () => { S.Save.notifications = !S.Save.notifications; S.Persist(); Refresh(); });
            Row(list, "Tutorial", "Replay", () => App.Confirm("Replay tutorial", "Start the guided tutorial again? Its reward is only given once.", "Replay",
                () => { S.ReplayTutorial(); Close(); App.Tutorial.Begin(); }));
            Row(list, "Notification log (24 h)", "Open", ShowLog);

            var tz = Kit.Row(list, 90);
            Kit.Text(tz.transform, "Timezone: UTC" + Fmt(tzDraft) + "\n<size=18>Daily reset at midnight. Changeable once every 7 days.</size>", 24, 20, 12, 380, 6, null, TextAnchor.UpperLeft, true);
            Kit.Button(tz.transform, "-", () => { tzDraft -= 60; Refresh(); }, 286, 60, 50, "btn", 26);
            Kit.Button(tz.transform, "+", () => { tzDraft += 60; Refresh(); }, 216, 60, 50, "btn", 26);
            var apply = Kit.Button(tz.transform, "Apply", () => App.Act(tx => S.SetTimezone(tzDraft)), 16, 180, 50);
            apply.interactable = tzDraft != S.Save.tzOffsetMin;

            Row(list, "Return to Title", "Go", () => App.ReturnToTitle());
            Row(list, "Log out of " + S.Save.username, "Logout", () => App.Confirm("Logout", "Save and log out?", "Logout", () => App.Logout()));

            if (Application.isEditor || Debug.isDebugBuild)
            {
                UI.Label(list, "Developer tools (editor and development builds only)", 22, UI.Red, TextAnchor.MiddleCenter, true).Layout(-1, 44);
                var r1 = UI.HRow(list, 56, 8); r1.childAlignment = TextAnchor.MiddleCenter;
                void Dev(Transform row, string label, Action a) => UI.TextButton(row, label, () => { a(); App.NotifyChanged(); }, "btn", 20).Layout(150, 52);
                Dev(r1.transform, "+10 min", () => S.DevAdvance(10));
                Dev(r1.transform, "+1 hour", () => S.DevAdvance(60));
                Dev(r1.transform, "+1 day", () => S.DevAdvance(1440));
                Dev(r1.transform, "+500c +200XP", () => S.DevGrant(500, 200));
                var r2 = UI.HRow(list, 56, 8); r2.childAlignment = TextAnchor.MiddleCenter;
                Dev(r2.transform, "Rain", () => S.DevTrigger("rain"));
                Dev(r2.transform, "Pests", () => S.DevTrigger("pest"));
                Dev(r2.transform, "Drought", () => S.DevTrigger("drought"));
            }
        }

        static string Fmt(int m) => (m >= 0 ? "+" : "-") + Mathf.Abs(m / 60) + (m % 60 != 0 ? ":" + Mathf.Abs(m % 60).ToString("00") : "");

        void Row(Transform list, string label, string button, Action a)
        {
            var row = Kit.Row(list, 80);
            Kit.Text(row.transform, label, 26, 20, 0, 260, 0, null, TextAnchor.MiddleLeft, true);
            Kit.Button(row.transform, button, a, 16, 220, 54, "btn", 22);
        }

        void ShowLog()
        {
            var log = S.Save.notifLog.AsEnumerable().Reverse().Take(14)
                .Select(n => DateTimeOffset.FromUnixTimeMilliseconds(n.at).UtcDateTime.AddMinutes(S.Save.tzOffsetMin).ToString("HH:mm") + "  " + n.title).ToList();
            App.Message("Notification log", log.Count == 0 ? "No notifications in the last 24 hours." : string.Join("\n", log));
        }
    }

    // ====================================================================== profile and progression
    public class ProfilePanel : Panel
    {
        RectTransform content;
        public override string Key => "profile";
        public override void Build(RectTransform layer) => content = Frame(layer, S.Save.username, 900, 820, -30);

        public override void Refresh()
        {
            UI.Clear(content);
            var s = S.Save;
            int from = Defs.XpForLevel[s.level], to = s.level >= Defs.MaxLevel ? s.xp : Defs.XpForLevel[s.level + 1];
            Kit.Text(content, "Level " + s.level + (s.level >= 15 ? "  ·  Food Security Champion" : "") + "\nXP " + s.xp + (s.level < Defs.MaxLevel ? " / " + to : ""), 28, 0, 0, 0, 640, null, TextAnchor.UpperLeft, true);
            var (bg, fill) = UI.Bar(content, new Color(0.55f, 0.85f, 0.35f));
            bg.rectTransform.At(0, 1, 0, -92, 780, 26, 0, 1);
            UI.SetBar(fill, s.level >= Defs.MaxLevel ? 1 : (s.xp - from) / (float)(to - from));
            Kit.Text(content, "Coins " + s.coins.ToString("N0") + " · Community Points " + s.cp + " · Daily streak " + s.streak + " days", 22, 0, 130, 0, 560, UI.Muted);

            float y = 180;
            foreach (var def in Defs.Locations)
            {
                var l = S.Loc(def.id);
                var row = UI.Sliced(content, "row", null, 1f, def.name);
                row.rectTransform.At(0, 1, 0, -y, 0, 130, 0, 1);
                row.rectTransform.anchorMax = new Vector2(1, 1); row.rectTransform.sizeDelta = new Vector2(0, 130);
                Kit.Text(row.transform, def.name + (S.Save.currentLocation == def.id ? "  (here)" : ""), 26, 20, 12, 20, 80, null, TextAnchor.UpperLeft, true);
                if (l.unlocked)
                {
                    var (b2, f2) = UI.Bar(row.transform, GameServer.BandColor(l.meter));
                    b2.rectTransform.At(0, 1, 20, -56, 420, 24, 0, 1);
                    UI.SetBar(f2, l.meter / 100f);
                    Kit.Text(row.transform, GameServer.Band(l.meter) + " " + l.meter, 24, 460, 50, 20, 40, GameServer.BandColor(l.meter) * 0.8f, TextAnchor.UpperLeft, true);
                    Kit.Text(row.transform, S.OwnedPlots(l) + " plots · " + l.requestsCompleted + " requests · Stable streak " + l.stableDays + " days", 20, 20, 90, 20, 6, UI.Muted);
                }
                else
                {
                    int met = S.UnlockRequirements(def.id).Count(r => r.met), all = S.UnlockRequirements(def.id).Count;
                    Kit.Text(row.transform, "Locked · " + met + "/" + all + " requirements met · fee " + def.fee.ToString("N0") + " coins", 22, 20, 56, 20, 10, UI.Muted);
                    row.Clickable(() => App.Open(new MapPanel()));
                }
                y += 142;
            }
            Kit.Text(content, "Goal: raise every community to Thriving (85+) through steady, varied deliveries.", 22, 0, y + 10, 0, 0, UI.Muted);
        }
    }
}
