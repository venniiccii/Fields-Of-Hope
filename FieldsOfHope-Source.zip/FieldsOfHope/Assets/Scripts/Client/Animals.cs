using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace FieldsOfHope
{
    /// <summary>
    /// The farm animals. By day they wander about their patch: chickens scratch and peck, the cat strolls and sits, goats,
    /// deer and the carabao amble and graze, and ducks and swans glide about the water. At dusk each goes back to its own
    /// place and settles down to sleep (lying down, curled up, or with its head tucked in), with a zzz now and then, and
    /// gets up again at dawn. The places come from the location's map layout (Tools/map_builder.py, animal_roams). The art:
    /// the standing sprite is the map piece (Resources/Map/{kind}), the walk is anim_{kind}_walk (4 frames, 128 px high,
    /// the figure 112 px tall) and the sleeping pose anim_{kind}_sleep (Tools/slice_animal.py).
    /// </summary>
    public class Animals
    {
        const float Figure = 112f, FrameH = 128f, FootPx = 4f;

        class Kind
        {
            public float speed, steps, rest0, rest1, sleepWidth, bed0, bed1, wake0, wake1;
            public bool peck, swim;
        }

        // speed in map px per second; steps = walk frames per map px; rest = seconds between strolls;
        // sleepWidth = how wide the sleeping pose is against the standing one; bed and wake = local hours
        static readonly Dictionary<string, Kind> Kinds = new Dictionary<string, Kind>
        {
            { "chicken", new Kind { speed = 16, steps = 0.2f, rest0 = 0.8f, rest1 = 3.5f, sleepWidth = 0.95f, peck = true, bed0 = 18.3f, bed1 = 18.9f, wake0 = 5.2f, wake1 = 5.7f } },
            { "hen", new Kind { speed = 15, steps = 0.2f, rest0 = 0.8f, rest1 = 3.5f, sleepWidth = 0.95f, peck = true, bed0 = 18.3f, bed1 = 18.9f, wake0 = 5.2f, wake1 = 5.7f } },
            { "cat", new Kind { speed = 20, steps = 0.13f, rest0 = 3f, rest1 = 10f, sleepWidth = 1.2f, bed0 = 21.3f, bed1 = 22.3f, wake0 = 6.3f, wake1 = 7.1f } },
            { "goat", new Kind { speed = 13, steps = 0.13f, rest0 = 3f, rest1 = 9f, sleepWidth = 1.25f, bed0 = 19.3f, bed1 = 20.3f, wake0 = 5.5f, wake1 = 6.3f } },
            { "deer", new Kind { speed = 15, steps = 0.11f, rest0 = 3f, rest1 = 10f, sleepWidth = 1.35f, bed0 = 19.5f, bed1 = 20.5f, wake0 = 5.3f, wake1 = 6.1f } },
            { "carabao", new Kind { speed = 7, steps = 0.08f, rest0 = 5f, rest1 = 14f, sleepWidth = 1f, bed0 = 19.3f, bed1 = 20.3f, wake0 = 5.5f, wake1 = 6.3f } },
            { "duck", new Kind { speed = 6, rest0 = 2f, rest1 = 6f, sleepWidth = 1f, swim = true, bed0 = 18.8f, bed1 = 19.5f, wake0 = 5.5f, wake1 = 6.2f } },
            { "swan", new Kind { speed = 5, rest0 = 3f, rest1 = 8f, sleepWidth = 1f, swim = true, bed0 = 18.8f, bed1 = 19.5f, wake0 = 5.5f, wake1 = 6.2f } },
        };

        class Animal
        {
            public string id;
            public Kind k;
            public Image img;
            public DepthKey depth;
            public Sprite stand, sleep;
            public Sprite[] walk;
            public Vector2 home, at, target;
            public Vector2[] roam;
            public float w, h, until, clock, nextZ, nextPeck, peckUntil, phase;
            public bool right, asleep, moving, placed;
            public int last;
        }

        readonly FarmScreen farm;
        readonly Emotes emotes;
        readonly List<Animal> animals = new List<Animal>();
        readonly System.Random rnd = new System.Random();
        float Rand(float a, float b) => a + (float)rnd.NextDouble() * (b - a);

        public Animals(FarmScreen farm, RectTransform layer, MapAnimal[] cast, Emotes emotes)
        {
            this.farm = farm; this.emotes = emotes;
            if (cast == null) return;
            for (int i = 0; i < cast.Length; i++)
            {
                var c = cast[i];
                if (c == null || !Kinds.TryGetValue(c.kind, out var k)) continue;
                var stand = Resources.Load<Sprite>("Map/" + c.kind);
                if (stand == null) continue;
                var a = new Animal
                {
                    id = c.kind + i, k = k, stand = stand, home = new Vector2(c.x, c.y), at = new Vector2(c.x, c.y), w = c.w, h = c.h,
                    right = c.flip, phase = Rand(0f, 6.28f), until = Time.unscaledTime + Rand(0.5f, 6f), nextPeck = Time.unscaledTime + Rand(0.3f, 2f),
                };
                var roam = new List<Vector2>();
                if (c.roam != null) foreach (var p in c.roam) roam.Add(p.V);
                if (roam.Count == 0) roam.Add(a.home);
                a.roam = roam.ToArray();
                a.walk = Strip("anim_" + c.kind + "_walk");
                a.sleep = Single("anim_" + c.kind + "_sleep");
                a.img = UI.Img(layer, null, Color.white, false, "Animal " + c.kind);
                a.img.raycastTarget = false;
                a.depth = a.img.gameObject.AddComponent<DepthKey>();
                ShowStand(a);
                animals.Add(a);
            }
        }

        static Sprite[] Strip(string name)
        {
            var s = UI.S(name);
            if (s == null) return null;
            var tex = s.texture;
            int fw = tex.width / 4;
            var frames = new Sprite[4];
            for (int i = 0; i < 4; i++) frames[i] = Sprite.Create(tex, new Rect(i * fw, 0, fw, tex.height), new Vector2(0.5f, FootPx / tex.height), 100);
            return frames;
        }

        static Sprite Single(string name)
        {
            var s = UI.S(name);
            if (s == null) return null;
            var tex = s.texture;
            return Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, FootPx / tex.height), 100);
        }

        // ---------------------------------------------------------------- drawing
        void Face(Animal a, float tilt = 0f)
        {
            // the art faces left; facing right is the mirror image (and a forward tilt mirrors with it)
            a.img.rectTransform.localScale = new Vector3(a.right ? -1 : 1, 1, 1);
            a.img.rectTransform.localRotation = Quaternion.Euler(0, 0, a.right ? -tilt : tilt);
        }

        void ShowStand(Animal a)
        {
            a.img.sprite = a.stand;
            a.img.rectTransform.anchorMin = a.img.rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            a.img.rectTransform.pivot = new Vector2(0.5f, 0f);
            a.img.rectTransform.sizeDelta = new Vector2(a.w, a.h) * farm.Scale;
            Face(a);
            Place(a);
        }

        void ShowWalk(Animal a, int frame, float lift)
        {
            if (a.walk == null) { ShowStand(a); return; }
            var s = a.walk[frame];
            float k = a.h / Figure;                          // the walking figure is as tall as the standing one
            a.img.sprite = s;
            a.img.rectTransform.pivot = s.pivot / s.rect.size;
            a.img.rectTransform.sizeDelta = new Vector2(s.rect.width, s.rect.height) * k * farm.Scale;
            Face(a);
            Place(a, lift);
        }

        void ShowSleep(Animal a)
        {
            if (a.sleep == null) { ShowStand(a); return; }
            var s = a.sleep;
            float width = a.w * a.k.sleepWidth;
            a.img.sprite = s;
            a.img.rectTransform.pivot = s.pivot / s.rect.size;
            a.img.rectTransform.sizeDelta = new Vector2(width, width * s.rect.height / s.rect.width) * farm.Scale;
            Face(a);
            Place(a);
        }

        void Place(Animal a, float lift = 0f)
        {
            a.img.rectTransform.anchoredPosition = farm.BgToWorld(a.at.x, a.at.y - lift);
            a.depth.y = a.at.y;
        }

        // ---------------------------------------------------------------- the day
        bool Asleep(Animal a, VillageTime t)
        {
            float bed = Mathf.Lerp(a.k.bed0, a.k.bed1, Routine.Hash(a.id, t.day, 41));
            float wake = Mathf.Lerp(a.k.wake0, a.k.wake1, Routine.Hash(a.id, t.day, 42));
            return t.hour >= bed || t.hour < wake;
        }

        public void Tick(VillageTime t)
        {
            float now = Time.unscaledTime, dt = Mathf.Min(Time.unscaledDeltaTime, 0.1f);
            foreach (var a in animals)
            {
                bool night = Asleep(a, t);
                if (!a.placed)
                {
                    // when the farm is first shown everyone is already where the time of day puts them
                    a.placed = true;
                    if (night) { a.at = a.home; a.asleep = true; a.nextZ = now + Rand(1f, 6f); ShowSleep(a); }
                    continue;
                }
                if (night && !a.asleep)
                {
                    // bedtime: back to its own place, then down to sleep
                    if (Vector2.Distance(a.at, a.home) > 1.5f) { a.target = a.home; a.moving = true; }
                    else { a.moving = false; a.asleep = true; a.nextZ = now + Rand(1f, 4f); ShowSleep(a); continue; }
                }
                else if (!night && a.asleep)
                {
                    a.asleep = false; a.until = now + Rand(1f, 4f); ShowStand(a);
                }

                if (a.asleep)
                {
                    if (now >= a.nextZ) { a.nextZ = now + Rand(6f, 12f); emotes.Show(a.img, a.h * 0.55f, "zzz", 2.6f); }
                    // slow breathing
                    float b = 1f + 0.025f * Mathf.Sin(now * 1.7f + a.phase);
                    a.img.rectTransform.localScale = new Vector3((a.right ? -1 : 1) * (2f - b), b, 1f);
                    continue;
                }
                if (a.moving) { Step(a, now, dt); continue; }
                if (now >= a.until) { Wander(a); continue; }
                Idle(a, now);
            }
        }

        /// <summary>Off to another of its places, not the one it just left.</summary>
        void Wander(Animal a)
        {
            if (a.roam.Length < 2) { a.until = Time.unscaledTime + Rand(a.k.rest0, a.k.rest1); return; }
            int next, tries = 0;
            do next = rnd.Next(a.roam.Length); while ((next == a.last || Vector2.Distance(a.roam[next], a.at) < 8f) && ++tries < 20);
            a.last = next;
            a.target = a.roam[next];
            a.moving = true;
        }

        void Step(Animal a, float now, float dt)
        {
            var d = a.target - a.at;
            float dist = d.magnitude, move = a.k.speed * dt;
            if (Mathf.Abs(d.x) > 0.5f) a.right = d.x > 0;
            if (dist <= move)
            {
                a.at = a.target; a.moving = false;
                a.until = now + Rand(a.k.rest0, a.k.rest1);
                ShowStand(a);
                return;
            }
            a.at += d / dist * move;
            if (a.k.swim)
            {
                // ducks and swans glide, bobbing on the water
                ShowStand(a);
                Place(a, 0.8f * Mathf.Sin(now * 2.2f + a.phase));
                Face(a, 2f * Mathf.Sin(now * 1.6f + a.phase));
                return;
            }
            a.clock += move * a.k.steps;
            ShowWalk(a, Mathf.FloorToInt(a.clock) % 4, a.k.peck ? 0f : 0.6f * Mathf.Abs(Mathf.Sin(a.clock * Mathf.PI)));
        }

        void Idle(Animal a, float now)
        {
            if (a.k.swim)
            {
                Place(a, 0.8f * Mathf.Sin(now * 2.2f + a.phase));
                Face(a, 2f * Mathf.Sin(now * 1.6f + a.phase));
                return;
            }
            if (a.k.peck)
            {
                // chickens peck at the ground: a quick dip forward, again and again
                if (now >= a.nextPeck) { a.peckUntil = now + 0.22f; a.nextPeck = now + Rand(0.45f, 1.6f); }
                Face(a, now < a.peckUntil ? 16f : 0f);
            }
        }
    }
}
