using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace FieldsOfHope
{
    /// <summary>Guided first-time tutorial in Baguio (flow steps 12-23). Progress is saved per step.</summary>
    public class Tutorial
    {
        class Step
        {
            public string text, target, waitFor;
            public Action enter;
            public Func<bool> autoDone;
            public bool closePanelOnNext;
        }

        GameApp App => GameApp.I;
        GameServer S => GameApp.I.Server;
        readonly List<Step> steps = new List<Step>();
        int index;
        RectTransform overlay;
        public bool Active { get; private set; }
        public bool WantsLettuceOnly => Active && index < steps.Count && steps[index].waitFor == "plant";

        public Tutorial()
        {
            void Add(string text, string target = null, string waitFor = null, Action enter = null, Func<bool> auto = null, bool close = false) =>
                steps.Add(new Step { text = text, target = target, waitFor = waitFor, enter = enter, autoDone = auto, closePanelOnNext = close });

            Add(null, null, "intro_done", () => App.Open(new DialoguePanel(
                "Welcome to Baguio City! Our community doesn't have enough fresh food right now. We need a farmer: grow crops suited to our cool climate, deliver them to families here, and help us become food secure. Can you help?",
                ("I'll help! Let's get started.", "icon_basket_reply", () => App.Fire("intro_done")),
                ("I've played before. Skip the tutorial.", "icon_speech", () => App.Message("Skip tutorial",
                    "Skip the tutorial? You can replay it from Settings at any time.", ("Skip", Finish), ("Keep the tutorial", Show))))));
            Add("These are your <b>coins</b>. You start with 300. Spend them on seeds, supplies and new plots.", "coins");
            Add("The <b>clock</b> follows real time. Each real day is a new game day with fresh requests and quests.", "clock");
            Add("The <b>Map</b> shows Baguio, Ilocos Norte and Davao City.", "map");
            Add("<b>Shop / Inventory</b>: buy seeds and supplies in the Community Shop.", "shop");
            Add("<b>Daily Quests</b> and Farming Suggestions live here.", "quests");
            Add("<b>Home</b> brings the view back to your farm. Drag the farm with your finger or mouse (or use the arrow keys) to look around, and pinch, scroll or tap <b>+</b> and <b>-</b> to zoom.", "home");
            Add("<b>Settings</b>: sound, timezone, tutorial replay and logout.", "settings");
            Add("Tap the <b>seed bag</b> in the hotbar to open your Inventory.", "seedbag", "open_inventory");
            Add("These are your seeds: Lettuce, Cabbage and Carrot. <b>A seed is used up when you plant it.</b>", null, null, null, null, true);
            Add("Tap an empty plot on your farm and plant <b>Lettuce</b>.", "plot", "plant");
            Add("Select the <b>Watering Can</b>, then tap your lettuce. Dry plots grow at half speed.", "can", "water");
            Add("The <b>progress bar</b> shows growth. You can leave the game: crops keep growing on real time.", "plot");
            Add("Your tutorial lettuce grows in 2 minutes instead of 10. Waiting...", "plot", null, null, () => S.Here.plots.Any(p => p.tutorial && p.state == PlotState.Ready));
            Add("It's ready! Select the <b>Harvest Basket</b> and tap the plot.", "basket", "harvest");
            Add(null, null, "said_yes", OpenCommunityQuestion);
            Add("This is a community request. <b>Deliver your 4 Lettuce.</b>", null, "deliver");
            Add("Delivery paid <b>coins, XP and Community Points</b>, and raised Baguio's food security!", "coins", null, () => App.CloseAllPanels());
            Add("Open the <b>Community Shop</b> and buy <b>Lettuce Seeds</b> (the cheapest seed).", "shop", "buy");
            Add("Every card shows price, climate, growth time, yield and profit. Purple tags show Community Points.", null, null, null, null, true);
            Add("Open <b>Daily Quests</b>.", "quests", "open_quests");
            Add("Quests and planting suggestions change every day. Claim rewards when a quest is complete.", null, null, null, null, true);
            Add("Open the <b>Map</b>.", "map", "open_map");
            Add("Ilocos Norte and Davao City are <b>locked</b>. Tap their pins to see what they need, then close the map.", null, "close_map");
        }

        void OpenCommunityQuestion()
        {
            App.Open(new DialoguePanel("Hi there! We're looking for fresh produce for the community. Would you like to sell your harvest?",
                ("Yes, I'd like to sell my harvest.", "icon_basket_reply", () => { S.EnsureTutorialRequest(); App.Open(new CommunityPanel()); App.Fire("said_yes"); }),
                ("Let me check my inventory first.", "icon_crate_reply", () => { App.Open(new InventoryPanel("Harvested Crops")); App.Toast("Your lettuce is here. Talk to the Community Member when you're ready."); }),
                ("Not right now.", "icon_speech", () => App.Toast("Tap the Community Member when you're ready to sell."))));
        }

        public void Begin()
        {
            End(false);
            Active = true;
            index = Normalize(S.Save.tutorialStep);
            App.GameAction += OnAction;
            overlay = UI.New("TutorialOverlay", App.TutorialLayer).Fill();
            Show();
        }

        int Normalize(int i)
        {
            var tut = S.Loc("baguio").plots.FirstOrDefault(p => p.tutorial);
            if (i >= 1 && i <= 7) return 1;
            if (i == 9) return 8;
            if (i >= 10 && i <= 14)
            {
                if (tut == null) return S.Count("crop_lettuce") >= 4 ? 15 : 10;
                if (tut.state == PlotState.Ready) return 14;
                return i <= 11 ? (tut.waterings > 0 ? 12 : 11) : 13;
            }
            if (i == 16) return 15;
            if (i == 19) return 20;
            if (i == 21 || i == 23) return 22;
            return Mathf.Clamp(i, 0, steps.Count - 1);
        }

        void OnAction(string evt)
        {
            if (!Active || index >= steps.Count) return;
            if (steps[index].waitFor == evt) Next();
            // "Not right now" closes the dialogue: offer it again so the tutorial can continue
            else if (steps[index].waitFor == "said_yes" && evt == "close_dialogue" && App.OpenPanel == null)
                App.StartCoroutine(ReopenLater());
        }

        System.Collections.IEnumerator ReopenLater()
        {
            yield return new WaitForSecondsRealtime(4f);
            if (Active && index < steps.Count && steps[index].waitFor == "said_yes" && App.OpenPanel == null) OpenCommunityQuestion();
        }

        void Next()
        {
            if (steps[index].closePanelOnNext) App.CloseAllPanels();
            index++;
            S.SetTutorialStep(index);
            if (index >= steps.Count) { Finish(); return; }
            Show();
        }

        void Show()
        {
            UI.Clear(overlay);
            var step = steps[index];
            step.enter?.Invoke();
            if (step.text == null) return;

            var hl = UI.New("Highlight", overlay);
            var bars = new Image[4];
            for (int i = 0; i < 4; i++) bars[i] = UI.Rect(hl, UI.Gold, "Edge");

            var box = UI.Sliced(overlay, "panel", null, 1f, "Callout");
            box.raycastTarget = true;
            box.Shadowed(5);
            var portrait = UI.Img(box.transform, "npc_portrait");
            portrait.rectTransform.At(0, 1, 26, -26, 110, 110, 0, 1);
            var t = UI.Label(box.transform, step.text, 25, UI.Ink, TextAnchor.UpperLeft);
            t.rectTransform.Fill(150, 30, 34, 76);
            if (step.autoDone != null)
                t.Live(() =>
                {
                    var p = S.Here.plots.FirstOrDefault(x => x.tutorial);
                    if (p != null && p.state == PlotState.Growing)
                        t.text = step.text + "\n<b>" + S.FormatDuration((p.total - p.progress) / (S.IsWatered(p) ? 1f : 0.5f)) + "</b> left.";
                    if (step.autoDone()) Next();
                }, 0.25f);
            if (step.waitFor == null && step.autoDone == null)
            {
                var next = UI.TextButton(box.transform, "Next", Next, "btn_green", 24);
                ((RectTransform)next.transform).At(1, 0, -30, 22, 150, 52, 1, 0);
            }
            var skip = UI.TextButton(box.transform, "Skip tutorial", () => App.Confirm("Skip tutorial",
                "Skip the rest of the tutorial? You can replay it from Settings at any time.", "Skip", () => Finish()), "btn", 20);
            ((RectTransform)skip.transform).At(0, 0, 150, 22, 190, 52, 0, 0);

            box.Live(() =>
            {
                // keep the callout clear of open panels: beside them when a panel is open, above the hotbar otherwise
                if (App.OpenPanel != null) box.rectTransform.At(0, 0.5f, 20, -40, 360, 470, 0, 0.5f);
                else box.rectTransform.At(0.5f, 0, 30, 250, 900, 210, 0.5f, 0);
                t.rectTransform.Fill(App.OpenPanel != null ? 30 : 150, App.OpenPanel != null ? 30 : 30, 30, 76);
                portrait.enabled = App.OpenPanel == null;
                PlaceHighlight(hl, bars, Target(step.target));
            }, 0.02f);
        }

        RectTransform Target(string key)
        {
            if (key == null || App.Farm == null) return null;
            if (key == "plot")
            {
                var p = S.Here.plots.FirstOrDefault(x => x.tutorial) ?? S.Here.plots.FirstOrDefault(x => x.state == PlotState.Empty);
                return p != null ? App.Farm.Plots[p.index].root : null;
            }
            return App.Farm.Targets.TryGetValue(key, out var rt) ? rt : null;
        }

        void PlaceHighlight(RectTransform hl, Image[] bars, RectTransform target)
        {
            bool show = target != null && target.gameObject.activeInHierarchy && App.OpenPanel == null;
            hl.gameObject.SetActive(show);
            if (!show) return;
            var corners = new Vector3[4];
            target.GetWorldCorners(corners);
            var min = (Vector2)overlay.InverseTransformPoint(corners[0]);
            var max = (Vector2)overlay.InverseTransformPoint(corners[2]);
            float pad = 8 + Mathf.Sin(Time.unscaledTime * 6) * 4, th = 6;
            min -= Vector2.one * pad; max += Vector2.one * pad;
            var size = max - min; var center = (min + max) / 2f;
            hl.anchorMin = hl.anchorMax = new Vector2(0.5f, 0.5f);
            hl.anchoredPosition = center; hl.sizeDelta = size;
            bars[0].rectTransform.At(0.5f, 1f, 0, 0, size.x, th, 0.5f, 1f);
            bars[1].rectTransform.At(0.5f, 0f, 0, 0, size.x, th, 0.5f, 0f);
            bars[2].rectTransform.At(0f, 0.5f, 0, 0, th, size.y, 0f, 0.5f);
            bars[3].rectTransform.At(1f, 0.5f, 0, 0, th, size.y, 1f, 0.5f);
        }

        void Finish()
        {
            End(true);
            var r = App.Act(tx => S.CompleteTutorial(tx), null, false);
            if (r.ok)
                App.Message("Tutorial complete!", r.message + "\n\nRandom events such as heavy rain and pests begin at Level 2. Keep Baguio fed, and work toward unlocking Ilocos Norte!", ("Let's farm!", null));
        }

        void End(bool closePanels)
        {
            if (Active) App.GameAction -= OnAction;
            Active = false;
            if (overlay != null) UnityEngine.Object.Destroy(overlay.gameObject);
            overlay = null;
            if (closePanels) App.CloseAllPanels();
        }
    }
}
