using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace FieldsOfHope
{
    /// <summary>
    /// A person who walks: south-east and north-east walk cycles (Resources/Art/walk_{who}_se/_ne.png, square frames made
    /// by Tools/slice_walk.py), mirrored for the other two diagonals, standing on frame 1. Positions are map px; the
    /// sprite sorts by its feet, or just behind a house while stepping through its door.
    /// </summary>
    public class Body
    {
        public const float Height = 74f;          // an adult villager is about this tall on the map (px)
        const float Figure = 0.84f;               // share of each walk frame the figure fills
        public const float Feet = 4f / 144f;      // the feet sit this far above the bottom of a walk frame
        const float StepsPerPx = 6.5f / 24f;      // walk-cycle frames per map px travelled

        public readonly Image img;
        readonly FarmScreen farm;
        readonly Sprite[] se, ne;
        readonly DepthKey depth;
        public readonly float size, bounce, head;
        float clock;
        public Vector2 at, facing = new Vector2(1, 1);
        public float? behind;                     // draw depth while inside a doorway
        public bool Ok => se != null && ne != null;

        public Body(FarmScreen farm, RectTransform layer, string who, float height)
        {
            this.farm = farm;
            se = Frames("walk_" + who + "_se", 144);
            ne = Frames("walk_" + who + "_ne", 144);
            img = UI.Img(layer, null, Color.white, true, "Walker " + who);
            img.raycastTarget = false;                    // never in the way of tapping a plot
            size = Height * height / Figure * farm.Scale;
            img.rectTransform.At(0.5f, 0.5f, 0, 0, size, size, 0.5f, Feet);
            bounce = 1.2f * height;
            head = Height * height + 2f;
            depth = img.gameObject.AddComponent<DepthKey>();
        }

        public static Sprite[] Frames(string name, int frame)
        {
            var strip = UI.S(name);
            if (strip == null) return null;
            var tex = strip.texture;
            int h = tex.height, n = Mathf.Max(1, tex.width / h);
            var frames = new Sprite[n];
            for (int i = 0; i < n; i++) frames[i] = Sprite.Create(tex, new Rect(i * h, 0, h, h), new Vector2(0.5f, 0f), 100);
            return frames;
        }

        public bool Hidden { get => !img.enabled; set => img.enabled = !value; }

        /// <summary>One step of walking toward <paramref name="target"/>; true on arrival.</summary>
        public bool WalkTo(Vector2 target, float speed, float dt)
        {
            var step = target - at;
            float d = step.magnitude, move = speed * dt;
            if (d <= move) { at = target; Place(); return true; }
            facing = step;
            at += step / d * move;
            clock += move * StepsPerPx;
            var frames = facing.y > 0 ? se : ne;
            int f = Mathf.FloorToInt(clock) % frames.Length;
            // the body rises a little on the passing frames (1 and 3) and dips when a foot lands
            Show(frames[f], f % 2 == 1 ? bounce : 0f, facing.x >= 0);
            return false;
        }

        /// <summary>Standing still, facing <paramref name="toward"/> (map px direction) or the way they were going.</summary>
        public void Stand(Vector2? toward = null)
        {
            if (toward.HasValue && toward.Value.sqrMagnitude > 0.01f) facing = toward.Value;
            Show((facing.y > 0 ? se : ne)[1], 0f, facing.x >= 0);
        }

        /// <summary>A pose from another strip (work animations), drawn <paramref name="scale"/> times a walk frame's size.</summary>
        public void Pose(Sprite s, float scale, float feet, bool east)
        {
            img.sprite = s;
            img.rectTransform.sizeDelta = new Vector2(size * scale, size * scale);
            img.rectTransform.pivot = new Vector2(0.5f, feet);
            img.rectTransform.localScale = new Vector3(east ? 1 : -1, 1, 1);
            Place();
        }

        void Show(Sprite s, float lift, bool east)
        {
            img.sprite = s;
            img.rectTransform.sizeDelta = new Vector2(size, size);
            img.rectTransform.pivot = new Vector2(0.5f, Feet);
            img.rectTransform.localScale = new Vector3(east ? 1 : -1, 1, 1);
            Place(lift);
        }

        void Place(float lift = 0f)
        {
            img.rectTransform.anchoredPosition = farm.BgToWorld(at.x, at.y - lift);
            depth.y = behind ?? at.y;
        }
    }

    /// <summary>
    /// Villagers who walk the village. Each picks somewhere to go that suits them — the store, the notice board, a bench,
    /// the well, the bridge, a neighbour's door, or just a stroll — walks there along the paths, stays a while, and moves on.
    /// They stop to chat when they meet, greet the villagers they pass and step indoors (through the door, hidden by the
    /// house) for a while. They keep the village's routine (Routine): home at dusk and to bed, out again in the morning,
    /// to the campfire on some evenings, indoors from the rain (the boy would rather play in it). Paths and places come
    /// from the location's MapLayout.
    /// </summary>
    public class Walkers
    {
        enum Doing { Walk, Stay, Inside, Chat, Greet, Camp }

        class Walker
        {
            public Body body;
            public string who;
            public float speed;
            public bool nightOwl, kid;
            public MapSpot home, last;
            public readonly List<Vector2> route = new List<Vector2>();
            public Action arrive;
            public Doing doing;
            public Routine.Want plan = Routine.Want.Out;   // what they are doing it for: out and about, home for the night...
            public float until, chatCool, greetCool, lookAt, emoteAt;
            public Walker partner;
            public bool talker, placed;
        }

        readonly VillagePaths paths;
        readonly Villagers villagers;
        readonly Emotes emotes;
        readonly Campfire fire;
        readonly List<Walker> walkers = new List<Walker>();
        readonly System.Random rnd = new System.Random();
        float Rand(float a, float b) => a + (float)rnd.NextDouble() * (b - a);

        /// <param name="layer">the map's depth-sorted layer, so walkers pass behind trees and houses</param>
        /// <param name="cast">who walks, from the location's map layout; each starts somewhere on their old route</param>
        public Walkers(FarmScreen farm, RectTransform layer, MapWalker[] cast, VillagePaths paths, Villagers villagers, Emotes emotes,
                       Campfire fire, Predicate<string> skip = null)
        {
            this.paths = paths; this.villagers = villagers; this.emotes = emotes; this.fire = fire;
            if (cast == null) return;
            foreach (var c in cast)
            {
                if (c.route == null || c.route.Length < 2 || (skip != null && skip(c.who))) continue;
                var body = new Body(farm, layer, c.who, c.height);
                if (!body.Ok) { UnityEngine.Object.Destroy(body.img.gameObject); continue; }   // art not in this build: nobody walks
                var start = c.route[rnd.Next(c.route.Length)].V;
                var w = new Walker
                {
                    body = body, who = c.who, nightOwl = c.height > 0.9f, kid = Villagers.Kids.Contains(c.who),
                    speed = c.who == "lola" ? 16f : c.who == "boy" ? 27f : 22f + Rand(-2f, 2f),
                    chatCool = Rand(3f, 10f), greetCool = Rand(2f, 8f),
                };
                body.at = start;
                body.Stand(new Vector2(1, 1));
                // home is the door nearest where they used to walk
                float best = float.MaxValue;
                foreach (var s in paths.Spots)
                    if (s.kind == "door") { float d = Vector2.Distance(s.V, c.route[0].V); if (d < best) { best = d; w.home = s; } }
                // the first real decision waits for the first tick, which knows the time of day
                w.doing = Doing.Stay; w.until = Time.unscaledTime + Rand(0f, 3f); w.lookAt = w.until;
                walkers.Add(w);
            }
        }

        // ---------------------------------------------------------------- choosing what to do
        static float Liking(string who, string kind)
        {
            switch (who)
            {
                case "lola": return kind == "bench" ? 3f : kind == "store" ? 2f : kind == "door" ? 1.5f : kind == "board" ? 1.5f : 1f;
                case "boy": return kind == "view" ? 3f : kind == "well" ? 1.5f : kind == "board" ? 0.5f : 1f;
                case "woman": return kind == "store" ? 3f : kind == "well" ? 2f : kind == "board" ? 2f : 1f;
                default: return kind == "store" ? 2f : kind == "door" ? 2f : kind == "bench" ? 0.5f : 1f;
            }
        }

        /// <summary>Where the routine wants them now, if they can get there.</summary>
        Routine.Want Desired(Walker w, VillageTime t)
        {
            var want = Routine.Wanted(w.who, t, w.nightOwl, false, w.kid);
            if (want == Routine.Want.Camp && (fire == null || fire.Claim(w) < 0)) want = Routine.Want.Home;
            if (want == Routine.Want.Shelter) want = Routine.Want.Indoors;      // strollers just go in
            if ((want == Routine.Want.Home || want == Routine.Want.Indoors) && Nearest(w.body.at, "door") == null) want = Routine.Want.Out;
            return want;
        }

        void Decide(Walker w, float now, VillageTime t)
        {
            var want = Desired(w, t);
            if (want != Routine.Want.Camp) fire?.Release(w);
            w.plan = want;
            switch (want)
            {
                case Routine.Want.Home:
                case Routine.Want.Indoors:
                    var door = want == Routine.Want.Indoors ? Nearest(w.body.at, "door") ?? w.home : w.home ?? Nearest(w.body.at, "door");
                    if (t.rain && rnd.NextDouble() < 0.6) Pending(w, "excl", now + 0.2f);
                    Go(w, paths.Route(w.body.at, door), () => Enter(w, door, now));
                    return;
                case Routine.Want.Camp:
                    int seat = fire.Claim(w);
                    if (rnd.NextDouble() < 0.4) Pending(w, "note", now + Rand(0.3f, 1.5f));
                    Go(w, paths.Route(w.body.at, fire.Seat(seat)), () =>
                    {
                        w.doing = Doing.Camp; w.until = Time.unscaledTime + Rand(0.5f, 3f);
                        w.body.Stand(fire.Center - w.body.at);
                    });
                    return;
                case Routine.Want.Play:
                    // a child in the rain: from puddle to puddle, laughing
                    var to = w.body.at + new Vector2(Rand(-90f, 90f), Rand(-45f, 45f));
                    if (rnd.NextDouble() < 0.4) Pending(w, rnd.NextDouble() < 0.6 ? "laugh" : "note", now + 0.2f);
                    Go(w, new List<Vector2> { to }, () => { w.doing = Doing.Stay; w.until = Time.unscaledTime + Rand(0.6f, 2f); w.body.Stand(); });
                    return;
            }
            // somewhere nobody else is standing, not where we just were
            var options = new List<(MapSpot spot, float weight)>();
            float total = 1.2f;                                       // a plain stroll along the paths
            foreach (var s in paths.Spots)
            {
                if (s == w.last || s.kind == "campfire" || (s.kind == "door" && rnd.NextDouble() < 0.5)) continue;
                bool taken = false;
                foreach (var o in walkers) if (o != w && o.last == s && o.doing == Doing.Stay) taken = true;
                if (taken) continue;
                float weight = Liking(w.who, s.kind) / (1f + Vector2.Distance(s.V, w.body.at) / 700f);   // nearer places a bit more often
                options.Add((s, weight)); total += weight;
            }
            float pick = (float)rnd.NextDouble() * total;
            foreach (var (spot, weight) in options)
            {
                pick -= weight;
                if (pick > 0) continue;
                w.last = spot;
                if (spot.kind == "door") Go(w, paths.Route(w.body.at, spot), () => Enter(w, spot, Time.unscaledTime));
                else Go(w, paths.Route(w.body.at, spot), () => Stay(w, spot));
                return;
            }
            w.last = null;
            Go(w, paths.Route(w.body.at, paths.RandomPathPoint(rnd)), () => { w.doing = Doing.Stay; w.until = Time.unscaledTime + Rand(1.5f, 4f); });
        }

        MapSpot Nearest(Vector2 at, string kind)
        {
            MapSpot best = null; float d = float.MaxValue;
            foreach (var s in paths.Spots)
                if (s.kind == kind && (kind != "door" || (s.entry != null && s.entry.Length > 0))) { float e = Vector2.Distance(s.V, at); if (e < d) { d = e; best = s; } }
            return best;
        }

        void Go(Walker w, List<Vector2> route, Action arrive)
        {
            w.route.Clear(); w.route.AddRange(route);
            w.arrive = arrive; w.doing = Doing.Walk;
        }

        void Stay(Walker w, MapSpot s)
        {
            float now = Time.unscaledTime;
            w.doing = Doing.Stay;
            w.until = now + (s.kind == "bench" ? Rand(7f, 14f) : s.kind == "store" ? Rand(6f, 12f) : s.kind == "well" ? Rand(4f, 8f) : Rand(5f, 11f));
            w.lookAt = now + Rand(2f, 4f);
            string[] say = s.kind == "store" ? new[] { "coin", "talk", "food" } : s.kind == "board" ? new[] { "question", "excl", "talk" }
                         : s.kind == "bench" ? new[] { "note", "heart", "talk" } : s.kind == "well" ? new[] { "sweat", "note" } : new[] { "heart", "note", "excl" };
            if (rnd.NextDouble() < 0.7) { w.talker = false; Pending(w, say[rnd.Next(say.Length)], now + Rand(0.5f, 2f)); }
            // at the bench the one sitting there says hello back
            if (s.kind == "bench" && villagers.Greet(s.V, 60f, out var where)) w.body.Stand(where - w.body.at);
        }

        readonly Dictionary<Walker, string> pendingEmote = new Dictionary<Walker, string>();
        void Pending(Walker w, string kind, float at) { pendingEmote[w] = kind; w.emoteAt = at; }

        void Enter(Walker w, MapSpot door, float now)
        {
            if (door.entry == null || door.entry.Length == 0) { Stay(w, door); return; }
            // up to the door, then through it drawn behind the house, which hides them; then out of sight
            Go(w, new List<Vector2> { door.entry[0].V }, () =>
            {
                w.body.behind = door.depth;
                var inside = new List<Vector2>();
                for (int i = 1; i < door.entry.Length; i++) inside.Add(door.entry[i].V);
                Go(w, inside, () =>
                {
                    w.body.Hidden = true;
                    w.doing = Doing.Inside;
                    w.last = door;
                    w.until = Time.unscaledTime + Rand(10f, 30f);
                });
            });
        }

        void Leave(Walker w, VillageTime t)
        {
            var door = w.last;
            w.body.Hidden = false;
            if (door?.entry == null || door.entry.Length == 0) { w.body.behind = null; Decide(w, Time.unscaledTime, t); return; }
            var steps = new List<Vector2>();
            for (int i = door.entry.Length - 2; i >= 0; i--) steps.Add(door.entry[i].V);
            // back out through the doorway, then in front of the house again on the doorstep
            Go(w, steps, () => { w.body.behind = null; Go(w, new List<Vector2> { door.V }, () => Decide(w, Time.unscaledTime, t)); });
        }

        /// <summary>Whether someone indoors stays in: at home for the night, sheltering from the rain, or a visit not over yet.</summary>
        bool StaysIn(Walker w, Routine.Want want, float now)
        {
            switch (want)
            {
                case Routine.Want.Home: return w.home == null || w.last == w.home;
                case Routine.Want.Indoors: return true;
                case Routine.Want.Out: return w.plan == Routine.Want.Out && now < w.until;
                default: return false;
            }
        }

        /// <summary>Puts someone straight where the time of day wants them (when the farm is first shown).</summary>
        void Place(Walker w, VillageTime t)
        {
            var want = Desired(w, t);
            w.plan = want;
            if (want == Routine.Want.Home || want == Routine.Want.Indoors)
            {
                var door = want == Routine.Want.Home ? w.home ?? Nearest(w.body.at, "door") : Nearest(w.body.at, "door");
                w.last = door;
                w.body.at = door.entry[door.entry.Length - 1].V; w.body.behind = door.depth; w.body.Stand(new Vector2(1, -1));
                w.body.Hidden = true; w.doing = Doing.Inside; w.until = Time.unscaledTime + Rand(10f, 30f);
            }
            else if (want == Routine.Want.Camp)
            {
                w.body.at = fire.Seat(fire.Claim(w)); w.body.Stand(fire.Center - w.body.at);
                w.doing = Doing.Camp; w.until = Time.unscaledTime + Rand(0.5f, 4f);
            }
        }

        /// <summary>Who is in which house, and whether they are asleep (for the lights and the zzz).</summary>
        public void CountIndoors(Dictionary<MapSpot, (int awake, int asleep)> houses, VillageTime t)
        {
            foreach (var w in walkers)
            {
                if (w.doing != Doing.Inside || w.last == null) continue;
                houses.TryGetValue(w.last, out var n);
                if (w.plan == Routine.Want.Home && Routine.Asleep(w.who, t.day, t.hour, w.kid)) n.asleep++; else n.awake++;
                houses[w.last] = n;
            }
        }

        // ---------------------------------------------------------------- every frame
        public void Tick(VillageTime t)
        {
            float now = Time.unscaledTime, dt = Mathf.Min(Time.unscaledDeltaTime, 0.1f);
            foreach (var w in walkers)
            {
                if (!w.placed) { w.placed = true; Place(w, t); }
                w.chatCool -= dt; w.greetCool -= dt;
                if (pendingEmote.TryGetValue(w, out var kind) && now >= w.emoteAt) { emotes.Show(w.body.img, w.body.head, kind); pendingEmote.Remove(w); }
                switch (w.doing)
                {
                    case Doing.Walk: Walk(w, t, now, dt); break;
                    case Doing.Stay:
                        if (now >= w.lookAt && w.plan == Routine.Want.Out) { w.body.Stand(new Vector2(-w.body.facing.x, w.body.facing.y)); w.lookAt = now + Rand(2.5f, 5f); }   // looks around
                        if (now >= w.until || Desired(w, t) != w.plan) Decide(w, now, t);
                        break;
                    case Doing.Inside:
                        var want = Desired(w, t);
                        if (StaysIn(w, want, now)) { if (want != Routine.Want.Out) w.plan = want; }
                        else Leave(w, t);
                        break;
                    case Doing.Camp:
                        if (Desired(w, t) != Routine.Want.Camp) { fire.Release(w); Decide(w, now, t); break; }
                        if (now >= w.until)
                        {
                            // round the fire: stories, songs and laughter
                            w.until = now + Rand(3f, 7f);
                            Pending(w, new[] { "talk", "talk", "laugh", "laugh", "note", "heart" }[rnd.Next(6)], now + Rand(0f, 0.6f));
                            w.body.Stand(fire.Center - w.body.at);
                        }
                        break;
                    case Doing.Chat:
                        if (now >= w.emoteAt && w.talker) { emotes.Show(w.body.img, w.body.head, Emotes.Chatter[rnd.Next(Emotes.Chatter.Length)]); w.emoteAt = now + Rand(2.4f, 3.4f); }
                        if (now >= w.until) { w.doing = Doing.Walk; w.chatCool = Rand(20f, 40f); }
                        break;
                    case Doing.Greet:
                        if (now >= w.until) w.doing = Doing.Walk;
                        break;
                }
            }
        }

        void Walk(Walker w, VillageTime t, float now, float dt)
        {
            if (w.route.Count == 0) { var done = w.arrive; w.arrive = null; if (done != null) done(); else Decide(w, now, t); return; }
            if (w.body.WalkTo(w.route[0], w.speed, dt)) w.route.RemoveAt(0);
            if (w.body.behind != null || w.body.Hidden) return;            // stepping through a door: no stopping
            // the routine changed on the way (night fell, the rain came): off there instead
            if (Desired(w, t) != w.plan) { Decide(w, now, t); return; }
            if (w.plan != Routine.Want.Out) return;                         // going home or to the fire: no dawdling

            // meeting someone on the way: stop and chat for a bit
            if (w.chatCool <= 0)
                foreach (var o in walkers)
                {
                    if (o == w || o.doing != Doing.Walk || o.plan != Routine.Want.Out || o.chatCool > 0 || o.body.Hidden || o.body.behind != null) continue;
                    if (Vector2.Distance(o.body.at, w.body.at) > 30f) continue;
                    if (rnd.NextDouble() < 0.55)
                    {
                        float until = now + Rand(3f, 6f);
                        foreach (var (a, b, first) in new[] { (w, o, true), (o, w, false) })
                        {
                            a.doing = Doing.Chat; a.until = until; a.partner = b; a.talker = true;
                            a.emoteAt = now + (first ? 0.2f : 1.4f);
                            a.body.Stand(b.body.at - a.body.at);
                        }
                    }
                    else { w.chatCool = Rand(8f, 15f); o.chatCool = Rand(8f, 15f); }
                    return;
                }
            // passing a villager: a wave, and they answer
            if (w.greetCool <= 0)
            {
                w.greetCool = Rand(6f, 12f);
                if (rnd.NextDouble() < 0.45 && villagers.Greet(w.body.at, 34f, out var where))
                {
                    w.doing = Doing.Greet; w.until = now + 1.4f;
                    w.body.Stand(where - w.body.at);
                    emotes.Show(w.body.img, w.body.head, rnd.NextDouble() < 0.6 ? "wave" : "note");
                    w.greetCool = Rand(14f, 24f);
                }
            }
        }
    }
}
