using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

namespace FieldsOfHope
{
    /// <summary>Client root: owns the canvas, screens, panels, modals and the connection to the game server.</summary>
    public class GameApp : MonoBehaviour
    {
        public static GameApp I { get; private set; }
        public GameServer Server { get; private set; }
        public RectTransform CanvasRect, ScreenLayer, PanelLayer, PopupLayer, TutorialLayer, ToastLayer, FadeLayer;
        public FarmScreen Farm { get; private set; }
        public Tutorial Tutorial { get; private set; }
        public Panel OpenPanel { get; private set; }
        public event Action Changed;
        public event Action<string> GameAction;      // tutorial hooks: "plant", "open_inventory", ...

        const string TokenKey = "foh_session";
        readonly Queue<ServerMsg> levelUps = new Queue<ServerMsg>();
        int modalCount;
        float saveTimer;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Boot()
        {
            if (FindAnyObjectByType<GameApp>() == null) new GameObject("Fields of Hope").AddComponent<GameApp>();
        }

        /// <summary>Tests point the app at a temporary data folder.</summary>
        public static string DataRootOverride;

        void Awake()
        {
            if (I != null && I != this) { Destroy(gameObject); return; }
            I = this;
            DontDestroyOnLoad(gameObject);
            Application.targetFrameRate = 60;
            Server = new GameServer(DataRootOverride);
            GameServer.OpenAllLocations = DataRootOverride == null && PreviewGuard.OpenAllLocations;
            Sfx.Init(gameObject);
            Music.Init(this);
            BuildCanvas();
        }

        void Start()
        {
            if (!PreviewGuard.Apply(CanvasRect)) return;   // evaluation builds: watermark, expiry
            ShowTitle();
        }

        void BuildCanvas()
        {
            var cgo = new GameObject("Canvas", typeof(RectTransform));
            cgo.transform.SetParent(transform, false);
            var canvas = cgo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;
            var scaler = cgo.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            // Expand keeps the whole 1920x1080 layout on screen at any aspect: wide phones, 4:3 tablets, short browser windows
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
            cgo.AddComponent<GraphicRaycaster>();
            CanvasRect = (RectTransform)cgo.transform;
            UI.Rect(CanvasRect, new Color32(36, 58, 30, 255), "Backdrop").rectTransform.Fill();
            ScreenLayer = UI.New("Screens", CanvasRect).Fill();
            PanelLayer = UI.New("Panels", CanvasRect).Fill();
            TutorialLayer = UI.New("Tutorial", CanvasRect).Fill();
            PopupLayer = UI.New("Popups", CanvasRect).Fill();
            ToastLayer = UI.New("Toasts", CanvasRect).Fill();
            FadeLayer = UI.New("Fades", CanvasRect).Fill();

            var events = FindAnyObjectByType<EventSystem>();
            if (events == null)
            {
                var es = new GameObject("EventSystem", typeof(EventSystem), typeof(InputSystemUIInputModule));
                es.transform.SetParent(transform, false);
                events = es.GetComponent<EventSystem>();
            }
            // fingers wobble more than a mouse: a bigger threshold keeps taps from turning into tiny drags
            if (Application.isMobilePlatform) events.pixelDragThreshold = Mathf.Max(10, Screen.height / 40);
#if UNITY_WEBGL && !UNITY_EDITOR
            WebGLInput.mobileKeyboardSupport = true;   // login/register fields open the phone keyboard
#endif
        }

        void Update()
        {
            if (Server.Save == null) return;
            Server.Advance();
            DrainOutbox();
            saveTimer += Time.unscaledDeltaTime;
            if (saveTimer >= 60f) { saveTimer = 0; Server.Persist(); }   // J.2 periodic sync
        }

        void OnDestroy() { if (I == this) I = null; }

        void OnApplicationPause(bool paused) { if (paused && Server?.Save != null) Server.Persist(); }
        // the browser tab hiding or losing focus is the last reliable moment to save
        void OnApplicationFocus(bool focused) { if (!focused && Server?.Save != null) Server.Persist(); }
        void OnApplicationQuit() { if (Server?.Save != null) Server.Persist(); }

        // ------------------------------------------------------------------ screens
        void ClearAll()
        {
            CloseAllPanels();
            UI.Clear(ScreenLayer); UI.Clear(PopupLayer); UI.Clear(TutorialLayer); UI.Clear(ToastLayer);
            modalCount = 0;
            levelUps.Clear();
            Farm = null;
            Tutorial = null;
        }

        static readonly Color FadeColor = new Color32(36, 58, 30, 255);

        public void ShowTitle()
        {
            ClearAll();
            new TitleScreen().Build(ScreenLayer);
            UI.FadeFrom(FadeLayer, FadeColor);
        }

        public void PressStart()
        {
            var stored = PlayerPrefs.GetString(TokenKey, "");
            if (!string.IsNullOrEmpty(stored))
            {
                var r = Server.ResumeSession(stored, out var token);
                if (r.ok) { PlayerPrefs.SetString(TokenKey, token); PlayerPrefs.Save(); EnterGame(); return; }
                PlayerPrefs.DeleteKey(TokenKey);
                ShowAuth(r.message);
                return;
            }
            ShowAuth(null);
        }

        public void ShowAuth(string notice, string prefillUser = null)
        {
            ClearAll();
            new AuthScreen(notice, prefillUser).Build(ScreenLayer);
            UI.FadeFrom(FadeLayer, FadeColor, 0.25f);
        }

        public void LoginSucceeded(string token)
        {
            PlayerPrefs.SetString(TokenKey, token);
            PlayerPrefs.Save();
            EnterGame();
        }

        void EnterGame()
        {
            ClearAll();
            Sfx.Enabled = Server.Save.sound;
            Farm = new FarmScreen();
            Farm.Build(ScreenLayer);
            UI.FadeFrom(FadeLayer, FadeColor, 0.5f);
            Tutorial = new Tutorial();
            if (!Server.Save.tutorialDone) Tutorial.Begin();
            else if (Server.AwaySummary.Count > 0)
                Message("Welcome back, " + Server.Save.username + "!", "While you were away:\n\n- " + string.Join("\n- ", Server.AwaySummary), ("Let's farm!", null));
            else
                Toast("Welcome back, " + Server.Save.username + "!");
            Changed?.Invoke();
        }

        public void ReturnToTitle()
        {
            Server.Suspend();
            ShowTitle();
        }

        public void Logout()
        {
            Server.Logout();
            PlayerPrefs.DeleteKey(TokenKey);
            PlayerPrefs.Save();
            ShowTitle();
        }

        public void Quit()
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }

        // ------------------------------------------------------------------ actions
        /// <summary>Runs a server action with a fresh transaction id and shows the confirmed result.</summary>
        public Result Act(Func<string, Result> action, string tutorialEvent = null, bool toastSuccess = true, Action successSound = null)
        {
            var r = action(Guid.NewGuid().ToString("N"));
            if (!r.ok)
            {
                Sfx.Error();
                if (r.message == "STORAGE_FULL") StorageFull();
                else if (!string.IsNullOrEmpty(r.message)) Toast(r.message, true);
            }
            else
            {
                (successSound ?? Sfx.Good)();
                if (toastSuccess && !string.IsNullOrEmpty(r.message)) Toast(r.message);
                if (tutorialEvent != null) Fire(tutorialEvent);
            }
            NotifyChanged();
            return r;
        }

        public void NotifyChanged()
        {
            Changed?.Invoke();
            OpenPanel?.Refresh();
        }

        public void Fire(string evt) => GameAction?.Invoke(evt);

        public void StorageFull()
        {
            Message("Storage full", "There is no room in storage. The crop stays ready in the field, so nothing is lost.",
                ("Sell at market", () => Open(new InventoryPanel("Harvested Crops"))),
                ("Deliver", () => Open(new CommunityPanel())),
                ("Upgrade storage", () => Open(new ShopPanel("Upgrades"))));
        }

        // ------------------------------------------------------------------ panels
        public void Open(Panel p)
        {
            CloseAllPanels();
            OpenPanel = p;
            p.Build(PanelLayer);
            p.Refresh();
            Fire("open_" + p.Key);
        }

        public void Close(Panel p)
        {
            if (OpenPanel != p) return;
            OpenPanel = null;
            p.OnClose();
            if (p.Root != null) { p.Root.gameObject.SetActive(false); Destroy(p.Root.gameObject); }
            Fire("close_" + p.Key);
        }

        public void CloseAllPanels()
        {
            if (OpenPanel != null) Close(OpenPanel);
            UI.Clear(PanelLayer);
        }

        public bool ModalOpen => modalCount > 0;

        // ------------------------------------------------------------------ toasts and modals
        public void Toast(string text, bool error = false)
        {
            var bg = UI.Sliced(ToastLayer, "field", error ? new Color(1f, 0.82f, 0.78f) : Color.white, 1f, "Toast");
            var t = UI.Label(bg.transform, text, 26, error ? UI.Red : UI.Ink, TextAnchor.MiddleCenter, true);
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            float w = Mathf.Min(1100, t.preferredWidth + 60);
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.rectTransform.Fill(24, 6, 24, 6);
            bg.rectTransform.At(0.5f, 1f, 0, -150 - ToastLayer.childCount * 6, w, 60);
            bg.Shadowed();
            var cg = bg.gameObject.AddComponent<CanvasGroup>();
            cg.blocksRaycasts = false;
            float born = Time.unscaledTime;
            bg.Live(() =>
            {
                float age = Time.unscaledTime - born;
                cg.alpha = age < 2.4f ? Mathf.Clamp01(age / 0.12f) : 1f - (age - 2.4f) / 0.6f;
                // drops in with a little bounce
                float a = Mathf.Clamp01(age / 0.25f), x = a - 1f;
                bg.rectTransform.localScale = Vector3.one * Mathf.LerpUnclamped(0.85f, 1f, 1f + 2.7f * x * x * x + 1.7f * x * x);
                if (age > 3f) Destroy(bg.gameObject);
            }, 0.03f);
            // older toasts slide down the stack
            for (int i = 0; i < ToastLayer.childCount - 1; i++)
            {
                var older = (RectTransform)ToastLayer.GetChild(i);
                older.anchoredPosition += new Vector2(0, -66);
            }
        }

        RectTransform ModalShell(float w, float h, string title, out RectTransform content)
        {
            modalCount++;
            var dim = UI.Rect(PopupLayer, new Color(0, 0, 0, 0.55f), "Modal");
            dim.rectTransform.Fill();
            dim.raycastTarget = true;
            var panel = UI.Sliced(dim.transform, "panel", null, 1f, "Panel");
            panel.rectTransform.At(0.5f, 0.5f, 0, 0, w, h);
            panel.Shadowed(6);
            var ribbon = UI.Sliced(panel.transform, "ribbon");
            ribbon.rectTransform.At(0.5f, 1f, 0, 30, Mathf.Min(w - 60, 640), 66, 0.5f, 1f);
            var tt = UI.Label(ribbon.transform, title.ToUpperInvariant(), 30, UI.Cream, TextAnchor.MiddleCenter, true);
            tt.rectTransform.Fill(30, 4, 30, 6);
            tt.resizeTextForBestFit = true; tt.resizeTextMaxSize = 30; tt.resizeTextMinSize = 16;
            tt.Outlined();
            content = UI.New("Content", panel.transform).Fill(48, 56, 40, 36);
            panel.PopIn(0.8f, 0.28f);
            return dim.rectTransform;
        }

        void CloseModal(RectTransform m)
        {
            modalCount = Mathf.Max(0, modalCount - 1);
            Destroy(m.gameObject);
            if (modalCount == 0 && levelUps.Count > 0) ShowLevelUp(levelUps.Dequeue());
        }

        public void Message(string title, string body, params (string label, Action action)[] buttons)
        {
            float h = 330 + Mathf.Max(0, body.Split('\n').Length - 3) * 30 + (buttons.Length > 2 ? 30 : 0);
            var m = ModalShell(820, Mathf.Min(900, h), title, out var content);
            var t = UI.Label(content, body, 28, UI.Ink, TextAnchor.UpperLeft);
            t.rectTransform.Fill(10, 0, 10, 80);
            var row = UI.HRow(content, 64, 14);
            row.childAlignment = TextAnchor.MiddleCenter;
            var rrt = (RectTransform)row.transform;
            rrt.At(0.5f, 0f, 0, 6, 760, 64, 0.5f, 0f);
            if (buttons.Length == 0) buttons = new (string, Action)[] { ("OK", null) };
            for (int i = 0; i < buttons.Length; i++)
            {
                var (label, action) = buttons[i];
                var b = UI.TextButton(row.transform, label, () => { CloseModal(m); action?.Invoke(); }, i == 0 ? "btn_green" : "btn", 24);
                b.Layout(Mathf.Min(320, 60 + label.Length * 14), 60);
            }
        }

        public void Confirm(string title, string body, string ok, Action onOk, string cancel = "Cancel") =>
            Message(title, body, (ok, onOk), (cancel, null));

        void ShowLevelUp(ServerMsg msg)
        {
            Sfx.Fanfare();
            var m = ModalShell(760, 470, msg.title, out var content);
            var star = UI.Img(content, "icon_xp");
            star.rectTransform.At(0.5f, 1f, 0, 0, 96, 96, 0.5f, 1f);
            star.Live(() => star.rectTransform.localRotation = Quaternion.Euler(0, 0, Mathf.Sin(Time.unscaledTime * 3) * 8), 0.02f);
            var t = UI.Label(content, msg.body, 26, UI.Ink, TextAnchor.UpperCenter);
            t.rectTransform.Fill(10, 110, 10, 80);
            var b = UI.TextButton(content, "Continue", () => { CloseModal(m); NotifyChanged(); }, "btn_green", 28);
            ((RectTransform)b.transform).At(0.5f, 0f, 0, 6, 260, 64, 0.5f, 0f);
        }

        void DrainOutbox()
        {
            while (Server.Outbox.Count > 0)
            {
                var msg = Server.Outbox.Dequeue();
                if (msg.kind == "levelup")
                {
                    if (modalCount == 0) ShowLevelUp(msg); else levelUps.Enqueue(msg);
                    continue;
                }
                if (msg.kind == "warn") Sfx.Alert();
                if (Server.Save.notifications || msg.kind != "info") Farm?.Notifications.Push(msg);
            }
        }
    }

    /// <summary>A full panel opened from the HUD. Only one is open at a time.</summary>
    public abstract class Panel
    {
        protected GameApp App => GameApp.I;
        protected GameServer S => GameApp.I.Server;
        public RectTransform Root;
        public abstract string Key { get; }
        public abstract void Build(RectTransform layer);
        public virtual void Refresh() { }
        public virtual void OnClose() { }
        public void Close() => App.Close(this);

        /// <summary>Dimmed backdrop + parchment frame + ribbon title + close button. Returns the content area.</summary>
        protected RectTransform Frame(RectTransform layer, string title, float w, float h, float yOffset = -20)
        {
            var dim = UI.Rect(layer, new Color(0.95f, 0.95f, 0.85f, 0.35f), "Panel " + Key);
            dim.rectTransform.Fill();
            dim.raycastTarget = true;
            Root = dim.rectTransform;
            var panel = UI.Sliced(dim.transform, "panel", null, 1f, "Frame");
            panel.rectTransform.At(0.5f, 0.5f, 0, yOffset, w, h);
            panel.raycastTarget = true;
            panel.Shadowed(6);
            panel.PopIn();
            var ribbon = UI.Sliced(panel.transform, "ribbon");
            ribbon.rectTransform.At(0.5f, 1f, 0, 34, Mathf.Min(w - 80, 560), 70, 0.5f, 1f);
            var t = UI.Label(ribbon.transform, title.ToUpperInvariant(), 32, UI.Cream, TextAnchor.MiddleCenter, true);
            t.rectTransform.Fill(30, 4, 30, 8);
            t.Outlined();
            var close = UI.TextButton(panel.transform, "X", Close, "btn", 30);
            ((RectTransform)close.transform).At(1f, 1f, 18, 18, 64, 60, 1f, 1f);
            return UI.New("Content", panel.transform).Fill(50, 60, 46, 40);
        }
    }
}
