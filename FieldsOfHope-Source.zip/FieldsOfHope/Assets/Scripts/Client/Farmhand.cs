using System;
using System.Collections.Generic;
using UnityEngine;

namespace FieldsOfHope
{
    /// <summary>
    /// The farm's farmhand does every job on the plots by hand. He notices each change the player makes (planting,
    /// watering, harvesting, clearing land, digging a trench, fertilising or protecting a crop), walks to that plot and
    /// does the work — kneels to plant, pours from the can, picks the crop into his basket, swings the axe, digs. Until
    /// he has finished, the plot keeps showing how it was, and the effects (splash, coins, produce flying to the crate)
    /// play as he finishes. The game itself has already recorded the action; this is what the player sees happen.
    /// He lives in the house by the field (out of its door, back in at night), and between jobs he looks after the crops.
    /// Sprites: walk_farmer_se/_ne and farmhand_{plant,water,harvest,chop,dig}.png (Tools/slice_farmhand.py).
    /// </summary>
    public class Farmhand
    {
        enum Job { Plant, Water, Harvest, Chop, Dig, Tend }
        enum State { Inside, Walking, Working, Idle }

        const float Stroll = 30f, Hurry = 62f;              // map px per second
        const float WorkScale = 192f / 160f, WorkFeet = 4f / 192f;   // farmhand_* frames vs walk frames (Tools/slice_farmhand.py)

        readonly FarmScreen farm;
        readonly Emotes emotes;
        readonly Body body;
        readonly MapSpot home;
        readonly List<Vector2> approach = new List<Vector2>();
        readonly Dictionary<Job, Sprite[]> strips = new Dictionary<Job, Sprite[]>();
        readonly System.Random rnd = new System.Random();
        float Rand(float a, float b) => a + (float)rnd.NextDouble() * (b - a);
        GameServer S => GameApp.I.Server;

        // what the player sees on each plot while a job on it is still to be done
        Plot[] last, shown;
        float[] lastProgress;
        int[] pending;
        readonly List<(int plot, Job job)> queue = new List<(int, Job)>();
        readonly Dictionary<int, Action> after = new Dictionary<int, Action>();
        readonly Dictionary<int, float> afterSince = new Dictionary<int, float>();

        State state;
        readonly List<Vector2> route = new List<Vector2>();
        Action arrive;
        bool inField, goingHome;
        (int plot, Job job) current;
        Sprite[] strip;
        bool east;
        float workStart, frameTime, until, nextIdle, outSince;
        int loops, lastFrame;

        public bool Active { get; }

        /// <summary>His house, while he is in it, and whether he is asleep (for the lights and the zzz).</summary>
        public void CountIndoors(Dictionary<MapSpot, (int awake, int asleep)> houses, VillageTime t)
        {
            if (!Active || state != State.Inside || !body.Hidden) return;
            houses.TryGetValue(home, out var n);
            if (Routine.Asleep("farmhand", t.day, t.hour, false) && (t.Dark || t.LateNight)) n.asleep++; else n.awake++;
            houses[home] = n;
        }

        public Farmhand(FarmScreen farm, RectTransform layer, MapLayout map, VillagePaths paths, Emotes emotes)
        {
            this.farm = farm; this.emotes = emotes;
            if (map.farmhand == null || string.IsNullOrEmpty(map.farmhand.home)) return;
            home = paths.Spots.Find(s => s.name == map.farmhand.home);
            if (home == null || home.entry == null || home.entry.Length == 0) return;
            if (map.farmhand.approach != null) foreach (var p in map.farmhand.approach) approach.Add(p.V);
            body = new Body(farm, layer, "farmer", 1f);
            foreach (Job j in Enum.GetValues(typeof(Job)))
            {
                var f = Body.Frames("farmhand_" + (j == Job.Tend ? "plant" : j.ToString().ToLowerInvariant()), 192);
                if (f != null) strips[j] = f;
            }
            if (!body.Ok || strips.Count < 5) { UnityEngine.Object.Destroy(body.img.gameObject); return; }
            Active = true;
            Watch();
            // by day he is already out in the field; at night, at home
            var t = farm.VillageClock;
            if (t.Dark || t.LateNight) { body.at = Inside; body.behind = home.depth; body.Hidden = true; state = State.Inside; until = Time.unscaledTime + 5f; }
            else { body.at = Post; inField = true; body.Stand(new Vector2(-1, -1)); state = State.Idle; nextIdle = outSince = Time.unscaledTime; nextIdle += Rand(2f, 6f); }
        }

        // ---------------------------------------------------------------- the field, in map px
        Vector2 Centre(int i) => farm.WorldToBg(farm.Plots[i].root.anchoredPosition);
        float HalfW => FarmScreen.PlotWidth / 2f / farm.Scale;
        float HalfH => HalfW / 2f;
        Vector2 RightCorner => Centre(3) + new Vector2(HalfW + 16f, 8f);                     // just outside the field's right corner
        Vector2 EdgeOfRow(int r) => Centre(r * 4 + 3) + new Vector2(HalfW / 2f + 6f, HalfH / 2f + 3f);   // outside the open front edge
        Vector2 Post => EdgeOfRow(1) + new Vector2(10f, 5f);                                 // where he waits
        Vector2 Inside => home.entry != null && home.entry.Length > 0 ? home.entry[home.entry.Length - 1].V : home.V;

        /// <summary>Where he stands to work a plot: on its upper edge, the plot in front of him at his feet.</summary>
        Vector2 WorkSpot(int i, out bool facingEast)
        {
            int c = i % 4, r = i / 4;
            var centre = Centre(i);
            // the upper-left edge (facing south-east) or the upper-right edge (facing south-west), whichever is nearer;
            // the field's two back edges are fenced, so on those he stands just inside the plot instead
            bool seOpen = c != 0, swOpen = r != 0;
            var se = centre + new Vector2(-HalfW, -HalfH) * (seOpen ? 0.45f : 0.2f);
            var sw = centre + new Vector2(HalfW, -HalfH) * (swOpen ? 0.45f : 0.2f);
            if (seOpen == swOpen) facingEast = Vector2.Distance(se, body.at) <= Vector2.Distance(sw, body.at);
            else facingEast = seOpen;
            return facingEast ? se : sw;
        }

        // ---------------------------------------------------------------- noticing what the player did
        static Plot Copy(Plot p) => JsonUtility.FromJson<Plot>(JsonUtility.ToJson(p));

        static bool Same(Plot a, Plot b) =>
            a.state == b.state && a.crop == b.crop && a.waterings == b.waterings && a.obstacle == b.obstacle && a.trench == b.trench &&
            a.fertilized == b.fertilized && a.mulch == b.mulch && a.cover == b.cover && a.pest == b.pest && a.harvestsLeft == b.harvestsLeft;

        static List<Job> Jobs(Plot was, Plot now)
        {
            var jobs = new List<Job>();
            if (was.state == PlotState.Blocked && now.state != PlotState.Blocked) jobs.Add(Job.Chop);
            if (was.state == PlotState.Cleared && now.state == PlotState.Empty) jobs.Add(Job.Dig);          // bought: the soil is turned
            if (was.state == PlotState.Ready && (now.state != PlotState.Ready || now.harvestsLeft < was.harvestsLeft)) jobs.Add(Job.Harvest);
            if (was.state <= PlotState.Empty && now.state == PlotState.Growing) jobs.Add(Job.Plant);
            if (was.state == PlotState.Growing && now.state == PlotState.Growing && now.waterings > was.waterings) jobs.Add(Job.Water);
            if (!was.trench && now.trench) jobs.Add(Job.Dig);
            if (was.state == now.state && ((!was.fertilized && now.fertilized) || (!was.mulch && now.mulch) || (!was.cover && now.cover) || (was.pest && !now.pest)))
                jobs.Add(Job.Tend);
            return jobs;
        }

        void Watch()
        {
            var plots = S.Here.plots;
            last = new Plot[plots.Count]; shown = new Plot[plots.Count]; lastProgress = new float[plots.Count]; pending = new int[plots.Count];
            for (int i = 0; i < plots.Count; i++) { last[i] = Copy(plots[i]); lastProgress[i] = plots[i].progress; }
        }

        /// <summary>Runs before the plots draw each frame: turns every change the player made into a job.</summary>
        public void Observe()
        {
            if (!Active) return;
            var plots = S.Here.plots;
            if (plots.Count != last.Length) Watch();
            for (int i = 0; i < plots.Count; i++)
            {
                var p = plots[i];
                if (!Same(p, last[i]))
                {
                    var jobs = Jobs(last[i], p);
                    if (jobs.Count > 0)
                    {
                        if (pending[i] == 0) { shown[i] = last[i]; shown[i].progress = lastProgress[i]; }   // keep showing it as it was
                        foreach (var j in jobs) { queue.Add((i, j)); pending[i]++; }
                    }
                    last[i] = Copy(p);
                }
                lastProgress[i] = p.progress;
            }
            // effects for plots nobody has to walk to (the action changed nothing he works on) play straight away
            if (after.Count > 0)
                foreach (var k in new List<int>(after.Keys))
                    if ((k >= pending.Length || pending[k] == 0) && Time.unscaledTime - afterSince[k] > 0.3f) Finish(k);
        }

        /// <summary>The plot as the player should see it right now.</summary>
        public Plot Shown(int i) => Active && i < shown.Length && pending[i] > 0 ? shown[i] : S.PlotAt(i);

        /// <summary>Plays <paramref name="effect"/> when he finishes the work on that plot.</summary>
        public void Then(int plot, Action effect)
        {
            if (!Active) { effect(); return; }
            after[plot] = after.TryGetValue(plot, out var a) ? a + effect : effect;
            if (!afterSince.ContainsKey(plot)) afterSince[plot] = Time.unscaledTime;
        }

        void Finish(int plot)
        {
            if (after.TryGetValue(plot, out var a)) { after.Remove(plot); afterSince.Remove(plot); a?.Invoke(); }
        }

        // ---------------------------------------------------------------- doing it
        public void Tick(VillageTime t)
        {
            if (!Active) return;
            float now = Time.unscaledTime, dt = Mathf.Min(Time.unscaledDeltaTime, 0.1f);
            switch (state)
            {
                case State.Inside:
                    if (queue.Count > 0 || (now >= until && !t.Dark && !t.LateNight)) LeaveHouse();
                    break;
                case State.Walking:
                    // on his way home and a job comes in: straight back to the field
                    if (goingHome && queue.Count > 0 && body.behind == null)
                    {
                        goingHome = false;
                        Go(new List<Vector2> { RightCorner, Post }, () => { inField = true; NextJob(); });
                        break;
                    }
                    if (route.Count == 0) { var a = arrive; arrive = null; state = State.Idle; a?.Invoke(); break; }
                    if (body.WalkTo(route[0], queue.Count > 0 ? Hurry : Stroll, dt)) route.RemoveAt(0);
                    break;
                case State.Working: Work(now); break;
                case State.Idle: Idle(t, now); break;
            }
        }

        void Go(List<Vector2> points, Action then) { route.Clear(); route.AddRange(points); arrive = then; state = State.Walking; }

        void LeaveHouse()
        {
            body.Hidden = false;
            var pts = new List<Vector2>();
            for (int i = home.entry.Length - 2; i >= 0; i--) pts.Add(home.entry[i].V);
            Go(pts, () =>
            {
                body.behind = null;
                var toField = new List<Vector2> { home.V };
                toField.AddRange(approach);
                toField.Add(RightCorner); toField.Add(Post);
                Go(toField, () => { inField = true; outSince = Time.unscaledTime; NextJob(); });
            });
        }

        void GoHome()
        {
            inField = false; goingHome = true;
            var pts = new List<Vector2> { Post, RightCorner };
            for (int i = approach.Count - 1; i >= 0; i--) pts.Add(approach[i]);
            pts.Add(home.V);
            Go(pts, () =>
            {
                goingHome = false;
                if (queue.Count > 0) { LeaveHouseFromDoorstep(); return; }
                Go(new List<Vector2> { home.entry[0].V }, () =>
                {
                    body.behind = home.depth;
                    var inside = new List<Vector2>();
                    for (int i = 1; i < home.entry.Length; i++) inside.Add(home.entry[i].V);
                    Go(inside, () => { body.Hidden = true; state = State.Inside; until = Time.unscaledTime + Rand(30f, 90f); });
                });
            });
        }

        void LeaveHouseFromDoorstep()
        {
            var toField = new List<Vector2>(approach) { RightCorner, Post };
            Go(toField, () => { inField = true; NextJob(); });
        }

        /// <summary>The nearest waiting job next; nothing waiting, he idles.</summary>
        void NextJob()
        {
            if (queue.Count == 0) { state = State.Idle; nextIdle = Time.unscaledTime + Rand(2f, 5f); return; }
            if (!inField) { if (state != State.Walking) LeaveHouseFromDoorstep(); return; }
            int best = 0; float d = float.MaxValue;
            for (int k = 0; k < queue.Count; k++)
            {
                float e = Vector2.Distance(Centre(queue[k].plot), body.at);
                if (e < d) { d = e; best = k; }
            }
            current = queue[best];
            queue.RemoveAt(best);
            var spot = WorkSpot(current.plot, out east);
            Go(new List<Vector2> { spot }, StartWork);
        }

        void StartWork()
        {
            state = State.Working;
            strip = strips[current.job];
            workStart = Time.unscaledTime;
            frameTime = current.job == Job.Plant || current.job == Job.Tend ? 0.22f : 0.18f;
            loops = queue.Count > 3 ? 1 : 2;                 // a long list of jobs: quicker at each one
            lastFrame = -1;
        }

        void Work(float now)
        {
            int f = Mathf.FloorToInt((now - workStart) / frameTime);
            if (f >= strip.Length * loops)
            {
                Done();
                return;
            }
            int frame = f % strip.Length;
            if (frame != lastFrame)
            {
                lastFrame = frame;
                body.Pose(strip[frame], WorkScale, WorkFeet, east);
                // the axe bites and the rock or stump shudders
                if (current.job == Job.Chop && frame == 2) farm.Plots[current.plot].Jolt();
            }
        }

        void Done()
        {
            int i = current.plot;
            var pv = farm.Plots[i];
            if (current.job == Job.Plant || current.job == Job.Dig || current.job == Job.Tend) pv.Burst(PlotView.SoilColors, 7, 0.55f);
            if (i < pending.Length && pending[i] > 0 && --pending[i] == 0) { shown[i] = null; Finish(i); }
            if (current.job == Job.Harvest && rnd.NextDouble() < 0.35) emotes.Show(body.img, body.head, rnd.NextDouble() < 0.5 ? "heart" : "note");
            if (current.job == Job.Chop && rnd.NextDouble() < 0.5) emotes.Show(body.img, body.head, "sweat");
            body.Stand();
            NextJob();
        }

        void Idle(VillageTime t, float now)
        {
            if (queue.Count > 0) { NextJob(); return; }
            if (!inField) return;
            if (now < nextIdle) return;
            // evening: home for the night; otherwise now and then a rest indoors
            if (t.Dark || t.LateNight || (now - outSince > Rand(60f, 120f) && rnd.NextDouble() < 0.3)) { GoHome(); return; }
            nextIdle = now + Rand(4f, 9f);
            double r = rnd.NextDouble();
            if (r < 0.5)
            {
                // checks on a crop: kneels by it, looks it over
                var plots = S.Here.plots;
                var choices = new List<int>();
                for (int i = 0; i < plots.Count; i++) if (plots[i].state >= PlotState.Empty) choices.Add(i);
                if (choices.Count == 0) return;
                int p = choices[rnd.Next(choices.Count)];
                var spot = WorkSpot(p, out east);
                Go(new List<Vector2> { spot }, () =>
                {
                    body.Pose(strips[Job.Plant][0], WorkScale, WorkFeet, east);
                    state = State.Idle; nextIdle = Time.unscaledTime + Rand(2f, 3.5f);
                    var growing = S.PlotAt(p).state;
                    if (rnd.NextDouble() < 0.6) emotes.Show(body.img, body.head * 0.7f, growing == PlotState.Ready ? "excl" : growing == PlotState.Growing ? "heart" : "question");
                });
            }
            else if (r < 0.75) Go(new List<Vector2> { Post }, () => { body.Stand(new Vector2(-1, -1)); state = State.Idle; nextIdle = Time.unscaledTime + Rand(3f, 6f); });
            else { body.Stand(new Vector2(-body.facing.x, body.facing.y)); if (rnd.NextDouble() < 0.4) emotes.Show(body.img, body.head, "note"); }
        }
    }
}
