using System.Collections.Generic;
using UnityEngine;

namespace FieldsOfHope
{
    /// <summary>Tiny synthesized sound effects (no audio assets needed). Respects the Sound setting.</summary>
    public static class Sfx
    {
        public static bool Enabled = true;
        static AudioSource source;
        static readonly Dictionary<string, AudioClip> clips = new Dictionary<string, AudioClip>();

        public static void Init(GameObject host)
        {
            if (Object.FindAnyObjectByType<AudioListener>() == null) host.AddComponent<AudioListener>();
            source = host.AddComponent<AudioSource>();
            source.playOnAwake = false;
            source.volume = 0.35f;
        }

        static AudioClip Tone(string key, float[] freqs, float noteLen, float decay = 6f, bool square = false)
        {
            if (clips.TryGetValue(key, out var c)) return c;
            const int rate = 22050;
            int per = (int)(rate * noteLen);
            var data = new float[per * freqs.Length];
            for (int n = 0; n < freqs.Length; n++)
                for (int i = 0; i < per; i++)
                {
                    float t = i / (float)rate;
                    float w = Mathf.Sin(2 * Mathf.PI * freqs[n] * t);
                    if (square) w = Mathf.Sign(w) * 0.5f;
                    data[n * per + i] = w * Mathf.Exp(-decay * t) * 0.6f;
                }
            c = AudioClip.Create(key, data.Length, 1, rate, false);
            c.SetData(data, 0);
            clips[key] = c;
            return c;
        }

        static AudioClip Synth(string key, float seconds, System.Func<float, float> wave)
        {
            if (clips.TryGetValue(key, out var c)) return c;
            const int rate = 22050;
            var data = new float[(int)(rate * seconds)];
            for (int i = 0; i < data.Length; i++) data[i] = wave(i / (float)rate);
            c = AudioClip.Create(key, data.Length, 1, rate, false);
            c.SetData(data, 0);
            clips[key] = c;
            return c;
        }

        static void Play(AudioClip c) { if (Enabled && source != null) source.PlayOneShot(c); }

        /// <summary>Soft soil pat followed by a little rising "sprout" note.</summary>
        public static void Plant()
        {
            var rnd = new System.Random(3);
            float lp = 0;
            Play(Synth("plant", 0.32f, t =>
            {
                // low-passed noise = a muffled pat of soil
                lp += 0.12f * ((float)rnd.NextDouble() * 2f - 1f - lp);
                float pat = lp * 2.4f * Mathf.Exp(-28f * t) * Mathf.Clamp01(t / 0.003f);
                // a soft sine that glides upward, like a sprout popping up
                float s = t - 0.06f, sprout = 0;
                if (s > 0)
                {
                    float f = Mathf.Lerp(420f, 700f, Mathf.Clamp01(s / 0.1f));
                    sprout = Mathf.Sin(2 * Mathf.PI * f * s) * 0.32f * Mathf.Exp(-14f * s) * Mathf.Clamp01(s / 0.01f);
                }
                return pat + sprout;
            }));
        }

        public static void Click() => Play(Tone("click", new[] { 660f }, 0.05f, 40f, true));
        public static void Good() => Play(Tone("good", new[] { 523f, 784f }, 0.08f, 18f));
        public static void Coin() => Play(Tone("coin", new[] { 988f, 1319f }, 0.07f, 14f, true));
        public static void Error() => Play(Tone("error", new[] { 220f, 180f }, 0.09f, 10f, true));
        public static void Fanfare() => Play(Tone("fanfare", new[] { 523f, 659f, 784f, 1047f }, 0.11f, 7f));
        public static void Alert() => Play(Tone("alert", new[] { 880f, 660f, 880f }, 0.08f, 12f, true));
    }
}
