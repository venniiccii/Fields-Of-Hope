using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace FieldsOfHope
{
    /// <summary>Small uGUI construction kit: every screen in the game is built from code with these helpers.</summary>
    public static class UI
    {
        public static readonly Color Ink = new Color32(74, 46, 24, 255);
        public static readonly Color Cream = new Color32(255, 242, 208, 255);
        public static readonly Color Gold = new Color32(255, 214, 92, 255);
        public static readonly Color Purple = new Color32(138, 92, 214, 255);
        public static readonly Color Red = new Color32(200, 64, 48, 255);
        public static readonly Color Green = new Color32(70, 140, 50, 255);
        public static readonly Color Muted = new Color32(130, 100, 70, 255);

        static Font font;
        public static Font Font
        {
            get
            {
                if (font == null) font = Resources.Load<Font>("Fonts/Fredoka-SemiBold");
                if (font == null) font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                return font;
            }
        }

        static readonly Dictionary<string, Sprite> sprites = new Dictionary<string, Sprite>();

        public static Sprite S(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            if (sprites.TryGetValue(name, out var s)) return s;
            s = Resources.Load<Sprite>("Art/" + name);
            if (s == null) Debug.LogWarning("Missing sprite Art/" + name);
            sprites[name] = s;
            return s;
        }

        /// <summary>9-slice copy of a sprite; border is (left, bottom, right, top) in texture pixels.</summary>
        public static Sprite Nine(string name, Vector4 border)
        {
            string key = name + "#" + border;
            if (sprites.TryGetValue(key, out var s)) return s;
            var src = S(name);
            if (src == null) return null;
            s = Sprite.Create(src.texture, src.rect, new Vector2(0.5f, 0.5f), 100, 0, SpriteMeshType.FullRect, border);
            sprites[key] = s;
            return s;
        }

        public static readonly Dictionary<string, Vector4> Borders = new Dictionary<string, Vector4>
        {
            { "panel", new Vector4(34, 28, 20, 22) }, { "ribbon", new Vector4(28, 22, 28, 22) }, { "row", new Vector4(14, 14, 14, 14) },
            { "card", new Vector4(16, 16, 16, 16) }, { "tab", new Vector4(14, 14, 14, 14) }, { "tab_on", new Vector4(14, 14, 14, 14) },
            { "btn", new Vector4(16, 16, 16, 16) }, { "btn_green", new Vector4(16, 16, 16, 16) }, { "bar_bg", new Vector4(7, 7, 7, 7) },
            { "bar_fill", new Vector4(7, 7, 7, 7) }, { "tag_cp", new Vector4(10, 10, 10, 10) }, { "field", new Vector4(14, 14, 14, 14) },
            { "reply", new Vector4(28, 22, 28, 22) }, { "reply_hi", new Vector4(28, 22, 28, 22) }, { "notif_card", new Vector4(24, 22, 70, 22) },
            { "nameplate", new Vector4(22, 14, 22, 14) },
        };

        // ------------------------------------------------------------------ rect helpers
        public static RectTransform New(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.layer = 5;
            var rt = (RectTransform)go.transform;
            rt.SetParent(parent, false);
            return rt;
        }

        public static RectTransform Fill(this RectTransform rt, float left = 0, float top = 0, float right = 0, float bottom = 0)
        {
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
            rt.offsetMin = new Vector2(left, bottom); rt.offsetMax = new Vector2(-right, -top);
            return rt;
        }

        /// <summary>Anchors to a point of the parent (0..1) and places the pivot there with an offset in canvas units (y up).</summary>
        public static RectTransform At(this RectTransform rt, float ax, float ay, float x, float y, float w, float h, float px = -1, float py = -1)
        {
            rt.anchorMin = rt.anchorMax = new Vector2(ax, ay);
            rt.pivot = new Vector2(px < 0 ? ax : px, py < 0 ? ay : py);
            rt.anchoredPosition = new Vector2(x, y);
            rt.sizeDelta = new Vector2(w, h);
            return rt;
        }

        /// <summary>Top-left mockup coordinates (y down) on a 1920x1080 reference.</summary>
        public static RectTransform TL(this RectTransform rt, float x, float y, float w, float h) => rt.At(0, 1, x, -y, w, h);
        public static RectTransform TR(this RectTransform rt, float right, float y, float w, float h) => rt.At(1, 1, -right, -y, w, h);
        public static RectTransform BL(this RectTransform rt, float x, float bottom, float w, float h) => rt.At(0, 0, x, bottom, w, h);
        public static RectTransform BR(this RectTransform rt, float right, float bottom, float w, float h) => rt.At(1, 0, -right, bottom, w, h);

        public static RectTransform Size(this RectTransform rt, float w, float h) { rt.sizeDelta = new Vector2(w, h); return rt; }

        public static LayoutElement Layout(this Component c, float prefW = -1, float prefH = -1, float flexW = -1, float flexH = -1)
        {
            var le = (c.TryGetComponent<LayoutElement>(out var existing) ? existing : c.gameObject.AddComponent<LayoutElement>());
            le.preferredWidth = prefW; le.preferredHeight = prefH; le.flexibleWidth = flexW; le.flexibleHeight = flexH;
            return le;
        }

        // ------------------------------------------------------------------ widgets
        public static Image Img(Transform parent, string sprite, Color? color = null, bool preserve = true, string name = null)
        {
            var rt = New(name ?? sprite ?? "Image", parent);
            var img = rt.gameObject.AddComponent<Image>();
            img.sprite = S(sprite);
            img.color = color ?? Color.white;
            img.preserveAspect = preserve;
            img.raycastTarget = false;
            return img;
        }

        public static Image Sliced(Transform parent, string sprite, Color? color = null, float scale = 1f, string name = null)
        {
            var rt = New(name ?? sprite, parent);
            var img = rt.gameObject.AddComponent<Image>();
            img.sprite = Borders.TryGetValue(sprite, out var b) ? Nine(sprite, b) : S(sprite);
            img.type = Image.Type.Sliced;
            img.pixelsPerUnitMultiplier = 1f / scale;
            img.color = color ?? Color.white;
            img.raycastTarget = false;
            return img;
        }

        public static Image Rect(Transform parent, Color color, string name = "Rect")
        {
            var rt = New(name, parent);
            var img = rt.gameObject.AddComponent<Image>();
            img.color = color;
            img.raycastTarget = false;
            return img;
        }

        public static Text Label(Transform parent, string text, int size, Color color, TextAnchor anchor = TextAnchor.MiddleCenter, bool bold = false, string name = "Text")
        {
            var rt = New(name, parent);
            var t = rt.gameObject.AddComponent<Text>();
            t.font = Font;
            t.text = text;
            t.fontSize = size;
            t.color = color;
            t.alignment = anchor;
            t.fontStyle = bold ? FontStyle.Bold : FontStyle.Normal;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.supportRichText = true;
            t.raycastTarget = false;
            return t;
        }

        public static T Outlined<T>(this T g, Color? color = null, float d = 2f) where T : Graphic
        {
            var o = g.gameObject.AddComponent<Outline>();
            o.effectColor = color ?? new Color(0.18f, 0.1f, 0.04f, 1f);
            o.effectDistance = new Vector2(d, -d);
            return g;
        }

        public static T Shadowed<T>(this T g, float d = 3f) where T : Graphic
        {
            var s = g.gameObject.AddComponent<Shadow>();
            s.effectColor = new Color(0, 0, 0, 0.45f);
            s.effectDistance = new Vector2(d, -d);
            return g;
        }

        public static Button Clickable(this Graphic g, Action onClick, bool sound = true)
        {
            g.raycastTarget = true;
            var b = (g.gameObject.TryGetComponent<Button>(out var existing) ? existing : g.gameObject.AddComponent<Button>());
            b.targetGraphic = g;
            var cb = b.colors;
            cb.highlightedColor = new Color(1.08f, 1.05f, 0.95f);
            cb.pressedColor = new Color(0.82f, 0.78f, 0.72f);
            cb.disabledColor = new Color(0.6f, 0.6f, 0.6f, 0.75f);
            cb.colorMultiplier = 1.1f;
            b.colors = cb;
            b.onClick.AddListener(() => { if (sound) Sfx.Click(); onClick?.Invoke(); });
            g.gameObject.AddComponent<PressBounce>();
            return b;
        }

        public static Button TextButton(Transform parent, string label, Action onClick, string style = "btn", int size = 26, Color? textColor = null, bool sound = true)
        {
            var bg = Sliced(parent, style, null, 1f, "Button " + label);
            var t = Label(bg.transform, label, size, textColor ?? Cream, TextAnchor.MiddleCenter, true);
            t.rectTransform.Fill(10, 4, 10, 4);
            t.Outlined(new Color(0.15f, 0.08f, 0.03f, 0.8f), 1.5f);
            return bg.Clickable(onClick, sound);
        }

        public static void SetInteractable(this Button b, bool on, string label = null)
        {
            b.interactable = on;
            if (label != null) { var t = b.GetComponentInChildren<Text>(); if (t != null) t.text = label; }
        }

        public static (Image bg, Image fill) Bar(Transform parent, Color? fill = null)
        {
            var bg = Sliced(parent, "bar_bg", null, 1f, "Bar");
            var f = Sliced(bg.transform, "bar_fill", fill ?? Color.white, 1f, "Fill");
            f.rectTransform.Fill(2, 2, 2, 2);
            f.rectTransform.anchorMax = new Vector2(0, 1);
            return (bg, f);
        }

        public static void SetBar(Image fill, float t)
        {
            var rt = fill.rectTransform;
            rt.anchorMax = new Vector2(Mathf.Clamp01(t), 1);
            fill.enabled = t > 0.001f;
        }

        public static ScrollRect Scroll(Transform parent, out RectTransform content, float spacing = 8, int padding = 6)
        {
            var root = New("Scroll", parent);
            var sr = root.gameObject.AddComponent<ScrollRect>();
            var vp = New("Viewport", root).Fill();
            vp.gameObject.AddComponent<RectMask2D>();
            var hit = vp.gameObject.AddComponent<Image>(); hit.color = new Color(0, 0, 0, 0);
            content = New("Content", vp);
            content.anchorMin = new Vector2(0, 1); content.anchorMax = new Vector2(1, 1); content.pivot = new Vector2(0.5f, 1);
            content.sizeDelta = Vector2.zero;
            var vl = content.gameObject.AddComponent<VerticalLayoutGroup>();
            vl.spacing = spacing; vl.padding = new RectOffset(padding, padding + 6, padding, padding);
            vl.childControlHeight = true; vl.childControlWidth = true; vl.childForceExpandHeight = false; vl.childForceExpandWidth = true;
            content.gameObject.AddComponent<ContentSizeFitter>().verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            sr.viewport = vp; sr.content = content; sr.horizontal = false; sr.movementType = ScrollRect.MovementType.Clamped;
            sr.scrollSensitivity = 40;
            return sr;
        }

        public static HorizontalLayoutGroup HRow(Transform parent, float height, float spacing = 8, string name = "Row")
        {
            var rt = New(name, parent);
            var h = rt.gameObject.AddComponent<HorizontalLayoutGroup>();
            h.spacing = spacing; h.childAlignment = TextAnchor.MiddleLeft;
            h.childControlWidth = true; h.childControlHeight = true; h.childForceExpandWidth = false; h.childForceExpandHeight = false;
            rt.Layout(-1, height);
            return h;
        }

        public static void Clear(Transform t)
        {
            for (int i = t.childCount - 1; i >= 0; i--)
            {
                var go = t.GetChild(i).gameObject;
                go.SetActive(false);   // hide now so layouts rebuilt this frame ignore it
                UnityEngine.Object.Destroy(go);
            }
        }

        /// <summary>
        /// A full-screen layer drawn <paramref name="k"/> times smaller: its children keep their corner layout but come out smaller.
        /// </summary>
        public static RectTransform Scaled(RectTransform parent, float k, string name)
        {
            var rt = New(name, parent);
            rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
            rt.localScale = Vector3.one * k;
            rt.Live(() => rt.sizeDelta = parent.rect.size / k, 0.1f);   // follows window resizes and rotation
            return rt;
        }

        public static Live Live(this Component c, Action update, float interval = 0.25f)
        {
            var l = c.gameObject.AddComponent<Live>();
            l.update = update; l.interval = interval;
            update();
            return l;
        }

        /// <summary>Springs a panel in: scales up from <paramref name="from"/> with a slight overshoot while fading in.</summary>
        public static void PopIn(this Component c, float from = 0.86f, float duration = 0.24f)
        {
            var rt = (RectTransform)c.transform;
            // not "??": Unity's missing-component placeholder isn't C# null, so it must be checked with Unity's == operator
            var cg = c.GetComponent<CanvasGroup>();
            if (cg == null) cg = c.gameObject.AddComponent<CanvasGroup>();
            float born = Time.unscaledTime;
            Live l = null;
            l = c.Live(() =>
            {
                float a = Mathf.Clamp01((Time.unscaledTime - born) / duration), x = a - 1f, s = 1.7f;
                rt.localScale = Vector3.one * Mathf.LerpUnclamped(from, 1f, 1f + (s + 1f) * x * x * x + s * x * x);
                cg.alpha = Mathf.Clamp01(a * 2.5f);
                if (a >= 1f && l != null) { rt.localScale = Vector3.one; cg.alpha = 1f; l.enabled = false; }
            }, 0f);
        }

        /// <summary>Fades a full-screen colour away; used when switching screens.</summary>
        public static void FadeFrom(RectTransform layer, Color color, float duration = 0.35f)
        {
            var veil = Rect(layer, color, "Fade");
            veil.rectTransform.Fill();
            veil.raycastTarget = false;
            float born = Time.unscaledTime;
            veil.Live(() =>
            {
                float a = (Time.unscaledTime - born) / duration;
                veil.color = new Color(color.r, color.g, color.b, color.a * (1f - Mathf.Clamp01(a)));
                if (a >= 1f) UnityEngine.Object.Destroy(veil.gameObject);
            }, 0f);
        }
    }

    /// <summary>Calls an update delegate a few times per second (countdowns, bars, counters).</summary>
    public class Live : MonoBehaviour
    {
        public Action update;
        public float interval = 0.25f;
        float next;
        void Update()
        {
            if (Time.unscaledTime < next) return;
            next = Time.unscaledTime + interval;
            try { update?.Invoke(); } catch (Exception e) { Debug.LogException(e); enabled = false; }
        }
    }

    /// <summary>Squash on press for a tactile feel.</summary>
    public class PressBounce : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
    {
        Vector3 baseScale = Vector3.one; float target = 1f; bool init;
        void Awake() { baseScale = transform.localScale; init = true; }
        public void OnPointerDown(PointerEventData e) => target = 0.94f;
        public void OnPointerUp(PointerEventData e) => target = 1f;
        public void OnPointerExit(PointerEventData e) => target = 1f;
        void Update()
        {
            if (!init) return;
            float s = Mathf.Lerp(transform.localScale.x / Mathf.Max(0.0001f, baseScale.x), target, Time.unscaledDeltaTime * 18f);
            transform.localScale = baseScale * s;
        }
    }

    /// <summary>Diamond-shaped hit area for isometric tiles.</summary>
    public class DiamondHit : MonoBehaviour, ICanvasRaycastFilter
    {
        public float diamondHeightFraction = 0.84f;   // the top face occupies the upper part of the tile sprite
        public bool IsRaycastLocationValid(Vector2 sp, Camera cam)
        {
            var rt = (RectTransform)transform;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(rt, sp, cam, out var p);
            var r = rt.rect;
            float hw = r.width / 2f, hh = r.height * diamondHeightFraction / 2f;
            float cx = r.center.x, cy = r.yMax - hh;
            return Mathf.Abs(p.x - cx) / hw + Mathf.Abs(p.y - cy) / hh <= 1.05f;
        }
    }
}
