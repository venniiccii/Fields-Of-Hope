using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace FieldsOfHope
{
    /// <summary>
    /// Little speech bubbles over people's heads (Resources/Art/emote_*.png, drawn by Tools/make_emotes.py): what they say
    /// and feel — chatter, a laugh, a song, sweat after hard work, lunch. They sit in their own layer above the map so a
    /// tree never hides one, follow the person they belong to, pop in, bob, and fade away.
    /// </summary>
    public class Emotes
    {
        public static readonly string[] Chatter = { "talk", "talk", "talk", "laugh", "question", "excl", "note", "heart" };

        const float Width = 24f, Height = 22.4f;     // map px
        readonly FarmScreen farm;
        readonly RectTransform layer;

        class Bubble { public Image img; public Graphic who; public float head, born, life; }
        readonly Dictionary<Graphic, Bubble> bubbles = new Dictionary<Graphic, Bubble>();

        public Emotes(FarmScreen farm, int siblingIndex)
        {
            this.farm = farm;
            layer = UI.New("Emotes", farm.World).Fill();
            layer.SetSiblingIndex(siblingIndex);
        }

        /// <param name="who">the person's image; bubbles skip anyone hidden (indoors)</param>
        /// <param name="head">map px from their feet to the top of their head</param>
        public void Show(Graphic who, float head, string kind, float life = 2.2f)
        {
            if (who == null || !who.enabled || !who.gameObject.activeInHierarchy) return;
            var sprite = UI.S("emote_" + kind);
            if (sprite == null) return;
            if (!bubbles.TryGetValue(who, out var b))
            {
                var img = UI.Img(layer, null, Color.white, false, "Emote");
                img.raycastTarget = false;
                // the tail is at the bubble's bottom-left: that corner sits just over the head
                img.rectTransform.At(0.5f, 0.5f, 0, 0, Width * farm.Scale, Height * farm.Scale, 0.17f, 0f);
                bubbles[who] = b = new Bubble { img = img };
            }
            b.img.sprite = sprite; b.who = who; b.head = head; b.born = Time.unscaledTime; b.life = life;
            b.img.enabled = true;
        }

        public void Destroy() => Object.Destroy(layer.gameObject);

        public bool Showing(Graphic who) => bubbles.TryGetValue(who, out var b) && b.img.enabled;

        public void Tick()
        {
            float now = Time.unscaledTime;
            foreach (var b in bubbles.Values)
            {
                if (!b.img.enabled) continue;
                float age = now - b.born;
                if (age > b.life || b.who == null || !b.who.enabled || !b.who.gameObject.activeInHierarchy) { b.img.enabled = false; continue; }
                // springs up from small with a little overshoot, bobs gently, fades out at the end
                float pop = age < 0.16f ? Mathf.Lerp(0.3f, 1.15f, age / 0.16f) : age < 0.28f ? Mathf.Lerp(1.15f, 1f, (age - 0.16f) / 0.12f) : 1f;
                float alpha = Mathf.Clamp01((b.life - age) / 0.3f);
                var rt = b.img.rectTransform;
                rt.localScale = Vector3.one * pop;
                rt.anchoredPosition = b.who.rectTransform.anchoredPosition
                                      + new Vector2(3f, b.head + 2f + Mathf.Sin(age * 5f) * 0.8f) * farm.Scale;
                b.img.color = new Color(1, 1, 1, alpha);
            }
        }
    }
}
