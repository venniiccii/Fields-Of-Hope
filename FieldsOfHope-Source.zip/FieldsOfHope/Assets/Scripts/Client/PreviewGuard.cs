using System;
using UnityEngine;
using UnityEngine.UI;

namespace FieldsOfHope
{
    /// <summary>
    /// Evaluation builds only: the build script writes Resources/preview_config.json, which adds a watermark
    /// and an expiry date. Normal builds have no config file and are unaffected.
    /// </summary>
    public static class PreviewGuard
    {
        [Serializable]
        class Config { public string expiresUtc; public string label; public bool unlockAll; }

        static Config config;
        static bool loaded;

        static Config Load()
        {
            if (loaded) return config;
            loaded = true;
            var ta = Resources.Load<TextAsset>("preview_config");
            if (ta != null) config = JsonUtility.FromJson<Config>(ta.text);
            return config;
        }

        public static bool IsPreview => Load() != null;

        /// <summary>Every location open to visit, for the client to inspect (set per build in BuildTools).</summary>
        public static bool OpenAllLocations => Load()?.unlockAll ?? false;

        public static bool Expired
        {
            get
            {
                var c = Load();
                return c != null && DateTime.TryParse(c.expiresUtc, null, System.Globalization.DateTimeStyles.AdjustToUniversal | System.Globalization.DateTimeStyles.AssumeUniversal, out var exp)
                       && DateTime.UtcNow > exp;
            }
        }

        /// <summary>Adds the watermark; returns false (and shows a notice) when the preview has expired.</summary>
        public static bool Apply(RectTransform canvas)
        {
            var c = Load();
            if (c == null) return true;
            var mark = UI.Label(canvas, c.label + " · expires " + c.expiresUtc, 22, new Color(1, 1, 1, 0.55f), TextAnchor.LowerLeft, true);
            mark.rectTransform.At(0, 0, 360, 8, 1100, 32, 0, 0);
            mark.Outlined(new Color(0, 0, 0, 0.5f), 1.5f);
            mark.transform.SetAsLastSibling();
            if (!Expired) return true;
            var block = UI.Rect(canvas, new Color(0.08f, 0.06f, 0.04f, 0.96f), "Expired");
            block.rectTransform.Fill();
            block.raycastTarget = true;
            var t = UI.Label(block.transform, "This evaluation preview of Fields of Hope has expired.\n\nPlease contact the developer for the full version.", 40, UI.Cream);
            t.rectTransform.Fill(200, 200, 200, 200);
            return false;
        }
    }
}
