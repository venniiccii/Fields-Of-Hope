using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace FieldsOfHope
{
    /// <summary>Lower-right parchment cards (EVENT-04, I.3).</summary>
    public class NotificationStack
    {
        const int MaxVisible = 3;
        const float CardW = 370, CardH = 88, Gap = 6;

        class Card
        {
            public RectTransform rt;
            public ServerMsg msg;
            public float born;
            public Text title, body;
            public Image icon;
            public CanvasGroup group;
        }

        readonly RectTransform root;
        readonly List<Card> cards = new List<Card>();
        readonly Text more;
        GameServer S => GameApp.I.Server;

        public NotificationStack(RectTransform parent)
        {
            root = UI.New("Notifications", parent).BR(8, 14, CardW, (CardH + Gap) * MaxVisible + 40);
            more = UI.Label(root, "", 22, UI.Cream, TextAnchor.MiddleRight, true).Outlined();
            more.rectTransform.At(1, 1, -8, 0, 200, 34, 1, 1);
            root.Live(Tick, 0.1f);
        }

        public void Push(ServerMsg msg)
        {
            if (msg.eventId != null)
            {
                var existing = cards.FirstOrDefault(c => c.msg.eventId == msg.eventId);
                if (existing != null) { Fill(existing, msg); existing.born = Time.unscaledTime; return; }
            }
            var bg = UI.Sliced(root, "notif_card", null, 1f, "Card");
            bg.raycastTarget = true;
            var card = new Card { rt = bg.rectTransform, born = Time.unscaledTime };
            card.rt.At(1, 0, 0, 0, CardW, CardH, 1, 0);
            card.group = bg.gameObject.AddComponent<CanvasGroup>();
            card.icon = UI.Img(card.rt, null);
            card.icon.rectTransform.At(0, 0.5f, 14, 0, 58, 58, 0, 0.5f);
            card.title = UI.Label(card.rt, "", 23, UI.Ink, TextAnchor.UpperLeft, true);
            card.title.rectTransform.Fill(82, 12, 48, 40);
            card.title.horizontalOverflow = HorizontalWrapMode.Overflow;
            card.body = UI.Label(card.rt, "", 18, new Color(0.35f, 0.22f, 0.12f), TextAnchor.UpperLeft);
            card.body.rectTransform.Fill(82, 42, 40, 6);
            var x = UI.Label(card.rt, "x", 24, UI.Muted, TextAnchor.MiddleCenter, true);
            x.rectTransform.At(1, 1, -6, -2, 36, 36, 1, 1);
            x.Clickable(() => Remove(card));
            bg.Clickable(() => Detail(card));
            Fill(card, msg);
            cards.Add(card);
            Layout();
        }

        void Fill(Card c, ServerMsg msg)
        {
            c.msg = msg;
            c.title.text = msg.title;
            c.body.text = msg.body;
            c.icon.sprite = UI.S(msg.icon ?? (msg.kind == "warn" ? "icon_bug" : "icon_sprout_notif"));
            c.icon.enabled = c.icon.sprite != null;
            c.rt.GetComponent<Image>().color = msg.kind == "warn" ? new Color(1f, 0.93f, 0.85f) : Color.white;
        }

        void Detail(Card c)
        {
            string body = c.msg.body;
            var e = c.msg.eventId != null ? S.FindEvent(c.msg.eventId) : null;
            if (e != null)
            {
                body = S.EventStatusLine(e) + "\n\n" + body;
                if (e.phase != EventPhase.Resolved) body += "\n\n" + Advice(e.type);
                if (e.plots.Count > 0 && e.phase != EventPhase.Resolved) body += "\nAffected plots: " + string.Join(", ", e.plots.Select(i => i + 1));
            }
            GameApp.I.Message(c.msg.title, body, ("OK", null), ("Dismiss", () => Remove(c)));
        }

        static string Advice(string type) => type switch
        {
            "rain" => "What to do: dig drainage trenches with the shovel (free) or place Rain Covers, and harvest ready crops first.\nIf ignored: unprotected root crops and lettuce lose 15% yield; ready crops lose 10%.",
            "pest" => "What to do: apply Pest Spray to infested plots, or harvest early.\nIf ignored: infested crops grow 30% slower and yield 25% less.",
            "drought" => "What to do: refill the tank, mulch plots and water the most valuable crops first.\nIf ignored: unwatered plots stop growing.",
            _ => ""
        };

        void Remove(Card c)
        {
            cards.Remove(c);
            if (c.rt != null) Object.Destroy(c.rt.gameObject);
            Layout();
        }

        void Layout()
        {
            // newest card on top, up to three visible; one at a time on narrow (mobile) screens
            int max = Screen.width < Screen.height ? 1 : MaxVisible;
            var visible = cards.Skip(Mathf.Max(0, cards.Count - max)).ToList();
            foreach (var c in cards) c.rt.gameObject.SetActive(visible.Contains(c));
            for (int i = 0; i < visible.Count; i++) visible[i].rt.anchoredPosition = new Vector2(0, i * (CardH + Gap));
            int hidden = cards.Count - visible.Count;
            more.text = hidden > 0 ? "+" + hidden + " more" : "";
            more.rectTransform.anchoredPosition = new Vector2(-8, -(root.rect.height - visible.Count * (CardH + Gap) - 34));
        }

        void Tick()
        {
            bool changed = false;
            foreach (var c in cards.ToList())
            {
                float age = Time.unscaledTime - c.born;
                var e = c.msg.eventId != null ? S.FindEvent(c.msg.eventId) : null;
                if (e != null && c.msg.kind == "warn")
                {
                    c.body.text = S.EventStatusLine(e);
                    if (e.phase == EventPhase.Resolved) { c.msg.kind = "result"; c.born = Time.unscaledTime; }
                    continue;   // warnings persist until the event ends or the player dismisses them
                }
                float life = c.msg.kind == "info" ? 8f : c.msg.kind == "result" ? 14f : 20f;
                c.group.alpha = age > life - 1f ? Mathf.Clamp01(life - age) : 1f;
                if (age > life) { cards.Remove(c); Object.Destroy(c.rt.gameObject); changed = true; }
            }
            if (changed) Layout();
        }
    }
}
