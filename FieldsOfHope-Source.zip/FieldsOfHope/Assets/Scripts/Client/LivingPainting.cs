using UnityEngine;
using UnityEngine.UI;

namespace FieldsOfHope
{
    /// <summary>
    /// Puts the "living painting" shader on a background image: foliage sways, water ripples and glints, cloud shadows drift
    /// and the painted villagers breathe, work and chat. The mask (Resources/Art/mask_*.png) comes from Tools/make_masks.py (project root).
    /// If the shader or mask is missing, or the device can't run it, the painting simply stays still.
    /// </summary>
    public static class LivingPainting
    {
        static Shader shader;

        public static Material Apply(Image img, string mask, Vector4 wheel = default)
        {
            if (img == null) return null;
            if (shader == null) shader = Resources.Load<Shader>("Shaders/LivingPainting");
            var tex = Resources.Load<Texture2D>("Art/" + mask);
            if (shader == null || tex == null || !shader.isSupported) return null;
            var mat = new Material(shader) { name = "Living " + mask };
            mat.SetTexture("_Mask", tex);
            mat.SetVector("_Wheel", wheel);
            img.material = mat;
            return mat;
        }
    }
}
