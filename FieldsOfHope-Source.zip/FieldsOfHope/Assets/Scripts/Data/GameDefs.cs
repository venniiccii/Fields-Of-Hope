using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace FieldsOfHope
{
    public class CropDef
    {
        public string id, name, location, icon, realNote;
        public int unlockLevel, seedPrice, yield, price;
        public float growMin;            // growth time, or establishment time for orchard crops
        public bool orchard;
        public float regrowMin;          // orchard: time between harvests
        public int harvests = 1;         // orchard: harvests per tree
        public bool essential;           // staple food, may be flagged as an essential request
        public bool rootOrLeafy;         // takes damage from heavy rain when unprotected
        public bool hybrid;              // Rare Seed Hybrid
        public int seedCp;               // Community Points needed to buy the seed
        public Color tint = Color.white;

        public int Profit => yield * harvests * price - seedPrice;
        public string SeedId => "seed_" + id;
        public string CropItemId => "crop_" + id;
    }

    public class LocationDef
    {
        public string id, name, label, climate, realNote, considerations, challenges;
        public string arrivalIntro;      // shown on the first trip here; null where the tutorial does the welcoming (Baguio)
        public int waterings;            // waterings needed per growth cycle (0 = rain-fed)
        public float plotPriceMul, rainChance, pestChance, droughtChance;
        public Color bgTint;
        public int fee, unlockLevel;
    }

    public enum ItemKind { Seed, Crop, Tool, Supply, Upgrade }

    public class ShopItem
    {
        public string id, name, icon, tab, desc;
        public int coins, cp, level, maxOwned = 9999;
        public ItemKind kind;
        public string crop;              // seeds
        public string needsLocation;     // location that must be unlocked to buy
    }

    public static class Defs
    {
        public const int StartCoins = 300;
        public const int StackSize = 20;
        public const int TutorialLettuceSeconds = 120;
        public const float UnwateredRate = 0.5f;
        public const float MarketRate = 0.7f;
        public const int MaxPlots = 12;
        public const int TankBase = 10, TankUpgraded = 16;
        public const int WellCooldownMin = 10;

        public static readonly List<CropDef> Crops = new List<CropDef>
        {
            new CropDef { id = "lettuce", name = "Lettuce", location = "baguio", unlockLevel = 1, seedPrice = 8, growMin = 10, yield = 4, price = 5, icon = "crop_lettuce", rootOrLeafy = true, realNote = "Real lettuce takes roughly 45 to 60 days." },
            new CropDef { id = "cabbage", name = "Cabbage", location = "baguio", unlockLevel = 1, seedPrice = 10, growMin = 10, yield = 4, price = 7, icon = "crop_cabbage", essential = true, realNote = "Real cabbage takes roughly 70 to 100 days." },
            new CropDef { id = "carrot", name = "Carrot", location = "baguio", unlockLevel = 1, seedPrice = 10, growMin = 10, yield = 5, price = 6, icon = "crop_carrot", rootOrLeafy = true, realNote = "Real carrots take roughly 75 to 100 days." },
            new CropDef { id = "potato", name = "Potato", location = "baguio", unlockLevel = 2, seedPrice = 15, growMin = 20, yield = 6, price = 6, icon = "crop_potato", essential = true, rootOrLeafy = true, realNote = "Real potatoes take roughly 90 to 120 days." },
            new CropDef { id = "strawberry", name = "Strawberry", location = "baguio", unlockLevel = 3, seedPrice = 25, growMin = 30, yield = 5, price = 12, icon = "crop_strawberry", realNote = "A cool-climate fruit associated with La Trinidad, Benguet." },
            new CropDef { id = "hybrid_lettuce", name = "Hybrid Lettuce", location = "baguio", unlockLevel = 4, seedPrice = 30, seedCp = 5, growMin = 15, yield = 6, price = 9, icon = "crop_lettuce", hybrid = true, rootOrLeafy = true, tint = new Color(0.85f, 0.75f, 1f), realNote = "Improved varieties are bred for yield and resilience." },
            new CropDef { id = "hybrid_carrot", name = "Hybrid Carrot", location = "baguio", unlockLevel = 4, seedPrice = 35, seedCp = 5, growMin = 15, yield = 7, price = 8, icon = "crop_carrot", hybrid = true, rootOrLeafy = true, tint = new Color(0.9f, 0.75f, 1f), realNote = "Improved varieties are bred for yield and resilience." },

            new CropDef { id = "rice", name = "Rice", location = "ilocos", unlockLevel = 0, seedPrice = 20, growMin = 25, yield = 6, price = 6, icon = "crop_rice", essential = true, realNote = "Real rice takes about 3.5 to 4 months and needs irrigation." },
            new CropDef { id = "corn", name = "Corn", location = "ilocos", unlockLevel = 0, seedPrice = 15, growMin = 20, yield = 6, price = 5, icon = "crop_corn", essential = true, realNote = "Moderately drought tolerant; about 3 to 4 months." },
            new CropDef { id = "garlic", name = "Garlic", location = "ilocos", unlockLevel = 6, seedPrice = 25, growMin = 30, yield = 5, price = 10, icon = "crop_garlic", rootOrLeafy = true, realNote = "A dry-season crop; about 100 to 120 days." },
            new CropDef { id = "onion", name = "Onion", location = "ilocos", unlockLevel = 7, seedPrice = 25, growMin = 30, yield = 5, price = 9, icon = "crop_onion", rootOrLeafy = true, realNote = "A dry-season crop; about 100 to 120 days." },

            new CropDef { id = "banana", name = "Banana", location = "davao", unlockLevel = 10, seedPrice = 40, growMin = 45, regrowMin = 30, yield = 8, harvests = 5, price = 5, orchard = true, icon = "crop_banana", essential = true, realNote = "About 9 to 12 months to first harvest." },
            new CropDef { id = "pineapple", name = "Pineapple", location = "davao", unlockLevel = 11, seedPrice = 35, growMin = 60, regrowMin = 0, yield = 3, harvests = 1, price = 18, orchard = true, icon = "crop_pineapple", realNote = "About 12 to 18 months; grown across Mindanao." },
            new CropDef { id = "coconut", name = "Coconut", location = "davao", unlockLevel = 12, seedPrice = 60, growMin = 120, regrowMin = 60, yield = 6, harvests = 8, price = 10, orchard = true, icon = "crop_coconut", realNote = "Several years before bearing, then fruits year round." },
            new CropDef { id = "cacao", name = "Cacao", location = "davao", unlockLevel = 13, seedPrice = 55, growMin = 90, regrowMin = 45, yield = 4, harvests = 6, price = 15, orchard = true, icon = "crop_cacao", realNote = "About 3 to 4 years to bearing." },
            new CropDef { id = "durian", name = "Durian", location = "davao", unlockLevel = 14, seedPrice = 80, growMin = 150, regrowMin = 90, yield = 3, harvests = 5, price = 30, orchard = true, icon = "crop_durian", realNote = "Several years before bearing." },
        };

        public static readonly List<LocationDef> Locations = new List<LocationDef>
        {
            new LocationDef { id = "baguio", name = "Baguio City", label = "BAGUIO", climate = "Cool, rainy highland", waterings = 1, plotPriceMul = 1f,
                rainChance = 0.03f, pestChance = 0.02f, droughtChance = 0f, bgTint = Color.white, fee = 0, unlockLevel = 1,
                realNote = "Highland vegetables are widely grown in the Cordillera; strawberries are associated with La Trinidad, Benguet.",
                considerations = "One watering per crop. Root crops dislike waterlogging.", challenges = "Heavy rainfall, pest outbreaks" },
            new LocationDef { id = "ilocos", name = "Ilocos Norte", label = "ILOCOS NORTE", climate = "Dry, with a long dry season", waterings = 2, plotPriceMul = 1.3f,
                rainChance = 0.012f, pestChance = 0.02f, droughtChance = 0.03f, bgTint = new Color(1f, 0.9f, 0.7f), fee = 1500, unlockLevel = 5,
                realNote = "Ilocos Norte has a long dry season and is known for garlic, rice, corn and onion. Rice needs irrigation.",
                considerations = "Water tank and well. Two waterings per cycle.", challenges = "Drought and water shortage, pests",
                arrivalIntro = "Welcome to Ilocos Norte! It is dry here for much of the year. Every crop needs TWO waterings per cycle, and water comes from your tank. Refill it at the well, and plant hardy corn, garlic and onion when water is short." },
            new LocationDef { id = "davao", name = "Davao City", label = "DAVAO", climate = "Warm, humid tropical", waterings = 0, plotPriceMul = 1.6f,
                rainChance = 0.05f, pestChance = 0.035f, droughtChance = 0f, bgTint = new Color(0.82f, 1f, 0.86f), fee = 5000, unlockLevel = 10,
                realNote = "Rainfall is spread through the year. Davao is known for banana, durian and cacao; coconut is widely grown.",
                considerations = "Orchard plots: long establishment, repeated harvests. Watering is rarely needed.", challenges = "Frequent rain, pest outbreaks, long waits",
                arrivalIntro = "Welcome to Davao City! It's warm and humid, so watering is rarely needed. Bananas, cacao, coconut and durian grow on orchard trees: a long wait at first, then many harvests. Watch out for pests in the humidity!" },
        };

        // cumulative XP needed to reach each level (index = level)
        public static readonly int[] XpForLevel = { 0, 0, 100, 250, 450, 700, 1000, 1400, 1900, 2500, 3200, 4000, 4900, 5900, 7000, 8200 };
        public const int MaxLevel = 15;

        public static readonly int[] PlotPrices = { 0, 0, 0, 0, 0, 150, 200, 275, 375, 500, 650, 850, 1100 }; // index = plot number
        public static readonly int[] PlotLevels = { 0, 1, 1, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5 };

        public static int LevelCoinReward(int lv) => lv switch
        {
            2 => 50, 3 => 75, 4 => 100, 5 => 150, 6 => 150, 7 => 200, 8 => 200, 9 => 250, 10 => 300, 15 => 500,
            _ => lv >= 11 && lv <= 14 ? 300 : 0
        };

        public static int BaseStorage(int lv) => lv >= 8 ? 100 : lv >= 5 ? 80 : lv >= 3 ? 60 : 40;

        public static string LevelUnlockText(int lv) => lv switch
        {
            2 => "Potato seeds, plots 5 and 6. Random events can now happen.",
            3 => "Strawberry seeds, plots 7 and 8. Storage grows to 60 slots.",
            4 => "Plots 9 and 10, Rare Seed Hybrids. +2 Fertilizer Packs. Requests now ask for variety.",
            5 => "Plots 11 and 12. Storage grows to 80 slots. Ilocos Norte can become eligible.",
            6 => "Garlic seeds (Ilocos Norte).",
            7 => "Onion seeds. Cross-region requests begin.",
            8 => "Gilded Spade. Storage grows to 100 slots.",
            9 => "Large crate upgrades.",
            10 => "Davao City can become eligible. Banana seeds.",
            11 => "Pineapple seeds.",
            12 => "Coconut seeds.",
            13 => "Cacao seeds.",
            14 => "Durian seeds.",
            15 => "Title: Food Security Champion. Weekly challenges.",
            _ => ""
        };

        public static readonly List<ShopItem> Items = BuildItems();

        static List<ShopItem> BuildItems()
        {
            var list = new List<ShopItem>();
            foreach (var c in Crops)
                list.Add(new ShopItem
                {
                    id = c.SeedId, name = c.hybrid ? "Rare Seed Hybrid (" + c.name.Replace("Hybrid ", "") + ")" : c.name + " Seeds",
                    icon = c.hybrid ? "item_rare_seed" : c.icon, tab = c.hybrid ? "Featured" : "Seeds", kind = ItemKind.Seed, crop = c.id,
                    coins = c.seedPrice, cp = c.seedCp, level = Mathf.Max(1, c.unlockLevel), needsLocation = c.location,
                    desc = c.orchard ? "Orchard tree" : "Seed",
                });
            list.Add(new ShopItem { id = "fertilizer", name = "Fertilizer Pack", icon = "item_fertilizer", tab = "Supplies", kind = ItemKind.Supply, coins = 40, level = 1, desc = "+20% yield and clears soil fatigue. Apply when planting or on a growing crop." });
            list.Add(new ShopItem { id = "rain_cover", name = "Rain Cover", icon = "item_rain_cover", tab = "Supplies", kind = ItemKind.Supply, coins = 60, level = 2, desc = "Protects one plot from heavy rain." });
            list.Add(new ShopItem { id = "pest_spray", name = "Pest Spray", icon = "item_pest_spray", tab = "Supplies", kind = ItemKind.Supply, coins = 40, level = 2, desc = "Treats a pest-infested plot." });
            list.Add(new ShopItem { id = "mulch", name = "Mulch", icon = "item_mulch", tab = "Supplies", kind = ItemKind.Supply, coins = 50, level = 2, desc = "Halves a plot's water need; keeps growing during drought." });
            list.Add(new ShopItem { id = "scarecrow", name = "Scarecrow", icon = "item_scarecrow", tab = "Tools", kind = ItemKind.Upgrade, coins = 150, cp = 10, level = 2, maxOwned = 1, desc = "Placed on this farm: pest outbreaks are 25% less likely." });
            list.Add(new ShopItem { id = "tank_upgrade", name = "Water Tank Upgrade", icon = "item_tank", tab = "Tools", kind = ItemKind.Upgrade, coins = 400, level = 6, maxOwned = 1, needsLocation = "ilocos", desc = "Raises the Ilocos water tank from 10 to 16 waterings." });
            list.Add(new ShopItem { id = "tool_spade", name = "Gilded Spade", icon = "item_spade", tab = "Tools", kind = ItemKind.Tool, coins = 1000, cp = 20, level = 8, maxOwned = 1, desc = "One drainage trench protects every plot on the farm." });
            list.Add(new ShopItem { id = "crate_small", name = "Small Crate", icon = "slot_crate", tab = "Upgrades", kind = ItemKind.Upgrade, coins = 250, level = 2, maxOwned = 3, desc = "+10 storage slots." });
            list.Add(new ShopItem { id = "crate_large", name = "Large Crate", icon = "item_barn", tab = "Upgrades", kind = ItemKind.Upgrade, coins = 900, level = 9, maxOwned = 2, desc = "+25 storage slots." });
            return list;
        }

        public static readonly string[] ShopTabs = { "Featured", "Seeds", "Tools", "Supplies", "Upgrades" };

        public static CropDef Crop(string id) => Crops.FirstOrDefault(c => c.id == id);
        public static LocationDef Loc(string id) => Locations.FirstOrDefault(l => l.id == id);
        public static ShopItem Item(string id) => Items.FirstOrDefault(i => i.id == id);

        public static string ItemName(string id)
        {
            if (id.StartsWith("crop_")) return Crop(id.Substring(5))?.name ?? id;
            if (id == "recovery_kit") return "Recovery Seed Kit";
            return Item(id)?.name ?? id;
        }

        public static string ItemIcon(string id)
        {
            if (id.StartsWith("crop_")) return Crop(id.Substring(5))?.icon ?? "icon_check";
            return Item(id)?.icon ?? "icon_check";
        }

        public static bool UsesSlot(string id) => !id.StartsWith("tool_");

        public static int PlotPrice(string loc, int plotNumber) =>
            plotNumber < 1 || plotNumber > MaxPlots ? 0 : Mathf.RoundToInt(PlotPrices[plotNumber] * Loc(loc).plotPriceMul / 5f) * 5;

        /// <summary>What blocks unbought land in each location's field (art: obstacle_&lt;id&gt;), in its own pattern there.</summary>
        public static string Obstacle(string loc, int plot) => loc switch
        {
            "ilocos" => plot * 5 % 7 < 3 ? "driftwood" : "shrub",
            "davao" => plot * 3 % 5 < 2 ? "banana_stump" : "husks",
            _ => plot % 3 == 1 ? "stump" : "rock",
        };

        public static readonly string[] ObstacleKinds = { "rock", "stump", "driftwood", "shrub", "husks", "banana_stump" };

        public static string ObstacleNote(string obstacle) => obstacle switch
        {
            "stump" => "An old pine stump blocks this land.",
            "driftwood" => "Driftwood from the coast blocks this land.",
            "shrub" => "Dry, thorny shrubs block this land.",
            "husks" => "Piles of coconut husks block this land.",
            "banana_stump" => "An old banana stump blocks this land.",
            _ => "Large rocks block this land.",
        };
    }
}
