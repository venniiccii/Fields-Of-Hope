using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace FieldsOfHope.Tests
{
    /// <summary>Every location's planting field has its own look: tiles, edging and what blocks unbought land.</summary>
    public class FieldLookTests : ServerTestBase
    {
        static string[] Blockers(GameServer s, string loc) =>
            s.Loc(loc).plots.Where(p => p.state == PlotState.Blocked).Select(p => p.obstacle).ToArray();

        [Test]
        public void EachLocationIsBlockedByItsOwnThings()
        {
            LoginNew();
            CollectionAssert.AreEquivalent(new[] { "rock", "stump" }, Blockers(S, "baguio").Distinct().ToArray());
            CollectionAssert.AreEquivalent(new[] { "driftwood", "shrub" }, Blockers(S, "ilocos").Distinct().ToArray());
            CollectionAssert.AreEquivalent(new[] { "husks", "banana_stump" }, Blockers(S, "davao").Distinct().ToArray());
        }

        [Test]
        public void TheFieldsAreNotLaidOutAlike()
        {
            int Woody(string loc) => Enumerable.Range(4, Defs.MaxPlots - 4).Count(i => Defs.Obstacle(loc, i) is "stump" or "driftwood" or "banana_stump");
            var patterns = new[] { "baguio", "ilocos", "davao" }
                .Select(loc => string.Join("", Enumerable.Range(4, Defs.MaxPlots - 4).Select(i => Defs.Obstacle(loc, i) is "stump" or "driftwood" or "banana_stump" ? "W" : "o")))
                .ToArray();
            Assert.AreEqual(3, patterns.Distinct().Count(), string.Join(" / ", patterns));
            Assert.That(Woody("ilocos"), Is.InRange(2, 6)); Assert.That(Woody("davao"), Is.InRange(2, 6));
        }

        [Test]
        public void OlderSavesGetEachLocationsOwnBlockers()
        {
            LoginNew();
            // saves from before had Baguio's rocks and stumps in every location
            foreach (var l in S.Save.locations)
                foreach (var p in l.plots.Where(p => p.state == PlotState.Blocked))
                    p.obstacle = p.index % 3 == 1 ? "stump" : "rock";
            var baguio = Blockers(S, "baguio");
            S.Logout();
            Ok(S.Login(User, Pass, out _));
            CollectionAssert.AreEqual(baguio, Blockers(S, "baguio"), "Baguio's field is left as it was");
            Assert.IsTrue(Blockers(S, "ilocos").All(o => o == "driftwood" || o == "shrub"));
            Assert.IsTrue(Blockers(S, "davao").All(o => o == "husks" || o == "banana_stump"));
        }

        [Test]
        public void ClearingWorksOnEveryKindOfBlocker()
        {
            LoginNew();
            GameServer.OpenAllLocations = true;
            try
            {
                Ok(S.Travel(Tx(), "davao"));
                Assert.AreEqual("banana_stump", P(5).obstacle);
                Ok(S.ClearObstacle(Tx(), 5));
                Assert.AreEqual(PlotState.Cleared, P(5).state);
            }
            finally { GameServer.OpenAllLocations = false; }
        }

        [Test]
        public void EveryFieldHasItsArt()
        {
            foreach (var loc in Defs.Locations.Select(l => l.id))
                foreach (var kind in new[] { "tile_soil", "tile_soil_wet", "tile_grass" })
                    Assert.IsNotNull(Resources.Load<Sprite>("Art/" + kind + "_" + loc), kind + "_" + loc);
            foreach (var kind in Defs.ObstacleKinds)
                Assert.IsNotNull(Resources.Load<Sprite>("Art/obstacle_" + kind), "obstacle_" + kind);
            foreach (var loc in Defs.Locations.Select(l => l.id))
                for (int i = 0; i < Defs.MaxPlots; i++)
                    CollectionAssert.Contains(Defs.ObstacleKinds, Defs.Obstacle(loc, i));
            foreach (var edge in new[] { "stone_wall", "bamboo_fence", "coco_log" })
                Assert.IsNotNull(Resources.Load<Texture2D>("Map/" + edge), edge);
        }
    }
}
