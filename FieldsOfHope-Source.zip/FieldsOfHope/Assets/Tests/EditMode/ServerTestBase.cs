using System;
using System.IO;
using NUnit.Framework;

namespace FieldsOfHope.Tests
{
    /// <summary>Each test gets a fresh server writing to its own temporary folder.</summary>
    public abstract class ServerTestBase
    {
        protected string dir;
        protected GameServer S;
        protected const string User = "Test_Farmer";
        protected const string Pass = "harvest2026";

        [SetUp]
        public void BaseSetUp()
        {
            dir = Path.Combine(Path.GetTempPath(), "foh_tests_" + Guid.NewGuid().ToString("N"));
            S = new GameServer(dir);
        }

        [TearDown]
        public void BaseTearDown()
        {
            try { Directory.Delete(dir, true); } catch { /* temp folder cleanup is best effort */ }
        }

        protected static string Tx() => Guid.NewGuid().ToString("N");

        /// <summary>Registers and logs in; optionally finishes the tutorial so normal timers apply.</summary>
        protected void LoginNew(bool skipTutorial = true)
        {
            Assert.IsNull(S.Register(User, Pass, Pass));
            var r = S.Login(User, Pass, out _);
            Assert.IsTrue(r.ok, r.message);
            if (skipTutorial) Assert.IsTrue(S.CompleteTutorial(Tx()).ok);
            S.Outbox.Clear();
        }

        protected void Ok(Result r) => Assert.IsTrue(r.ok, "Expected success but got: " + r.message);
        protected void Fails(Result r, string contains = null)
        {
            Assert.IsFalse(r.ok, "Expected failure");
            if (contains != null) StringAssert.Contains(contains, r.message);
        }

        protected Plot P(int i) => S.PlotAt(i);

        protected void GiveLevel(int level)
        {
            int need = Defs.XpForLevel[level] - S.Save.xp;
            if (need > 0) S.DevGrant(0, need);
            Assert.AreEqual(level, S.Save.level);
        }
    }
}
