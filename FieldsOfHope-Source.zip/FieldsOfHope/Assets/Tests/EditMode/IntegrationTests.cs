using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEngine;

namespace FieldsOfHope.Tests
{
    public class CommunityTests : ServerTestBase
    {
        [SetUp] public void Login() => LoginNew();

        Request Req(string crop, int qty, bool essential = false)
        {
            var r = new Request { id = "t" + Tx().Substring(0, 6), crop = crop, qty = qty, day = S.Today, deadline = S.NowMs + GameServer.Min(600), essential = essential };
            S.Here.requests.Add(r);
            return r;
        }

        [Test]
        public void FullDeliveryPaysCoinsXpAndCp()
        {
            var r = Req("cabbage", 6);
            S.Save.items.Add(new ItemStack { id = "crop_cabbage", qty = 6 });
            int coins = S.Save.coins, xp = S.Save.xp, cp = S.Save.cp;
            Ok(S.Deliver(Tx(), r.id, false));
            Assert.AreEqual(coins + 6 * 7, S.Save.coins);
            Assert.AreEqual(xp + 10 + 2 * 6, S.Save.xp);
            Assert.AreEqual(cp + 3, S.Save.cp);
            Assert.AreEqual(RequestStatus.Completed, r.status);
            Assert.AreEqual(0, S.Count("crop_cabbage"));
            Assert.AreEqual(1, S.Here.requestsCompleted);
        }

        [Test]
        public void EssentialRequestGivesBonusXpAndDoubleCp()
        {
            var r = Req("cabbage", 4, essential: true);
            S.Save.items.Add(new ItemStack { id = "crop_cabbage", qty = 4 });
            int xp = S.Save.xp, cp = S.Save.cp;
            Ok(S.Deliver(Tx(), r.id, false));
            Assert.AreEqual(xp + 27, S.Save.xp);   // (10 + 8) * 1.5
            Assert.AreEqual(cp + 4, S.Save.cp);
        }

        [Test]
        public void MissingStockExplainsAndPartialDeliveryOnlyOnce()
        {
            var r = Req("cabbage", 6);
            S.Save.items.Add(new ItemStack { id = "crop_cabbage", qty = 3 });
            Fails(S.Deliver(Tx(), r.id, false), "Need 3 more Cabbage");
            int xp = S.Save.xp;
            Ok(S.Deliver(Tx(), r.id, true));
            Assert.AreEqual(3, r.delivered);
            Assert.AreEqual(RequestStatus.Open, r.status);
            Assert.AreEqual(xp, S.Save.xp, "partial delivery gives no XP");
            S.Save.items.Add(new ItemStack { id = "crop_cabbage", qty = 1 });
            Fails(S.Deliver(Tx(), r.id, true), "already");
            S.Save.items.Find(i => i.id == "crop_cabbage").qty = 3;
            Ok(S.Deliver(Tx(), r.id, false));
            Assert.AreEqual(RequestStatus.Completed, r.status);
        }

        [Test]
        public void RepeatDeliveriesOfOneCropHaveDiminishingXp()
        {
            var a = Req("carrot", 5); var b = Req("carrot", 5);
            S.Save.items.Add(new ItemStack { id = "crop_carrot", qty = 10 });
            int x0 = S.Save.xp;
            S.Deliver(Tx(), a.id, false);
            int x1 = S.Save.xp;
            S.Deliver(Tx(), b.id, false);
            Assert.AreEqual(20, x1 - x0);
            Assert.AreEqual(16, S.Save.xp - x1);   // 20 * 0.8
        }

        [Test]
        public void BalancedBasketBonusForThreeCrops()
        {
            foreach (var c in new[] { "lettuce", "cabbage", "carrot" })
            {
                var r = Req(c, 2);
                S.Save.items.Add(new ItemStack { id = "crop_" + c, qty = 2 });
                int cp = S.Save.cp;
                Ok(S.Deliver(Tx(), r.id, false));
                if (c == "carrot") Assert.AreEqual(cp + 1 + 5, S.Save.cp);
            }
            Assert.AreEqual(S.Today, S.Save.basketDay);
        }

        [Test]
        public void ExpiredRequestIsMarkedMissed()
        {
            var r = Req("lettuce", 2);
            r.deadline = S.NowMs + GameServer.Min(1);
            S.DevAdvance(2);
            Assert.AreEqual(RequestStatus.Missed, r.status);
            Fails(S.Deliver(Tx(), r.id, false), "no longer open");
        }

        [Test]
        public void MeterBandsAndFormula()
        {
            Assert.AreEqual("Critical", GameServer.Band(29));
            Assert.AreEqual("Strained", GameServer.Band(30));
            Assert.AreEqual("Stable", GameServer.Band(60));
            Assert.AreEqual("Thriving", GameServer.Band(85));
            var l = S.Here;
            l.history.Clear();
            l.history.Add(new DayHistory { day = S.Today, posted = 4, completed = 4, delivered = true, crops = { "lettuce", "cabbage", "carrot" } });
            l.pantryUnits = S.DailyConsumption(l) * 3;
            S.RecomputeMeter(l);
            // coverage 40 + variety 25*3/3 + pantry 20 + consistency 15/7
            Assert.AreEqual(Mathf.RoundToInt(40 + 25 + 20 + 15f / 7f), l.meter);
        }

        [Test]
        public void MarketSaleDoesNotRaiseFoodSecurity()
        {
            S.Save.items.Add(new ItemStack { id = "crop_cabbage", qty = 10 });
            S.RecomputeMeter(S.Here);
            int m = S.Here.meter;
            S.SellMarket(Tx(), "crop_cabbage", 10);
            S.RecomputeMeter(S.Here);
            Assert.AreEqual(m, S.Here.meter);
        }

        [Test]
        public void QuestsTrackAndPayOnce()
        {
            var water = S.Save.quests.First(q => q.kind == "water");
            for (int i = 0; i < 4; i++) S.Plant(Tx(), i, i < 3 ? "lettuce" : "cabbage", false);
            for (int i = 0; i < 4; i++) S.Water(Tx(), i);
            Assert.AreEqual(4, water.progress);
            Fails(S.ClaimQuest(Tx(), water.id), "Finish");
            water.progress = water.target;
            int coins = S.Save.coins;
            Ok(S.ClaimQuest(Tx(), water.id));
            Assert.AreEqual(coins + water.coins, S.Save.coins);
            Fails(S.ClaimQuest(Tx(), water.id), "Already");
        }

        [Test]
        public void DailyResetRollsNewRequestsAndQuests()
        {
            var oldQuest = S.Save.quests[0].id;
            int day = S.Today;
            S.DevAdvance(24 * 60 + 1);
            Assert.Greater(S.Today, day);
            Assert.AreEqual(S.Today, S.Save.questDay);
            Assert.AreNotEqual(oldQuest, S.Save.quests[0].id);
            Assert.IsTrue(S.Here.requests.Any(r => r.day == S.Today && r.status == RequestStatus.Open));
        }

        [Test]
        public void RequestCountScalesWithLevel()
        {
            GiveLevel(9);
            S.DevAdvance(24 * 60 + 1);
            int today = S.Here.requests.Count(r => r.day == S.Today && !r.surge);
            Assert.AreEqual(6, today);   // min(3 + 9/3, 6)
        }

        [Test]
        public void SuggestionsOnlyIncludeUnlockedLocalCrops()
        {
            var s = S.PlantSuggestions();
            Assert.IsNotEmpty(s);
            foreach (var x in s)
            {
                var c = Defs.Crop(x.id);
                Assert.AreEqual("baguio", c.location);
                Assert.LessOrEqual(c.unlockLevel, S.Save.level);
            }
        }
    }

    public class LocationTests : ServerTestBase
    {
        [SetUp] public void Login() => LoginNew();

        void MeetIlocosRequirements()
        {
            GiveLevel(5);
            var b = S.Loc("baguio");
            b.stableDays = 3; b.requestsCompleted = 15;
            b.cropsDelivered.AddRange(new[] { "lettuce", "cabbage", "carrot", "potato" });
            for (int i = 4; i < 8; i++) b.plots[i].state = PlotState.Empty;
        }

        [Test]
        public void IlocosStartsLockedWithChecklist()
        {
            Assert.IsFalse(S.Loc("ilocos").unlocked);
            Assert.IsFalse(S.IsEligible("ilocos"));
            Assert.AreEqual(5, S.UnlockRequirements("ilocos").Count);
            Fails(S.Travel(Tx(), "ilocos"), "locked");
            Fails(S.PayUnlock(Tx(), "ilocos"), "requirements");
        }

        [Test]
        public void UnlockPayFeeAndTravelSharesInventory()
        {
            MeetIlocosRequirements();
            Assert.IsTrue(S.IsEligible("ilocos"));
            S.Save.coins = 1400;
            Fails(S.PayUnlock(Tx(), "ilocos"), "Need 100 more coins");
            S.Save.coins = 2000;
            Ok(S.PayUnlock(Tx(), "ilocos"));
            Assert.AreEqual(500, S.Save.coins);
            int lettuceSeeds = S.Count("seed_lettuce");
            Ok(S.Travel(Tx(), "ilocos"));
            Assert.AreEqual("ilocos", S.Save.currentLocation);
            Assert.AreEqual(lettuceSeeds, S.Count("seed_lettuce"), "inventory is shared");
            Assert.AreEqual(4, S.OwnedPlots(S.Here), "each farm has its own plots");
            Fails(S.Plant(Tx(), 0, "lettuce", false), "Baguio");
        }

        [Test]
        public void IlocosNeedsTankWaterAndTwoWaterings()
        {
            MeetIlocosRequirements();
            S.Save.coins = 3000;
            S.PayUnlock(Tx(), "ilocos");
            S.Travel(Tx(), "ilocos");
            Ok(S.Buy(Tx(), "seed_rice", 2));
            Ok(S.Plant(Tx(), 0, "rice", false));
            Ok(S.Water(Tx(), 0));
            Assert.AreEqual(Defs.TankBase - 1, S.Here.tank);
            Fails(S.Water(Tx(), 0), "second half");
            S.DevAdvance(13);   // past half of 25 min
            Assert.IsFalse(S.IsWatered(P(0)));
            Ok(S.Water(Tx(), 0));
            Assert.IsTrue(S.IsWatered(P(0)));
            S.Here.tank = 0;
            Ok(S.Plant(Tx(), 1, "rice", false));
            Fails(S.Water(Tx(), 1), "tank is empty");
        }

        [Test]
        public void WellRefillsWithCooldown()
        {
            MeetIlocosRequirements();
            S.Save.coins = 3000;
            S.PayUnlock(Tx(), "ilocos");
            S.Travel(Tx(), "ilocos");
            S.Here.tank = 0;
            Ok(S.RefillTank(Tx()));
            Assert.AreEqual(Defs.TankBase, S.Here.tank);
            S.Here.tank = 3;
            Fails(S.RefillTank(Tx()), "refills in");
            S.DevAdvance(Defs.WellCooldownMin + 0.1f);
            Ok(S.RefillTank(Tx()));
        }

        [Test]
        public void DavaoRequiresIlocosFirst()
        {
            var req = S.UnlockRequirements("davao");
            Assert.IsFalse(req.First().met);
            Assert.IsFalse(S.IsEligible("davao"));
        }
    }

    public class EventTests : ServerTestBase
    {
        [SetUp] public void Login() { LoginNew(); GiveLevel(2); S.Save.coins = 1000; }

        [Test]
        public void HeavyRainDamagesOnlyUnprotectedPlots()
        {
            S.Plant(Tx(), 0, "carrot", false);
            S.Plant(Tx(), 1, "carrot", false);
            S.DevTrigger("rain");
            var e = S.Here.events.Last();
            Assert.AreEqual(EventPhase.Warning, e.phase);
            Ok(S.DigTrench(Tx(), 1));
            Fails(S.DigTrench(Tx(), 1), "already protected");
            S.DevAdvance(31);
            Assert.AreEqual(EventPhase.Active, e.phase);
            Assert.Less(P(0).yieldMod, 1f);
            Assert.AreEqual(1f, P(1).yieldMod, 0.0001f);
            Assert.GreaterOrEqual(P(0).yieldMod, 0.75f, "loss capped at 25%");
            S.DevAdvance(21);
            Assert.AreEqual(EventPhase.Resolved, e.phase);
            Assert.IsFalse(P(1).trench, "trenches are used up by the storm");
            Assert.IsNotEmpty(e.summary);
        }

        [Test]
        public void FullyProtectedRainGivesReward()
        {
            S.Plant(Tx(), 0, "cabbage", false);
            S.DevTrigger("rain");
            S.Buy(Tx(), "rain_cover", 1);
            Ok(S.UseOnPlot(Tx(), 0, "rain_cover"));
            int cp = S.Save.cp;
            S.DevAdvance(52);
            Assert.AreEqual(cp + 2, S.Save.cp);
        }

        [Test]
        public void PestSprayClearsInfestation()
        {
            S.Plant(Tx(), 0, "cabbage", false);
            S.Plant(Tx(), 1, "cabbage", false);
            S.DevTrigger("pest");
            var infested = S.Here.plots.Where(p => p.pest).ToList();
            Assert.IsNotEmpty(infested);
            int before = S.ExpectedYield(infested[0]);
            Fails(S.UseOnPlot(Tx(), infested[0].index, "pest_spray"), "no Pest Spray");
            S.Buy(Tx(), "pest_spray", 2);
            Ok(S.UseOnPlot(Tx(), infested[0].index, "pest_spray"));
            Assert.IsFalse(infested[0].pest);
            Assert.Greater(S.ExpectedYield(infested[0]), before);
        }

        [Test]
        public void OnlyOneNegativeEventAtATime()
        {
            S.Plant(Tx(), 0, "cabbage", false);
            S.DevTrigger("rain");
            S.DevTrigger("rain");
            Assert.AreEqual(1, S.Here.events.Count(e => e.phase != EventPhase.Resolved));
        }

        [Test]
        public void EventCardTextUpdatesInPlace()
        {
            S.DevTrigger("rain");
            var e = S.Here.events.Last();
            StringAssert.StartsWith("Heavy rain in", S.EventStatusLine(e));
            S.DevAdvance(31);
            StringAssert.Contains("active", S.EventStatusLine(e));
        }
    }

    public class PersistenceTests : ServerTestBase
    {
        [Test]
        public void ProgressSurvivesReload()
        {
            LoginNew();
            S.Plant(Tx(), 0, "cabbage", false);
            S.Buy(Tx(), "seed_carrot", 3);
            int coins = S.Save.coins;
            S.Logout();

            var again = new GameServer(dir);
            Assert.IsTrue(again.Login(User, Pass, out _).ok);
            Assert.AreEqual(coins, again.Save.coins);
            Assert.AreEqual(PlotState.Growing, again.PlotAt(0).state);
            Assert.AreEqual("cabbage", again.PlotAt(0).crop);
            Assert.AreEqual(7, again.Count("seed_carrot"));
            Assert.IsTrue(again.Save.tutorialDone);
        }

        [Test]
        public void OfflineTimeCompletesCropsAndSummarises()
        {
            LoginNew();
            S.Plant(Tx(), 0, "lettuce", false);
            S.Water(Tx(), 0);
            S.Persist();
            // simulate 30 minutes away: move the clock without the server seeing it
            S.Save.devClockOffsetMs += GameServer.Min(30);
            File.WriteAllText(Path.Combine(dir, "saves", S.Save.accountId + ".json"), JsonUtility.ToJson(S.Save));

            var again = new GameServer(dir);
            Assert.IsTrue(again.Login(User, Pass, out _).ok);
            Assert.AreEqual(PlotState.Ready, again.PlotAt(0).state);
            Assert.IsTrue(again.AwaySummary.Any(s => s.Contains("ready to harvest")), string.Join("|", again.AwaySummary));
        }

        [Test]
        public void ReopeningTheGameDoesNotAdvanceTimers()
        {
            LoginNew();
            S.Plant(Tx(), 0, "lettuce", false);
            float progress = S.PlotAt(0).progress;
            S.Logout();
            var again = new GameServer(dir);
            again.Login(User, Pass, out _);
            Assert.Less(again.PlotAt(0).progress - progress, 0.05f);
        }

        [Test]
        public void MissedDaysDoNotStackRewards()
        {
            LoginNew();
            S.DevAdvance(3 * 24 * 60);
            Assert.AreEqual(4, S.Save.quests.Count, "only the latest day's quests exist");
            Assert.AreEqual(1, S.Here.requests.Select(r => r.day).Where(d => d == S.Today).Distinct().Count());
        }
    }
}
