using System.Linq;
using NUnit.Framework;

namespace FieldsOfHope.Tests
{
    public class FarmTests : ServerTestBase
    {
        [SetUp] public void Login() => LoginNew();

        [Test]
        public void PlantingConsumesOneSeedAndStartsTimer()
        {
            Ok(S.Plant(Tx(), 0, "lettuce", false));
            Assert.AreEqual(5, S.Count("seed_lettuce"));
            Assert.AreEqual(PlotState.Growing, P(0).state);
            Assert.AreEqual(10f, P(0).total);
            Assert.IsTrue(S.Outbox.Any(m => m.title == "New crop planted!" && m.body == "Your seeds are growing."));
        }

        [Test]
        public void PlantingErrorsExplainTheReason()
        {
            Ok(S.Plant(Tx(), 0, "lettuce", false));
            Fails(S.Plant(Tx(), 0, "lettuce", false), "already in use");
            Fails(S.Plant(Tx(), 1, "rice", false), "Ilocos Norte");
            Fails(S.Plant(Tx(), 1, "potato", false), "Level 2");
            Fails(S.Plant(Tx(), 5, "lettuce", false), "axe");
            S.Save.items.RemoveAll(i => i.id == "seed_carrot");
            Fails(S.Plant(Tx(), 1, "carrot", false), "no Carrot seeds");
        }

        [Test]
        public void WateredTier1CropIsReadyIn10Minutes()
        {
            S.Plant(Tx(), 0, "lettuce", false);
            Ok(S.Water(Tx(), 0));
            Fails(S.Water(Tx(), 0), "already watered");
            S.DevAdvance(9.5f);
            Assert.AreEqual(PlotState.Growing, P(0).state);
            S.DevAdvance(0.6f);
            Assert.AreEqual(PlotState.Ready, P(0).state);
        }

        [Test]
        public void UnwateredCropGrowsAtHalfSpeed()
        {
            S.Plant(Tx(), 0, "lettuce", false);
            S.DevAdvance(10);
            Assert.AreEqual(PlotState.Growing, P(0).state);
            Assert.AreEqual(5f, P(0).progress, 0.05f);
            S.DevAdvance(10.1f);
            Assert.AreEqual(PlotState.Ready, P(0).state);
        }

        [Test]
        public void HarvestAddsYieldEmptiesPlotAndGivesXp()
        {
            S.Plant(Tx(), 0, "carrot", false);
            S.Water(Tx(), 0);
            Fails(S.Harvest(Tx(), 0), "not ready");
            S.DevAdvance(10.1f);
            int xp = S.Save.xp;
            var r = S.Harvest(Tx(), 0);
            Ok(r);
            Assert.AreEqual("+5 Carrot", r.message);
            Assert.AreEqual(5, S.Count("crop_carrot"));
            Assert.AreEqual(PlotState.Empty, P(0).state);
            Assert.AreEqual(xp + 1, S.Save.xp);
        }

        [Test]
        public void HarvestXpIsCappedAt20PerDay()
        {
            S.Save.harvestXpDay = S.Today;
            S.Save.harvestXpToday = 20;
            S.Plant(Tx(), 0, "carrot", false);
            S.DevAdvance(20.1f);
            int xp = S.Save.xp;
            Ok(S.Harvest(Tx(), 0));
            Assert.AreEqual(xp, S.Save.xp);
        }

        [Test]
        public void FullStorageBlocksHarvestAndKeepsTheCrop()
        {
            S.Plant(Tx(), 0, "carrot", false);
            S.DevAdvance(20.1f);
            S.Save.items.Add(new ItemStack { id = "crop_cabbage", qty = Defs.StackSize * S.StorageCapacity });
            Fails(S.Harvest(Tx(), 0), "STORAGE_FULL");
            Assert.AreEqual(PlotState.Ready, P(0).state);
        }

        [Test]
        public void SoilFatigueAfterThreeRepeats()
        {
            for (int i = 0; i < 3; i++)
            {
                Ok(S.Plant(Tx(), 0, "carrot", false));
                S.DevAdvance(20.1f);
                Ok(S.Harvest(Tx(), 0));
            }
            S.Save.items.Add(new ItemStack { id = "seed_carrot", qty = 5 });
            Ok(S.Plant(Tx(), 0, "carrot", false));
            Assert.AreEqual(4, P(0).repeatCount);
            Assert.AreEqual(20, S.FatiguePenaltyPct(P(0)));
            Ok(S.Plant(Tx(), 1, "carrot", false));
            Assert.AreEqual(0, S.FatiguePenaltyPct(P(1)), "fatigue is per plot");
        }

        [Test]
        public void FatigueFloorIsThirtyPercent()
        {
            P(0).repeatCount = 9;
            Assert.AreEqual(30, S.FatiguePenaltyPct(P(0)));
        }

        [Test]
        public void FertilizerBoostsYieldAndClearsFatigue()
        {
            S.Save.items.Add(new ItemStack { id = "fertilizer", qty = 2 });
            P(0).lastCrop = "lettuce"; P(0).repeatCount = 4;
            Ok(S.Plant(Tx(), 0, "lettuce", true));
            Assert.AreEqual(0, S.FatiguePenaltyPct(P(0)));
            Assert.AreEqual(2, S.Count("fertilizer"), "3 owned (1 from the tutorial) minus 1 used");
            Assert.AreEqual(5, S.ExpectedYield(P(0)));   // 4 * 1.2 = 4.8 -> 5
            Fails(S.Fertilize(Tx(), 0), "already fertilized");
        }

        [Test]
        public void ClearingAndBuyingAPlot()
        {
            Fails(S.BuyPlot(Tx(), 4), "Clear");
            Ok(S.ClearObstacle(Tx(), 4));
            Assert.AreEqual(PlotState.Cleared, P(4).state);
            Fails(S.BuyPlot(Tx(), 4), "Level 2");
            GiveLevel(2);
            int coins = S.Save.coins;
            Ok(S.BuyPlot(Tx(), 4));
            Assert.AreEqual(coins - 150, S.Save.coins);
            Assert.AreEqual(5, S.OwnedPlots(S.Here));
            Assert.AreEqual(200, Defs.PlotPrice("baguio", 6));
        }

        [Test]
        public void ClearedLandStaysClearedWhenShortOnCoins()
        {
            GiveLevel(2);
            S.ClearObstacle(Tx(), 4);
            S.Save.coins = 10;
            Fails(S.BuyPlot(Tx(), 4), "Need 140 more coins");
            Assert.AreEqual(PlotState.Cleared, P(4).state);
        }

        [Test]
        public void PlotPricesScaleByLocation()
        {
            Assert.AreEqual(1100, Defs.PlotPrice("baguio", 12));
            Assert.AreEqual(195, Defs.PlotPrice("ilocos", 5));
            Assert.AreEqual(240, Defs.PlotPrice("davao", 5));
        }

        [Test]
        public void TrenchOnlyDuringRainWarning()
        {
            Fails(S.DigTrench(Tx(), 0), "No heavy rain");
        }
    }

    public class EconomyTests : ServerTestBase
    {
        [SetUp] public void Login() => LoginNew();

        [Test]
        public void BuyingDeductsCoinsAndAddsItems()
        {
            int coins = S.Save.coins;
            Ok(S.Buy(Tx(), "seed_cabbage", 5));
            Assert.AreEqual(coins - 50, S.Save.coins);
            Assert.AreEqual(9, S.Count("seed_cabbage"));
        }

        [Test]
        public void InsufficientCoinsShowsShortfallAndDoesNothing()
        {
            S.Save.coins = 5;
            Fails(S.Buy(Tx(), "seed_cabbage", 1), "Need 5 more coins");
            Assert.AreEqual(5, S.Save.coins);
            Assert.AreEqual(4, S.Count("seed_cabbage"));
        }

        [Test]
        public void LevelLockedItemsCannotBeBought()
        {
            Fails(S.Buy(Tx(), "seed_potato", 1), "Reach Level 2");
            Fails(S.Buy(Tx(), "seed_rice", 1), "Ilocos Norte");
        }

        [Test]
        public void CommunityPointItemsRequireCp()
        {
            GiveLevel(4);
            S.Save.coins = 1000;
            Fails(S.Buy(Tx(), "seed_hybrid_lettuce", 1), "CP");
            S.Save.cp = 5;
            Ok(S.Buy(Tx(), "seed_hybrid_lettuce", 1));
            Assert.AreEqual(0, S.Save.cp);
        }

        [Test]
        public void DuplicateTransactionIsAppliedOnce()
        {
            string tx = Tx();
            int coins = S.Save.coins;
            Ok(S.Buy(tx, "seed_cabbage", 1));
            Ok(S.Buy(tx, "seed_cabbage", 1));
            Assert.AreEqual(coins - 10, S.Save.coins);
            Assert.AreEqual(5, S.Count("seed_cabbage"));
        }

        [Test]
        public void MarketPaysSeventyPercentWithNoXp()
        {
            S.Save.items.Add(new ItemStack { id = "crop_strawberry", qty = 10 });
            int coins = S.Save.coins, xp = S.Save.xp, cp = S.Save.cp;
            Ok(S.SellMarket(Tx(), "crop_strawberry", 10));
            Assert.AreEqual(coins + 80, S.Save.coins);   // floor(12 * 0.7) = 8 each
            Assert.AreEqual(xp, S.Save.xp);
            Assert.AreEqual(cp, S.Save.cp);
            Fails(S.SellMarket(Tx(), "crop_strawberry", 1), "do not have");
        }

        [Test]
        public void StorageUsesStacksOfTwentyAndToolsAreFree()
        {
            S.Save.items.RemoveAll(i => !i.id.StartsWith("tool_"));
            Assert.AreEqual(0, S.UsedSlots);
            S.Save.items.Add(new ItemStack { id = "crop_carrot", qty = 21 });
            Assert.AreEqual(2, S.UsedSlots);
        }

        [Test]
        public void StorageUpgradesRaiseCapacity()
        {
            GiveLevel(2);
            S.Save.coins = 1000;
            Ok(S.Buy(Tx(), "crate_small", 1));
            Assert.AreEqual(50, S.StorageCapacity);
        }

        [Test]
        public void LedgerRecordsEveryEconomyChange()
        {
            S.Buy(Tx(), "seed_cabbage", 2);
            var last = S.Save.ledger.Last();
            Assert.AreEqual("buy", last.type);
            Assert.AreEqual(-20, last.dCoins);
        }
    }

    public class ProgressionTests : ServerTestBase
    {
        [SetUp] public void Login() => LoginNew();

        [Test]
        public void LevelTwoAt100XpWithCoinBonus()
        {
            int coins = S.Save.coins;
            S.DevGrant(0, 99);
            Assert.AreEqual(1, S.Save.level);
            S.DevGrant(0, 1);
            Assert.AreEqual(2, S.Save.level);
            Assert.AreEqual(coins + 50, S.Save.coins);
            Assert.IsTrue(S.Outbox.Any(m => m.kind == "levelup" && m.level == 2));
        }

        [Test]
        public void MultipleLevelsAtOnceQueueInSequence()
        {
            S.DevGrant(0, 450);
            Assert.AreEqual(4, S.Save.level);
            CollectionAssert.AreEqual(new[] { 2, 3, 4 }, S.Outbox.Where(m => m.kind == "levelup").Select(m => m.level).ToArray());
            Assert.AreEqual(2, S.Count("fertilizer") - 1, "level 4 grants 2 fertilizer (plus 1 from the tutorial)");
            Assert.AreEqual(60, S.StorageCapacity);
        }

        [Test]
        public void StorageGrowsWithLevel()
        {
            Assert.AreEqual(40, Defs.BaseStorage(1));
            Assert.AreEqual(60, Defs.BaseStorage(3));
            Assert.AreEqual(80, Defs.BaseStorage(5));
            Assert.AreEqual(100, Defs.BaseStorage(8));
        }

        [Test]
        public void SoftCapAtLevelFifteen()
        {
            S.DevGrant(0, 20000);
            Assert.AreEqual(15, S.Save.level);
        }
    }
}
