using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEngine;
using Want = FieldsOfHope.Routine.Want;

namespace FieldsOfHope.Tests
{
    /// <summary>The village's day: home at dusk and asleep at night, a campfire some evenings, most people in from the rain.</summary>
    public class RoutineTests
    {
        static readonly string[] Villagers =
        {
            "feast_grey", "feast_top", "feast_brown", "feast_red", "bench_sitter", "waterer_top", "harvester", "crate_kid", "hoer",
            "waterer_cab", "hay_girl", "plank_man", "feast_back", "feast_tray", "path_lady", "path_man", "barn_basket", "barn_boy",
            "barn_back", "barn_lola", "store_overalls", "store_purple", "road_man", "road_lady", "woman", "lola", "boy",
        };
        static readonly HashSet<string> Workers = new HashSet<string> { "waterer_top", "harvester", "crate_kid", "hoer", "waterer_cab", "plank_man" };

        static bool Kid(string who) => FieldsOfHope.Villagers.Kids.Contains(who);
        static Want WantOf(string who, VillageTime t) => Routine.Wanted(who, t, false, Workers.Contains(who), Kid(who));
        static VillageTime At(int day, float hour, bool rain = false, int rainKey = 0) =>
            new VillageTime { day = day, hour = hour, campfireNight = Routine.CampfireNight(day), rain = rain, rainKey = rainKey };

        static int CampfireDay(int from) { int d = from; while (!Routine.CampfireNight(d)) d++; return d; }
        static int QuietDay(int from) { int d = from; while (Routine.CampfireNight(d)) d++; return d; }

        [Test]
        public void CampfireEveningsComeEverySecondOrThirdDay()
        {
            var nights = Enumerable.Range(20700, 120).Where(Routine.CampfireNight).ToList();
            var gaps = nights.Zip(nights.Skip(1), (a, b) => b - a).ToList();
            CollectionAssert.IsSubsetOf(gaps.Distinct().ToList(), new[] { 2, 3 }, "gaps: " + string.Join(",", gaps));
            CollectionAssert.Contains(gaps, 2); CollectionAssert.Contains(gaps, 3);
        }

        [Test]
        public void TheFireBurnsFromEightToNine()
        {
            Assert.AreEqual(0f, Routine.Fire(19f, true, false));
            Assert.AreEqual(1f, Routine.Fire(20f, true, false));
            Assert.AreEqual(1f, Routine.Fire(20.75f, true, false));
            Assert.That(Routine.Fire(21.1f, true, false), Is.InRange(0.05f, 0.99f), "burning down");
            Assert.AreEqual(0f, Routine.Fire(21.5f, true, false));
            Assert.AreEqual(0f, Routine.Fire(20.5f, false, false), "not a campfire evening");
            Assert.AreEqual(0f, Routine.Fire(20.5f, true, true), "rained off");
        }

        [Test]
        public void SomeOfTheVillageGathersAtTheCampfire()
        {
            int day = CampfireDay(20700);
            int camping = Villagers.Count(v => WantOf(v, At(day, 20.5f)) == Want.Camp);
            Assert.That(camping, Is.InRange(4, 16), "a good crowd, not everyone");
            Assert.AreEqual(0, Villagers.Count(v => WantOf(v, At(day, 19.5f)) == Want.Camp), "nobody before 7:45 pm");
            Assert.AreEqual(0, Villagers.Count(v => WantOf(v, At(day, 21.2f)) == Want.Camp), "everyone gone by 9:05 pm");
            Assert.AreEqual(0, Villagers.Count(v => WantOf(v, At(QuietDay(20700), 20.5f)) == Want.Camp), "no fire tonight");
            Assert.AreEqual(0, Villagers.Count(v => WantOf(v, At(day, 20.5f, rain: true)) == Want.Camp), "rained off");
            // not the same people every time
            var a = Villagers.Where(v => WantOf(v, At(day, 20.5f)) == Want.Camp).ToList();
            var b = Villagers.Where(v => WantOf(v, At(CampfireDay(day + 1), 20.5f)) == Want.Camp).ToList();
            CollectionAssert.AreNotEquivalent(a, b);
        }

        [Test]
        public void EveryoneIsHomeAndAsleepLateAtNight()
        {
            foreach (int day in new[] { CampfireDay(20700), QuietDay(20700) })
                foreach (var v in Villagers)
                {
                    foreach (var h in new[] { 22.5f, 23.9f, 0.5f, 3f, 4.9f })
                    {
                        Assert.AreEqual(Want.Home, WantOf(v, At(day, h)), v + " at " + h);
                        Assert.IsTrue(Routine.Asleep(v, day, h, Kid(v)), v + " asleep at " + h);
                    }
                    Assert.IsFalse(Routine.Asleep(v, day, 7f, Kid(v)), v + " up by 7 am");
                    Assert.IsFalse(Routine.Asleep(v, day, 20f, Kid(v)), v + " still up at 8 pm");
                }
        }

        [Test]
        public void EveryoneIsOutByDayAndHeadsHomeAtTheirOwnTime()
        {
            int day = QuietDay(20700);
            foreach (var v in Villagers) Assert.AreEqual(Want.Out, WantOf(v, At(day, 12f)), v);
            var home = Villagers.Select(v => Routine.HomeAt(v, day, false)).ToList();
            Assert.That(home.Min(), Is.GreaterThanOrEqualTo(17.9f)); Assert.That(home.Max(), Is.LessThan(19.2f));
            Assert.That(home.Distinct().Count(), Is.GreaterThan(20), "not all at once");
            Assert.That(Villagers.Count(v => WantOf(v, At(day, 18.5f)) == Want.Home), Is.InRange(3, 25), "a few at a time at dusk");
            // farmers are out first in the morning
            Assert.That(Workers.Average(w => Routine.OutAt(w, day, true)), Is.LessThan(Villagers.Except(Workers).Average(v => Routine.OutAt(v, day, false))));
        }

        [Test]
        public void InTheRainMostGoInButSomeStayOut()
        {
            int day = QuietDay(20700);
            int indoors = 0, outside = 0, total = 0;
            var stayed = new HashSet<Want>();
            for (int shower = 1; shower <= 6; shower++)
                foreach (var v in Villagers)
                {
                    var w = WantOf(v, At(day, 12f, rain: true, rainKey: shower * 7919));
                    total++;
                    if (w == Want.Indoors) indoors++; else { outside++; stayed.Add(w); }
                }
            Assert.That(indoors, Is.GreaterThan(total / 2), "most people go in");
            Assert.That(outside, Is.GreaterThan(0), "a few stay out");
            CollectionAssert.IsSubsetOf(stayed.ToList(), new[] { Want.Out, Want.Shelter, Want.Play });
            Assert.That(stayed.Count, Is.GreaterThanOrEqualTo(2), "farmers carry on, others watch from doorways, children play");
            // each shower, different people
            var first = Villagers.Where(v => WantOf(v, At(day, 12f, true, 1)) != Want.Indoors).ToList();
            var second = Villagers.Where(v => WantOf(v, At(day, 12f, true, 2)) != Want.Indoors).ToList();
            CollectionAssert.AreNotEquivalent(first, second);
            // at night the rain changes nothing: everyone is home
            foreach (var v in Villagers) Assert.AreEqual(Want.Home, WantOf(v, At(day, 23f, true, 5)), v);
        }

        [Test]
        public void TheCampfireCircleLeavesTheFrontOpen()
        {
            var fire = new Campfire(new MapSpot { kind = "campfire", x = 600, y = 400 });
            for (int i = 0; i < fire.Count; i++)
            {
                var d = fire.Seat(i) - fire.Center;
                Assert.IsFalse(d.y > 10f && Mathf.Abs(d.x) < 30f, "seat " + i + " would hide the flames");
                Assert.That(d.magnitude, Is.GreaterThan(20f), "nobody stands in the fire");
            }
            var seats = new HashSet<int>();
            for (int i = 0; i < fire.Count; i++) Assert.IsTrue(seats.Add(fire.Claim("person " + i)));
            Assert.IsFalse(fire.HasRoom);
            Assert.AreEqual(-1, fire.Claim("one too many"));
            Assert.AreEqual(fire.Claim("person 3"), fire.Claim("person 3"), "claiming again keeps the same place");
            fire.Release("person 3");
            Assert.IsTrue(fire.HasRoom);
        }
    }
}
