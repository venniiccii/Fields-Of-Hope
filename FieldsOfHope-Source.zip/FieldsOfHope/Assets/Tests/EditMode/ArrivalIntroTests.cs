using NUnit.Framework;

namespace FieldsOfHope.Tests
{
    /// <summary>The message shown on a first trip to a location belongs to that location.</summary>
    public class ArrivalIntroTests
    {
        [Test]
        public void BaguioHasNoArrivalIntroBecauseTheTutorialWelcomesYou() =>
            Assert.IsNull(Defs.Loc("baguio").arrivalIntro);

        [Test]
        public void EachArrivalIntroNamesItsOwnLocation()
        {
            foreach (var l in Defs.Locations)
            {
                if (l.arrivalIntro == null) continue;
                StringAssert.StartsWith("Welcome to " + l.name + "!", l.arrivalIntro, l.id);
                foreach (var other in Defs.Locations)
                    if (other != l) StringAssert.DoesNotContain(other.name, l.arrivalIntro, l.id + " mentions " + other.id);
            }
            Assert.IsNotNull(Defs.Loc("ilocos").arrivalIntro);
            Assert.IsNotNull(Defs.Loc("davao").arrivalIntro);
        }
    }
}
