using NUnit.Framework;

namespace FieldsOfHope.Tests
{
    /// <summary>Name-only accounts: a new name starts a farm, the same name (any case) continues it.</summary>
    public class PlayAsTests : ServerTestBase
    {
        [Test]
        public void NewNameStartsAFreshFarm()
        {
            Ok(S.PlayAs(User, out var token));
            Assert.AreEqual(User, S.Save.username);
            Assert.AreEqual(Defs.StartCoins, S.Save.coins);
            Assert.IsNotNull(token);
        }

        [Test]
        public void SameNameContinuesTheFarm()
        {
            Ok(S.PlayAs(User, out _));
            string id = S.Save.accountId;
            S.Save.coins = 999; S.Persist();
            S.Logout();
            Ok(S.PlayAs(User.ToUpperInvariant(), out _));
            Assert.AreEqual(id, S.Save.accountId);
            Assert.AreEqual(999, S.Save.coins);
        }

        [Test]
        public void ProgressSurvivesARestart()
        {
            Ok(S.PlayAs(User, out var token));
            S.Save.coins = 777; S.Persist();
            S = new GameServer(dir);            // the game is closed and opened again
            Ok(S.ResumeSession(token, out _));
            Assert.AreEqual(777, S.Save.coins);
        }

        [Test]
        public void InvalidOrBlockedNamesAreRejected()
        {
            Fails(S.PlayAs("1bad", out _), "start with a letter");
            Fails(S.PlayAs("ab", out _), "4 to 16");
            Fails(S.PlayAs("gagoman", out _), "different username");
            Assert.IsNull(S.Save);
        }

        [Test]
        public void DeviceFarmsListsMostRecentFirst()
        {
            Ok(S.PlayAs("Ana_Grower", out _)); S.Logout();
            Ok(S.PlayAs("Leo_Planter", out _)); S.Logout();
            Ok(S.PlayAs("Ana_Grower", out _)); S.Logout();
            CollectionAssert.AreEqual(new[] { "Ana_Grower", "Leo_Planter" }, S.DeviceFarms());
        }
    }
}
