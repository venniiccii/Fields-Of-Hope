using System.Linq;
using NUnit.Framework;

namespace FieldsOfHope.Tests
{
    public class ValidationTests
    {
        [TestCase("abc", false)]                 // too short
        [TestCase("abcd", true)]
        [TestCase("a234567890123456", true)]    // 16 chars
        [TestCase("a2345678901234567", false)]  // 17 chars
        [TestCase("1abc", false)]                // must start with a letter
        [TestCase("ab cd", false)]
        [TestCase("ab-cd", false)]
        [TestCase("Juan_Farmer", true)]
        public void UsernameRules(string name, bool valid) =>
            Assert.AreEqual(valid, GameServer.ValidateUsername(name) == null, GameServer.ValidateUsername(name));

        [TestCase("short1", false)]
        [TestCase("longenough", false)]          // no number
        [TestCase("12345678", false)]            // no letter
        [TestCase("harvest2026", true)]
        public void PasswordRules(string pw, bool valid) =>
            Assert.AreEqual(valid, GameServer.ValidatePassword(pw, "someone") == null);

        [Test]
        public void PasswordCannotEqualUsername() =>
            Assert.IsNotNull(GameServer.ValidatePassword("Farmer2026", "farmer2026"));
    }

    public class AuthTests : ServerTestBase
    {
        [Test]
        public void RegisterRequiresMatchingPasswords()
        {
            var e = S.Register(User, Pass, Pass + "x");
            Assert.AreEqual("Passwords do not match", e["confirm"]);
        }

        [Test]
        public void UsernameIsUniqueCaseInsensitive()
        {
            Assert.IsNull(S.Register(User, Pass, Pass));
            var e = S.Register(User.ToUpperInvariant(), Pass, Pass);
            Assert.AreEqual("That username is already taken. Try another.", e["username"]);
        }

        [Test]
        public void InappropriateUsernameRejected() =>
            Assert.IsTrue(S.Register("shithead1", Pass, Pass).ContainsKey("username"));

        [Test]
        public void PasswordIsStoredAsSaltedHash()
        {
            S.Register(User, Pass, Pass);
            var json = System.IO.File.ReadAllText(System.IO.Path.Combine(dir, "accounts.json"));
            StringAssert.DoesNotContain(Pass, json);
            StringAssert.Contains("\"salt\"", json);
        }

        [Test]
        public void RegistrationDoesNotAutoLogin()
        {
            S.Register(User, Pass, Pass);
            Assert.IsNull(S.Save);
        }

        [Test]
        public void WrongUsernameAndWrongPasswordGiveTheSameMessage()
        {
            S.Register(User, Pass, Pass);
            var a = S.Login(User, "wrongpass1", out _);
            var b = S.Login("Nobody_here", Pass, out _);
            Assert.IsFalse(a.ok); Assert.IsFalse(b.ok);
            Assert.AreEqual("Username or password is incorrect.", a.message);
            Assert.AreEqual(a.message, b.message);
        }

        [Test]
        public void FiveFailuresLockTheAccount()
        {
            S.Register(User, Pass, Pass);
            for (int i = 0; i < 5; i++) S.Login(User, "wrongpass" + i, out _);
            var r = S.Login(User, Pass, out _);
            Assert.IsFalse(r.ok);
            StringAssert.Contains("Too many attempts", r.message);
            Assert.Greater(S.LockSecondsRemaining(User), 200);
        }

        [Test]
        public void LoginLoadsStartingState()
        {
            LoginNew(false);
            var s = S.Save;
            Assert.AreEqual(Defs.StartCoins, s.coins);
            Assert.AreEqual(0, s.cp);
            Assert.AreEqual(1, s.level);
            Assert.AreEqual("baguio", s.currentLocation);
            Assert.AreEqual(4, S.OwnedPlots(S.Here));
            Assert.AreEqual(6, S.Count("seed_lettuce"));
            Assert.AreEqual(4, S.Count("seed_cabbage"));
            Assert.AreEqual(4, S.Count("seed_carrot"));
            foreach (var t in new[] { "tool_can", "tool_shovel", "tool_basket", "tool_axe" }) Assert.IsTrue(S.Has(t), t);
            Assert.AreEqual(40, S.StorageCapacity);
            Assert.IsFalse(s.tutorialDone);
            Assert.IsTrue(S.Here.requests.Count >= 3, "day-1 requests generated");
            Assert.AreEqual(4, s.quests.Count);
        }

        [Test]
        public void ResumeSessionWithStoredToken()
        {
            S.Register(User, Pass, Pass);
            S.Login(User, Pass, out var token);
            S.Suspend();
            var r = S.ResumeSession(token, out var newToken);
            Assert.IsTrue(r.ok, r.message);
            Assert.AreEqual(User, S.Save.username);
            Assert.AreNotEqual(token, newToken, "tokens rotate on every session");
        }

        [Test]
        public void NewLoginEndsTheOlderSession()
        {
            S.Register(User, Pass, Pass);
            S.Login(User, Pass, out var first);
            var other = new GameServer(dir);
            Assert.IsTrue(other.Login(User, Pass, out _).ok);
            Assert.IsFalse(S.ResumeSession(first, out _).ok);
        }

        [Test]
        public void LogoutInvalidatesTheSession()
        {
            S.Register(User, Pass, Pass);
            S.Login(User, Pass, out var token);
            S.Logout();
            Assert.IsNull(S.Save);
            Assert.IsFalse(S.ResumeSession(token, out _).ok);
        }

        [Test]
        public void TutorialRewardIsGrantedOnce()
        {
            LoginNew(false);
            Ok(S.CompleteTutorial(Tx()));
            Assert.AreEqual(Defs.StartCoins + 50, S.Save.coins);
            Assert.AreEqual(1, S.Count("fertilizer"));
            S.ReplayTutorial();
            Ok(S.CompleteTutorial(Tx()));
            Assert.AreEqual(Defs.StartCoins + 50, S.Save.coins);
            Assert.AreEqual(1, S.Count("fertilizer"));
        }

        [Test]
        public void TimezoneChangeLimitedToOncePerWeek()
        {
            LoginNew();
            Ok(S.SetTimezone(480));
            Assert.AreEqual(480, S.Save.tzOffsetMin);
            Fails(S.SetTimezone(0), "7 days");
        }
    }
}
