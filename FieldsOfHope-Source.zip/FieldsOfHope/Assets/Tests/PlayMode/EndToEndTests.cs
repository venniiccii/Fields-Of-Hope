using System;
using System.Collections;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace FieldsOfHope.Tests
{
    /// <summary>Drives the real UI the way a player would: buttons, input fields, HUD, hotbar and plots.</summary>
    public class EndToEndTests
    {
        string dir;
        GameApp App => GameApp.I;
        GameServer S => GameApp.I.Server;

        [UnitySetUp]
        public IEnumerator SetUp()
        {
            foreach (var old in Object.FindObjectsByType<GameApp>(FindObjectsSortMode.None)) Object.DestroyImmediate(old.gameObject);
            dir = Path.Combine(Path.GetTempPath(), "foh_e2e_" + Guid.NewGuid().ToString("N"));
            GameApp.DataRootOverride = dir;
            PlayerPrefs.DeleteKey("foh_session");
            new GameObject("Fields of Hope").AddComponent<GameApp>();
            yield return null;
            yield return null;
        }

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            if (App != null) Object.DestroyImmediate(App.gameObject);
            GameApp.DataRootOverride = null;
            PlayerPrefs.DeleteKey("foh_session");
            yield return null;
            try { Directory.Delete(dir, true); } catch { /* best effort */ }
        }

        // ------------------------------------------------------------------ helpers
        static Button[] Buttons() => Object.FindObjectsByType<Button>(FindObjectsSortMode.None).Where(b => b.isActiveAndEnabled).ToArray();

        static Button ByLabel(string label, Func<Button, bool> where = null)
        {
            var b = Buttons().FirstOrDefault(x => x.GetComponentInChildren<Text>()?.text == label && (where == null || where(x)));
            Assert.IsNotNull(b, "No visible button labelled '" + label + "'");
            return b;
        }

        static Button ByName(string name)
        {
            var b = Buttons().FirstOrDefault(x => x.gameObject.name == name);
            Assert.IsNotNull(b, "No visible button named '" + name + "'");
            return b;
        }

        static IEnumerator Click(Button b)
        {
            Assert.IsTrue(b.interactable, b.name + " is disabled");
            b.onClick.Invoke();
            yield return null;
            yield return null;
        }

        static bool Under(Component c, string ancestor)
        {
            for (var t = c.transform; t != null; t = t.parent) if (t.name == ancestor) return true;
            return false;
        }

        Button PlotTile(int index) => App.Farm.Plots[index].root.Find("Tile").GetComponent<Button>();

        static InputField[] Inputs() => Object.FindObjectsByType<InputField>(FindObjectsSortMode.None)
            .Where(i => i.isActiveAndEnabled).OrderByDescending(i => i.transform.position.y).ToArray();

        /// <summary>START, type a farmer name, Play: a new name makes a new farm.</summary>
        IEnumerator PlayAs(string user)
        {
            yield return Click(ByName("btn_start"));
            var f = Inputs();
            Assert.AreEqual(1, f.Length, "only a name is asked for");
            f[0].text = user;
            yield return Click(ByLabel("Play"));
            Assert.IsNotNull(App.Farm, "farm screen should be open after entering a name");
        }

        // ------------------------------------------------------------------ tests
        [UnityTest]
        public IEnumerator TitleShowsStartAndQuitWithConfirmation()
        {
            Assert.IsNotNull(ByName("btn_start"));
            yield return Click(ByName("btn_quit"));
            Assert.IsNotNull(ByLabel("Confirm"));
            yield return Click(ByLabel("Cancel"));
            Assert.IsFalse(App.ModalOpen);
        }

        [UnityTest]
        public IEnumerator InvalidNameShowsInlineError()
        {
            yield return Click(ByName("btn_start"));
            Inputs()[0].text = "1bad";
            yield return Click(ByLabel("Play"));
            Assert.IsTrue(Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t => t.text == "Username must start with a letter."));
            Assert.IsNull(S.Save);
        }

        [UnityTest]
        public IEnumerator ReturningPlayerContinuesTheirFarm()
        {
            yield return PlayAs("Maria_Farm");
            S.Save.coins = 4321; S.Persist();
            yield return Click(ByName("Reply 1"));                       // skip the tutorial so Settings is reachable
            yield return Click(ByLabel("Skip"));
            yield return Click(ByLabel("Let's farm!"));
            yield return Click(ByName("hud_settings"));
            yield return Click(ByLabel("Logout", b => Under(b, "Panels")));
            yield return Click(ByLabel("Logout", b => Under(b, "Popups")));

            yield return Click(ByName("btn_start"));
            yield return Click(ByLabel("Continue as Maria_Farm"));       // farms on this device are listed
            Assert.IsNotNull(App.Farm);
            Assert.AreEqual(4321 + 50, S.Save.coins, "progress (plus the tutorial reward) is still there");
            Assert.IsTrue(S.Save.tutorialDone);
        }

        [UnityTest]
        public IEnumerator FullTutorialThroughTheUi()
        {
            yield return PlayAs("Juan_Farmer");
            Assert.IsTrue(App.Tutorial.Active);

            yield return Click(ByName("Reply 0"));                       // intro dialogue
            for (int i = 0; i < 7; i++) yield return Click(ByLabel("Next"));   // HUD tour
            yield return Click(ByName("Slot seedbag"));                  // inventory
            Assert.AreEqual("inventory", App.OpenPanel?.Key);
            yield return Click(ByLabel("Next"));
            Assert.IsNull(App.OpenPanel);

            yield return Click(PlotTile(0));                             // plant lettuce
            Assert.AreEqual("plot", App.OpenPanel?.Key);
            yield return Click(ByLabel("Plant"));
            Assert.AreEqual(PlotState.Growing, S.PlotAt(0).state);
            Assert.AreEqual(5, S.Count("seed_lettuce"));
            Assert.IsTrue(S.PlotAt(0).tutorial, "tutorial lettuce uses the 2-minute timer");

            yield return Click(ByName("Slot can"));                      // water
            yield return Click(PlotTile(0));
            Assert.AreEqual(1, S.PlotAt(0).waterings);
            yield return Click(ByLabel("Next"));                         // progress bar explanation

            S.DevAdvance(2.1f);                                          // wait for the 2-minute lettuce
            yield return new WaitForSecondsRealtime(0.6f);
            Assert.AreEqual(PlotState.Ready, S.PlotAt(0).state);

            yield return Click(ByName("Slot basket"));                   // harvest
            yield return Click(PlotTile(0));
            Assert.AreEqual(4, S.Count("crop_lettuce"));
            Assert.AreEqual(PlotState.Empty, S.PlotAt(0).state);

            yield return Click(ByName("Reply 0"));                       // "Yes, I'd like to sell my harvest."
            Assert.AreEqual("community", App.OpenPanel?.Key);
            int coinsBefore = S.Save.coins;
            yield return Click(ByLabel("Deliver 4"));
            Assert.AreEqual(coinsBefore + 20, S.Save.coins);
            Assert.AreEqual(4, S.Save.cp);
            yield return Click(ByLabel("Next"));

            yield return Click(ByName("hud_shop"));                      // buy cheapest seed
            var card = GameObject.Find("Lettuce Seeds");
            Assert.IsNotNull(card, "Featured tab shows the cheapest local seed");
            yield return Click(card.GetComponentsInChildren<Button>().First(b => b.GetComponentInChildren<Text>()?.text == "Buy 1"));
            Assert.AreEqual(5 + 1, S.Count("seed_lettuce"));
            yield return Click(ByLabel("Next"));

            yield return Click(ByName("hud_quests"));
            Assert.AreEqual("quests", App.OpenPanel?.Key);
            yield return Click(ByLabel("Next"));
            yield return Click(ByName("hud_map"));
            Assert.AreEqual("map", App.OpenPanel?.Key);
            yield return Click(ByLabel("Close Map"));

            Assert.IsTrue(S.Save.tutorialDone);
            Assert.AreEqual(Defs.StartCoins + 20 - 8 + 50, S.Save.coins, "delivery + seed purchase + tutorial reward");
            Assert.AreEqual(1, S.Count("fertilizer"));
            Assert.IsTrue(App.ModalOpen, "tutorial complete message");
            yield return Click(ByLabel("Let's farm!"));
        }

        [UnityTest]
        public IEnumerator SkipTutorialThenPlayAndLogout()
        {
            yield return PlayAs("Ana_Grower");
            yield return Click(ByName("Reply 1"));                       // "Skip the tutorial" from the intro
            yield return Click(ByLabel("Skip"));
            Assert.IsTrue(S.Save.tutorialDone);
            yield return Click(ByLabel("Let's farm!"));

            // plant cabbage through the plot menu, check the HUD reflects state
            yield return Click(PlotTile(1));
            var row = Object.FindObjectsByType<Text>(FindObjectsSortMode.None).First(t => t.text.StartsWith("Cabbage")).transform.parent;
            yield return Click(row.GetComponentsInChildren<Button>().First(b => b.GetComponentInChildren<Text>()?.text == "Plant"));
            Assert.AreEqual("cabbage", S.PlotAt(1).crop);

            // clear land with the axe tool
            yield return Click(ByName("Slot axe"));
            yield return Click(PlotTile(4));
            yield return new WaitForSecondsRealtime(1f);
            Assert.AreEqual(PlotState.Cleared, S.PlotAt(4).state);

            // locked location shows its checklist
            yield return Click(ByName("hud_map"));
            yield return Click(ByName("Pin ilocos"));
            Assert.IsTrue(Object.FindObjectsByType<Text>(FindObjectsSortMode.None).Any(t => t.text.Contains("Reach Level 5")));
            Assert.IsFalse(ByLabel("Locked", b => Under(b, "Card")).interactable, "locked locations cannot be paid for or travelled to");
            yield return Click(ByLabel("Close Map"));

            // logout returns to the title and clears the stored session
            yield return Click(ByName("hud_settings"));
            yield return Click(ByLabel("Logout", b => Under(b, "Panels")));
            yield return Click(ByLabel("Logout", b => Under(b, "Popups")));
            Assert.IsNull(S.Save);
            Assert.IsNotNull(ByName("btn_start"));
            Assert.IsFalse(PlayerPrefs.HasKey("foh_session"));
        }

        [UnityTest]
        public IEnumerator StartResumesAStoredSession()
        {
            yield return PlayAs("Leo_Planter");
            yield return Click(ByName("Reply 0"));
            yield return Click(ByLabel("Skip tutorial"));                // skip from a later callout
            yield return Click(ByLabel("Skip"));
            yield return Click(ByLabel("Let's farm!"));
            yield return Click(ByName("hud_settings"));
            yield return Click(ByLabel("Go"));                           // Return to Title keeps the session
            yield return Click(ByName("btn_start"));
            Assert.IsNotNull(App.Farm, "START skips login when a valid session is stored");
            Assert.AreEqual("Leo_Planter", S.Save.username);
        }
    }
}
