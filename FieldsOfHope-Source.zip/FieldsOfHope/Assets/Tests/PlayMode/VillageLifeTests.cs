using System;
using System.Collections;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace FieldsOfHope.Tests
{
    /// <summary>The real farm at different times of day: everyone indoors and asleep at night, a crowd round the campfire
    /// on a campfire evening, most people in from the rain but not all; and the farm zooms.</summary>
    public class VillageLifeTests
    {
        string dir;
        GameApp App => GameApp.I;
        GameServer S => GameApp.I.Server;

        [UnitySetUp]
        public IEnumerator SetUp()
        {
            foreach (var old in Object.FindObjectsByType<GameApp>(FindObjectsSortMode.None)) Object.DestroyImmediate(old.gameObject);
            dir = Path.Combine(Path.GetTempPath(), "foh_village_" + Guid.NewGuid().ToString("N"));
            GameApp.DataRootOverride = dir;
            PlayerPrefs.DeleteKey("foh_session");
            new GameObject("Fields of Hope").AddComponent<GameApp>();
            yield return null;
            yield return null;
            // a new farm, tutorial skipped
            Click("btn_start");
            yield return null;
            Object.FindObjectsByType<InputField>(FindObjectsSortMode.None).First(i => i.isActiveAndEnabled).text = "Village_Test";
            ClickLabel("Play");
            yield return null; yield return null;
            Click("Reply 1"); yield return null;
            ClickLabel("Skip"); yield return null;
            ClickLabel("Let's farm!"); yield return null;
            Assert.IsNotNull(App.Farm);
        }

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            if (App != null) Object.DestroyImmediate(App.gameObject);
            GameApp.DataRootOverride = null;
            PlayerPrefs.DeleteKey("foh_session");
            yield return null;
            try { Directory.Delete(dir, true); } catch { /* best effort */ }
        }

        static void Click(string name) =>
            Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b => b.isActiveAndEnabled && b.name == name).onClick.Invoke();

        static void ClickLabel(string label) =>
            Object.FindObjectsByType<Button>(FindObjectsSortMode.None).First(b => b.isActiveAndEnabled && b.GetComponentInChildren<Text>()?.text == label).onClick.Invoke();

        /// <summary>Moves the game clock to <paramref name="hour"/> on local day <paramref name="day"/> and shows the farm afresh.</summary>
        IEnumerator At(int day, float hour)
        {
            long target = day * 86400000L + (long)(hour * 3600000) - S.Save.tzOffsetMin * 60000L;
            S.Save.devClockOffsetMs = target - DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            App.CloseAllPanels();
            App.Farm.RebuildLocation();
            for (int i = 0; i < 5; i++) yield return null;
        }

        int Today => S.Today;
        static int Next(int from, bool campfire) { int d = from; while (Routine.CampfireNight(d) != campfire) d++; return d; }

        Image[] People => App.Farm.Map.Layer.GetComponentsInChildren<Image>(true).Where(i => i.name.StartsWith("Walker ")).ToArray();

        [UnityTest]
        public IEnumerator AtNightEveryoneIsIndoorsAndAsleep()
        {
            yield return At(Next(Today + 1, false), 23.5f);
            var people = People;
            Assert.That(people.Length, Is.GreaterThanOrEqualTo(25), "all the villagers can walk now");
            Assert.AreEqual(0, people.Count(p => p.enabled), "nobody outside at half past eleven at night");
            int asleep = App.Farm.Map.Indoors.Values.Sum(n => n.asleep), awake = App.Farm.Map.Indoors.Values.Sum(n => n.awake);
            Assert.AreEqual(people.Length, asleep + awake);
            Assert.AreEqual(0, awake, "everyone is asleep");
            Assert.That(App.Farm.Map.Indoors.Count, Is.GreaterThanOrEqualTo(2), "in their own houses, not all in one");
        }

        [UnityTest]
        public IEnumerator OnACampfireEveningAGroupGathersRoundTheFire()
        {
            yield return At(Next(Today + 1, true), 20.4f);
            var fire = App.Farm.Map.Campfire;
            Assert.IsNotNull(fire, "Baguio has a campfire");
            var round = People.Where(p => p.enabled && Vector2.Distance(App.Farm.WorldToBg(p.rectTransform.anchoredPosition), fire.Center) < 100f).ToList();
            Assert.That(round.Count, Is.InRange(3, 13), "a group round the fire");
            var flame = App.Farm.World.GetComponentsInChildren<Image>().FirstOrDefault(i => i.name == "Flame");
            Assert.IsTrue(flame != null && flame.enabled, "the fire is burning");
            // on other evenings the fire stays out and nobody is there
            yield return At(Next(Today + 1, false), 20.4f);
            Assert.IsFalse(App.Farm.World.GetComponentsInChildren<Image>().First(i => i.name == "Flame").enabled);
        }

        [UnityTest]
        public IEnumerator InTheRainMostGoInButNotEveryone()
        {
            yield return At(Next(Today + 1, false), 11f);
            Assert.That(People.Count(p => p.enabled), Is.GreaterThanOrEqualTo(25), "late morning: everyone is out");
            S.DevTrigger("rain");
            S.DevAdvance(31);                                             // past the warning: it is raining
            Assert.IsNotNull(S.ActiveEvent(S.Here, "rain"));
            App.CloseAllPanels();
            App.Farm.RebuildLocation();
            for (int i = 0; i < 5; i++) yield return null;
            var people = People;
            int outside = people.Count(p => p.enabled);
            Assert.That(people.Length - outside, Is.GreaterThan(people.Length / 2), "most are indoors");
            Assert.That(outside, Is.GreaterThanOrEqualTo(1), "someone braves the rain (the farmhand at least)");
        }

        Image[] AnimalImages => App.Farm.Map.Layer.GetComponentsInChildren<Image>(true).Where(i => i.name.StartsWith("Animal ")).ToArray();

        [UnityTest]
        public IEnumerator AnimalsWanderByDayAndSleepAtNight()
        {
            yield return At(Next(Today + 1, false), 23.5f);
            var animals = AnimalImages;
            Assert.That(animals.Length, Is.GreaterThanOrEqualTo(6), "Baguio's animals");
            foreach (var a in animals) StringAssert.EndsWith("_sleep", a.sprite.texture.name, a.name + " asleep at night");

            yield return At(Next(Today + 1, false), 10f);
            animals = AnimalImages;
            foreach (var a in animals) Assert.IsFalse(a.sprite.texture.name.EndsWith("_sleep"), a.name + " awake by day");
            var before = animals.Select(a => a.rectTransform.anchoredPosition).ToArray();
            for (float t = 0; t < 8f; t += Time.unscaledDeltaTime) yield return null;
            int moved = animals.Where((a, i) => Vector2.Distance(a.rectTransform.anchoredPosition, before[i]) > 4f).Count();
            Assert.That(moved, Is.GreaterThanOrEqualTo(2), "they wander about");
        }

        [UnityTest]
        public IEnumerator TheClockShowsTheMoonAtNight()
        {
            yield return At(Next(Today + 1, false), 23f);
            yield return new WaitForSecondsRealtime(1.2f);
            Assert.IsTrue(App.Farm.Root.GetComponentsInChildren<Image>().First(i => i.name == "Moon").enabled);
            yield return At(Next(Today + 1, false), 12f);
            yield return new WaitForSecondsRealtime(1.2f);
            Assert.IsFalse(App.Farm.Root.GetComponentsInChildren<Image>(true).First(i => i.name == "Moon").enabled);
        }

        [UnityTest]
        public IEnumerator TheFarmZoomsInAndOut()
        {
            var farm = App.Farm;
            for (int i = 0; i < 3; i++) farm.ZoomBy(1.25f, Vector2.zero);
            for (int i = 0; i < 40; i++) yield return null;
            Assert.That(farm.ZoomLevel, Is.GreaterThan(1.5f));
            Assert.AreEqual(farm.ZoomLevel, farm.World.localScale.x, 0.001f);
            for (int i = 0; i < 12; i++) farm.ZoomBy(0.8f, Vector2.zero);
            for (int i = 0; i < 40; i++) yield return null;
            // zoomed all the way out, the farm still covers the screen
            var view = App.CanvasRect.rect.size;
            Assert.That(farm.World.rect.width * farm.ZoomLevel, Is.GreaterThanOrEqualTo(view.x - 1f));
            Assert.That(farm.World.rect.height * farm.ZoomLevel, Is.GreaterThanOrEqualTo(view.y - 1f));
            farm.Home(true);
            Assert.AreEqual(1f, farm.ZoomLevel);
        }
    }
}
