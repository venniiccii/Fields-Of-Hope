mergeInto(LibraryManager.library, {
  // Persist Application.persistentDataPath (IndexedDB) after each save.
  // Saves that arrive while a sync is running are coalesced into one follow-up sync.
  FoH_SyncFs: function () {
    if (typeof FS === 'undefined' || !FS.syncfs) return;
    var s = Module.fohSync || (Module.fohSync = { busy: false, again: false });
    if (s.busy) { s.again = true; return; }
    s.busy = true;
    (function run() {
      s.again = false;
      FS.syncfs(false, function (err) {
        if (err) console.warn('FoH save sync failed', err);
        if (s.again) run(); else s.busy = false;
      });
    })();
  },
  // Browser's local UTC offset in minutes (TimeZoneInfo.Local is UTC under WebGL).
  FoH_TzOffsetMinutes: function () {
    return -new Date().getTimezoneOffset();
  }
});
