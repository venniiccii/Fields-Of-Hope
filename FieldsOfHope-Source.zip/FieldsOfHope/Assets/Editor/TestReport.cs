using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.TestTools.TestRunner.Api;
using UnityEngine;

namespace FieldsOfHope.EditorTools
{
    /// <summary>Runs the EditMode or PlayMode suite and writes a plain-text report to TestResults/ (menu: Fields of Hope > Tests).</summary>
    [InitializeOnLoad]
    public static class TestReport
    {
        public static string ReportDir => Path.GetFullPath(Path.Combine(Application.dataPath, "..", "TestResults"));

        // re-registered after every domain reload so PlayMode runs (which reload) still get a report
        static TestReport() => ScriptableObject.CreateInstance<TestRunnerApi>().RegisterCallbacks(new Writer());

        [MenuItem("Fields of Hope/Tests/Run Unit + Integration (EditMode)")]
        public static void RunEditMode() => Run(TestMode.EditMode, "FieldsOfHope.Tests.EditMode");

        [MenuItem("Fields of Hope/Tests/Run End-to-End (PlayMode)")]
        public static void RunPlayMode() => Run(TestMode.PlayMode, "FieldsOfHope.Tests.PlayMode");

        public static void Run(TestMode mode, string assembly)
        {
            Directory.CreateDirectory(ReportDir);
            File.WriteAllText(Path.Combine(ReportDir, mode + ".txt"), "RUNNING\n");
            ScriptableObject.CreateInstance<TestRunnerApi>()
                .Execute(new ExecutionSettings(new Filter { testMode = mode, assemblyNames = new[] { assembly } }));
        }

        class Writer : ICallbacks
        {
            public void RunStarted(ITestAdaptor t) { }
            public void TestStarted(ITestAdaptor t) { }
            public void TestFinished(ITestResultAdaptor r) { }

            public void RunFinished(ITestResultAdaptor r)
            {
                Directory.CreateDirectory(ReportDir);
                var path = Path.Combine(ReportDir, r.Test.TestMode + ".txt");
                var sb = new StringBuilder();
                sb.AppendLine($"PASS {r.PassCount}  FAIL {r.FailCount}  SKIP {r.SkipCount}  ({r.Duration:0.0}s)");
                Walk(r, sb);
                File.WriteAllText(path, sb.ToString());
                Debug.Log("[Tests] " + Path.GetFileName(path) + ": " + r.PassCount + " passed, " + r.FailCount + " failed. Report: " + path);
            }

            static void Walk(ITestResultAdaptor r, StringBuilder sb)
            {
                if (r.HasChildren) { foreach (var c in r.Children) Walk(c, sb); return; }
                sb.AppendLine((r.TestStatus == TestStatus.Passed ? "  ok   " : "  FAIL ") + r.FullName);
                if (r.TestStatus != TestStatus.Passed)
                {
                    sb.AppendLine("       " + r.Message?.Trim().Replace("\n", "\n       "));
                    var st = r.StackTrace?.Split('\n');
                    if (st != null) for (int i = 0; i < Mathf.Min(4, st.Length); i++) sb.AppendLine("       " + st[i].Trim());
                }
            }
        }
    }
}
