using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace FieldsOfHope.EditorTools
{
    /// <summary>
    /// One-click builds. Evaluation previews carry a watermark and stop working after the expiry date;
    /// release builds have neither. Output goes to Builds/ next to Assets/.
    /// </summary>
    public static class BuildTools
    {
        const string ConfigPath = "Assets/Resources/preview_config.json";
        const string Scene = "Assets/Scenes/SampleScene.unity";
        public static int PreviewDays = 14;
        /// <summary>Evaluation builds with every location open to visit (for the client to inspect), without unlocking them in saves.</summary>
        public static bool OpenAllLocations = false;

        // Lets the browser decompress the Brotli files natively (much faster than the JS fallback)
        const string VercelConfig = @"{
  ""headers"": [
    { ""source"": ""/Build/(.*)\\.unityweb"", ""headers"": [ { ""key"": ""Content-Encoding"", ""value"": ""br"" } ] },
    { ""source"": ""/Build/(.*)\\.wasm\\.unityweb"", ""headers"": [ { ""key"": ""Content-Type"", ""value"": ""application/wasm"" } ] },
    { ""source"": ""/Build/(.*)\\.js\\.unityweb"", ""headers"": [ { ""key"": ""Content-Type"", ""value"": ""application/javascript"" } ] },
    { ""source"": ""/Build/(.*)\\.data\\.unityweb"", ""headers"": [ { ""key"": ""Content-Type"", ""value"": ""application/octet-stream"" } ] },
    { ""source"": ""/(.*)"", ""headers"": [ { ""key"": ""X-Robots-Tag"", ""value"": ""noindex"" } ] }
  ]
}
";

        [MenuItem("Fields of Hope/Build/WebGL Evaluation Preview (14 days)")]
        public static void WebGLPreview() => Build(BuildTarget.WebGL, "WebGL-Preview", PreviewDays);

        [MenuItem("Fields of Hope/Build/Windows Evaluation Preview (14 days)")]
        public static void WindowsPreview() => Build(BuildTarget.StandaloneWindows64, "Windows-Preview/FieldsOfHope.exe", PreviewDays);

        [MenuItem("Fields of Hope/Build/WebGL Release")]
        public static void WebGLRelease() => Build(BuildTarget.WebGL, "WebGL-Release", 0);

        [MenuItem("Fields of Hope/Build/Windows Release")]
        public static void WindowsRelease() => Build(BuildTarget.StandaloneWindows64, "Windows-Release/FieldsOfHope.exe", 0);

        /// <summary>The Android app's package name (unique on a phone and on Google Play). Change it to the publisher's own.</summary>
        public const string AndroidPackage = "com.fieldsofhope.game";

        [MenuItem("Fields of Hope/Build/Android APK Evaluation Preview (14 days)")]
        public static void AndroidPreview() => Build(BuildTarget.Android, "Android-Preview/FieldsOfHope-Preview.apk", PreviewDays);

        [MenuItem("Fields of Hope/Build/Android APK Release")]
        public static void AndroidRelease() => Build(BuildTarget.Android, "Android-Release/FieldsOfHope.apk", 0);

        public static string Build(BuildTarget target, string output, int previewDays)
        {
            string root = Path.GetFullPath(Path.Combine(Application.dataPath, "..", "Builds"));
            string path = Path.Combine(root, output);
            PlayerSettings.productName = "Fields of Hope";
            // the app icon (Assets/Icons/app_icon.png: the title art and logo) on phones and desktops
            var icon = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/Icons/app_icon.png");
            if (icon != null) PlayerSettings.SetIcons(NamedBuildTarget.Unknown, new[] { icon }, IconKind.Any);
            if (target == BuildTarget.WebGL)
            {
                PlayerSettings.WebGL.compressionFormat = WebGLCompressionFormat.Brotli;
                PlayerSettings.WebGL.decompressionFallback = true;   // still starts if a host drops the Content-Encoding header
                PlayerSettings.WebGL.dataCaching = true;
                PlayerSettings.WebGL.template = "PROJECT:FieldsOfHope";   // full-window page, Assets/WebGLTemplates
                PlayerSettings.SplashScreen.show = false;
                PlayerSettings.SetManagedStrippingLevel(NamedBuildTarget.WebGL, ManagedStrippingLevel.High);   // Assets/link.xml keeps game code
                PlayerSettings.SetIl2CppCodeGeneration(NamedBuildTarget.WebGL, Il2CppCodeGeneration.OptimizeSize);
                // UnityEditor.WebGL.UserBuildSettings lives in the WebGL module, which may not be installed
                var webgl = Type.GetType("UnityEditor.WebGL.UserBuildSettings, UnityEditor.WebGL.Extensions");
                var opt = webgl?.GetProperty("codeOptimization");
                if (opt != null) opt.SetValue(null, Enum.Parse(opt.PropertyType, "DiskSizeLTO"));
            }
            if (target == BuildTarget.Android)
            {
                // an installable .apk (not a Play Store .aab), 64-bit and 32-bit ARM phones, Android 7.1 and newer
                EditorUserBuildSettings.buildAppBundle = false;
                PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, AndroidPackage);
                PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
                PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64 | AndroidArchitecture.ARMv7;
                PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel25;
                PlayerSettings.SetManagedStrippingLevel(NamedBuildTarget.Android, ManagedStrippingLevel.High);   // Assets/link.xml keeps game code
                PlayerSettings.SplashScreen.show = false;
                // the game is played in landscape only, either way round
                PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
                PlayerSettings.allowedAutorotateToPortrait = false;
                PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
                PlayerSettings.allowedAutorotateToLandscapeLeft = true;
                PlayerSettings.allowedAutorotateToLandscapeRight = true;
                Directory.CreateDirectory(Path.GetDirectoryName(path));
            }
            if (previewDays > 0)
            {
                string expires = DateTime.UtcNow.AddDays(previewDays).ToString("yyyy-MM-dd");
                File.WriteAllText(ConfigPath, "{\"expiresUtc\":\"" + expires + "\",\"label\":\"Evaluation preview - not for distribution\",\"unlockAll\":" +
                                              (OpenAllLocations ? "true" : "false") + "}");
                AssetDatabase.ImportAsset(ConfigPath);
            }
            try
            {
                var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
                {
                    scenes = new[] { Scene }, locationPathName = path, target = target, options = BuildOptions.None,
                });
                string msg = "[Build] " + target + " " + report.summary.result + " -> " + path + " (" + report.summary.totalSize / (1024 * 1024) + " MB, " +
                             report.summary.totalErrors + " errors)";
                if (target == BuildTarget.WebGL && report.summary.result == BuildResult.Succeeded)
                {
                    File.WriteAllText(Path.Combine(path, "vercel.json"), VercelConfig);
                    // itch.io expects a zip with index.html at its root
                    string zip = path + ".zip";
                    if (File.Exists(zip)) File.Delete(zip);
                    System.IO.Compression.ZipFile.CreateFromDirectory(path, zip);
                    msg += "\n[Build] Upload this file to itch.io: " + zip;
                }
                Debug.Log(msg);
                return msg;
            }
            finally
            {
                if (File.Exists(ConfigPath)) AssetDatabase.DeleteAsset(ConfigPath);
            }
        }
    }
}
