using UnityEditor;
using UnityEngine;

// Every texture under Resources/Art is a UI sprite. Procedural pixel icons keep hard edges;
// the painted mockup layers use bilinear filtering so they scale smoothly.
public class ArtImportSettings : AssetPostprocessor
{
    static readonly string[] PixelPrefixes = { "crop_", "emote_", "item_", "icon_cp", "icon_xp", "icon_lock", "icon_check", "icon_drop",
        "icon_bug", "icon_sun", "icon_moon", "icon_people", "obstacle_", "sign_", "bubble_", "stage_", "tree_", "tile_" };

    // background music streams instead of being unpacked into memory up front
    void OnPreprocessAudio()
    {
        if (!assetPath.Replace('\\', '/').Contains("/Resources/Audio/")) return;
        var ai = (AudioImporter)assetImporter;
        var s = ai.defaultSampleSettings;
        s.loadType = AudioClipLoadType.Streaming;
        s.compressionFormat = AudioCompressionFormat.Vorbis;
        s.quality = 0.5f;
        ai.defaultSampleSettings = s;
    }

    static readonly string[] Compressed = { "title_bg", "map_islands", "logo", "btn_start", "btn_quit", "npc_portrait",
        "ground_baguio", "ground_ilocos", "ground_davao" };
    static readonly string[] Opaque = { "title_bg", "ground_baguio", "ground_ilocos", "ground_davao" };

    void OnPreprocessTexture()
    {
        string path = assetPath.Replace('\\', '/');
        if (path.Contains("/Resources/Map/")) { MapSprite((TextureImporter)assetImporter); return; }
        if (!path.Contains("/Resources/Art/")) return;
        var ti = (TextureImporter)assetImporter;
        ti.textureType = TextureImporterType.Sprite;
        ti.spriteImportMode = SpriteImportMode.Single;
        ti.mipmapEnabled = false;
        ti.alphaIsTransparency = true;
        ti.textureCompression = TextureImporterCompression.Uncompressed;
        ti.maxTextureSize = 4096;
        ti.npotScale = TextureImporterNPOTScale.None;
        ti.wrapMode = TextureWrapMode.Clamp;
        string file = System.IO.Path.GetFileName(assetPath);
        if (file.StartsWith("mask_"))
        {
            // living-painting masks are data, not colours: no sRGB conversion, no alpha bleeding, codes never blended
            ti.textureType = TextureImporterType.Default;
            ti.sRGBTexture = false;
            ti.alphaIsTransparency = false;
            ti.filterMode = FilterMode.Point;
            return;
        }
        ti.filterMode = FilterMode.Bilinear;
        foreach (var p in PixelPrefixes)
            if (file.StartsWith(p)) { ti.filterMode = FilterMode.Point; break; }
        // the large paintings are GPU-compressed (DXT1 opaque / DXT5 with alpha, best quality): ~6x smaller download,
        // visually identical (compared side by side). Their sizes are padded to multiples of 4, which DXT requires.
        string bare = System.IO.Path.GetFileNameWithoutExtension(file);
        if (System.Array.IndexOf(Compressed, bare) >= 0)
        {
            ti.textureCompression = TextureImporterCompression.Compressed;
            ti.compressionQuality = 100;
            ti.crunchedCompression = false;
            // pin the exact formats that were compared (WebGL would otherwise be free to pick BC7, twice the size)
            bool opaque = System.Array.IndexOf(Opaque, bare) >= 0;
            ti.SetPlatformTextureSettings(new TextureImporterPlatformSettings
            {
                name = "WebGL", overridden = true, maxTextureSize = 4096, compressionQuality = 100,
                format = opaque ? TextureImporterFormat.DXT1 : TextureImporterFormat.DXT5,
            });
        }
    }

    // farm map objects (buildings, trees, props; Tools/map_builder.py pads them to multiples of 4): smooth DXT5 sprites
    static void MapSprite(TextureImporter ti)
    {
        ti.textureType = TextureImporterType.Sprite;
        ti.spriteImportMode = SpriteImportMode.Single;
        ti.mipmapEnabled = false;
        ti.alphaIsTransparency = true;
        ti.npotScale = TextureImporterNPOTScale.None;
        ti.wrapMode = TextureWrapMode.Clamp;
        ti.filterMode = FilterMode.Bilinear;
        ti.textureCompression = TextureImporterCompression.Compressed;
        ti.compressionQuality = 100;
        ti.crunchedCompression = false;
        ti.SetPlatformTextureSettings(new TextureImporterPlatformSettings
        {
            name = "WebGL", overridden = true, maxTextureSize = 2048, compressionQuality = 100, format = TextureImporterFormat.DXT5,
        });
    }
}
