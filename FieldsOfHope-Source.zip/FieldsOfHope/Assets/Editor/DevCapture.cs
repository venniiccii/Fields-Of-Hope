using System.IO;
using UnityEditor;
using UnityEngine;

namespace FieldsOfHope.EditorTools
{
    /// <summary>Renders the game UI to a PNG at 1920x1080 (used for visual checks while the editor is unfocused).</summary>
    public static class DevCapture
    {
        public static string Capture(string path, int w = 1920, int h = 1080)
        {
            var canvas = Object.FindAnyObjectByType<GameApp>()?.GetComponentInChildren<Canvas>();
            if (canvas == null) return "No GameApp canvas";
            var camGo = new GameObject("CaptureCam");
            var cam = camGo.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = Color.black;
            var rt = new RenderTexture(w, h, 24);
            cam.targetTexture = rt;
            var mode = canvas.renderMode;
            canvas.renderMode = RenderMode.ScreenSpaceCamera;
            canvas.worldCamera = cam;
            canvas.planeDistance = 10;
            Canvas.ForceUpdateCanvases();
            cam.Render();
            Canvas.ForceUpdateCanvases();
            cam.Render();
            var prev = RenderTexture.active;
            RenderTexture.active = rt;
            var tex = new Texture2D(w, h, TextureFormat.RGB24, false);
            tex.ReadPixels(new Rect(0, 0, w, h), 0, 0);
            tex.Apply();
            RenderTexture.active = prev;
            File.WriteAllBytes(path, tex.EncodeToPNG());
            canvas.renderMode = mode;
            canvas.worldCamera = null;
            cam.targetTexture = null;
            Object.DestroyImmediate(camGo);
            Object.DestroyImmediate(rt);
            Object.DestroyImmediate(tex);
            return "Saved " + path;
        }
    }
}
