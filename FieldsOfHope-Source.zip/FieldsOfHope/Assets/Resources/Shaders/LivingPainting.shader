// Brings a painted UI background to life using a mask made by Tools/make_masks.py (project root):
//   R = foliage (sways in the wind)   G = water (ripples, sparkles)
//   B = character motion code (type * 32 + phase)   A = character weight (0 at the feet, 1 at the head)
// plus slow cloud shadows over everything and an optional turning water wheel.
// Based on Unity's UI/Default so RectMask2D clipping and UI stencils keep working.
Shader "FieldsOfHope/LivingPainting"
{
    Properties
    {
        [PerRendererData] _MainTex ("Painting", 2D) = "white" {}
        _Color ("Tint", Color) = (1,1,1,1)
        _Mask ("Living mask", 2D) = "black" {}
        _Sway ("Foliage sway (px)", Float) = 1.6
        _Ripple ("Water ripple (px)", Float) = 1.4
        _People ("Character motion (px)", Float) = 2.2
        _Clouds ("Cloud shadow strength", Float) = 0.1
        _Wheel ("Wheel centre xy / radius (px), speed", Vector) = (0,0,0,0)

        _StencilComp ("Stencil Comparison", Float) = 8
        _Stencil ("Stencil ID", Float) = 0
        _StencilOp ("Stencil Operation", Float) = 0
        _StencilWriteMask ("Stencil Write Mask", Float) = 255
        _StencilReadMask ("Stencil Read Mask", Float) = 255
        _ColorMask ("Color Mask", Float) = 15
        [Toggle(UNITY_UI_ALPHACLIP)] _UseUIAlphaClip ("Use Alpha Clip", Float) = 0
    }

    SubShader
    {
        Tags { "Queue"="Transparent" "IgnoreProjector"="True" "RenderType"="Transparent" "PreviewType"="Plane" "CanUseSpriteAtlas"="True" }
        Stencil
        {
            Ref [_Stencil]
            Comp [_StencilComp]
            Pass [_StencilOp]
            ReadMask [_StencilReadMask]
            WriteMask [_StencilWriteMask]
        }
        Cull Off
        Lighting Off
        ZWrite Off
        ZTest [unity_GUIZTestMode]
        Blend SrcAlpha OneMinusSrcAlpha
        ColorMask [_ColorMask]

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 3.0
            #include "UnityCG.cginc"
            #include "UnityUI.cginc"
            #pragma multi_compile_local _ UNITY_UI_CLIP_RECT
            #pragma multi_compile_local _ UNITY_UI_ALPHACLIP

            struct appdata { float4 vertex : POSITION; float4 color : COLOR; float2 uv : TEXCOORD0; };
            struct v2f { float4 pos : SV_POSITION; fixed4 color : COLOR; float2 uv : TEXCOORD0; float4 world : TEXCOORD1; };

            sampler2D _MainTex; float4 _MainTex_TexelSize;
            sampler2D _Mask;
            fixed4 _Color; float4 _ClipRect;
            float _Sway, _Ripple, _People, _Clouds;
            float4 _Wheel;

            v2f vert (appdata v)
            {
                v2f o;
                o.world = v.vertex;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.uv = v.uv;
                o.color = v.color * _Color;
                return o;
            }

            // one villager/animal: returns how far (px) the painting at this point is pushed
            float2 CharacterMotion(float code, float w, float t)
            {
                if (w <= 0.001) return 0;
                float kind = floor(code / 32.0);
                float ph = fmod(code, 32.0) / 32.0 * 6.2832;
                float2 d = 0;
                if (kind < 0.5)      d = float2(0.35 * sin(t * 0.9 + ph), 0.9 * sin(t * 1.7 + ph));              // idle: breathing
                else if (kind < 1.5) d = float2(1.0 * sin(t * 3.1 + ph), 1.1 * abs(sin(t * 3.1 + ph)));           // working: lean and bob
                else if (kind < 2.5) d = float2(0.6 * sin(t * 1.2 + ph * 2.0), 0.9 * sin(t * 2.3 + ph));        // chatting: nods
                else if (kind < 3.5) d = float2(1.4 * sin(t * 1.3 + ph) + 0.4 * sin(t * 3.7 + ph), 0);          // scarecrow in the wind
                else if (kind < 4.5) d = float2(0.6 * sin(t * 0.5 + ph), 1.0 * sin(t * 0.8 + ph));              // animal: slow head bob
                else                 d = float2(1.2 * sin(t * 0.45 + ph), 0.5 * sin(t * 1.4 + ph));             // swan: paddling
                return d * w;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                float t = _Time.y;
                float2 size = _MainTex_TexelSize.zw;          // painting size in px
                float2 p = i.uv * size;                       // this fragment in painting px (y up)
                fixed4 m = tex2D(_Mask, i.uv);
                float2 push = 0;

                // foliage: two layered breezes so neighbouring trees don't move in lock-step
                push.x += m.r * _Sway * (0.65 * sin(t * 1.5 + p.x * 0.021 + p.y * 0.013) + 0.35 * sin(t * 2.9 + p.y * 0.05));
                push.y += m.r * _Sway * 0.3 * sin(t * 2.1 + p.x * 0.03);

                // water: rippling refraction
                push += m.g * _Ripple * float2(sin(p.y * 0.35 + t * 2.2), sin(p.x * 0.25 - t * 1.7));

                // villagers and animals
                push += CharacterMotion(floor(m.b * 255.0 + 0.5), m.a, t) * _People;

                float2 q = p - push;

                // water wheel: the disc inside its rim turns
                if (_Wheel.z > 0)
                {
                    float2 d = q - _Wheel.xy;
                    if (dot(d, d) < _Wheel.z * _Wheel.z)
                    {
                        float a = -t * _Wheel.w, s = sin(a), c = cos(a);
                        q = _Wheel.xy + float2(c * d.x - s * d.y, s * d.x + c * d.y);
                    }
                }

                fixed4 col = tex2D(_MainTex, q / size) * i.color;

                // sunlight glints dancing on the water
                float glint = sin(p.x * 0.42 + t * 2.4) * sin(p.y * 0.62 - t * 1.9) * sin((p.x + p.y) * 0.11 + t * 0.6);
                col.rgb += m.g * smoothstep(0.78, 1.0, glint) * 0.32;
                col.rgb += m.g * 0.05 * sin(p.x * 0.05 + p.y * 0.03 - t * 1.2);

                // big soft cloud shadows drifting across the land
                float cloud = sin(p.x * 0.0045 + t * 0.06) * sin(p.y * 0.007 - t * 0.04) + 0.6 * sin((p.x + p.y * 1.4) * 0.003 + t * 0.05);
                col.rgb *= 1.0 - _Clouds * smoothstep(0.55, 1.3, cloud);

                #ifdef UNITY_UI_CLIP_RECT
                col.a *= UnityGet2DClipping(i.world.xy, _ClipRect);
                #endif
                #ifdef UNITY_UI_ALPHACLIP
                clip(col.a - 0.001);
                #endif
                return col;
            }
            ENDCG
        }
    }
}
